package com.chaotyk.arcade;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.regex.*;

/** Release information is parsed as data; downloaded JavaScript is never executed. */
final class AppRelease {
  final String version,link,notes;
  AppRelease(String version,String link,String notes){this.version=version;this.link=link;this.notes=notes;}
  static String line(String text,String label){Matcher match=Pattern.compile("(?im)^\\h*(?://\\h*)?"+label+"\\h*:\\h*([^\\r\\n]*)$").matcher(text);return match.find()?match.group(1).trim():"";}
  static AppRelease parse(String text)throws Exception{
    String version=line(text,"Current\\h+version"),link=line(text,"Update\\h+link"),notes=line(text,"Release\\h+notes");
    if(version.isEmpty())throw new IOException("Update file has no Current version line.");
    ScriptUpdateClient.compareVersions(version,version);
    if(link.isEmpty())throw new IOException("Update file has no Update link line.");
    ScriptUpdateClient.requireHttps(link);
    return new AppRelease(version,link,notes);
  }
  static void validateApk(String actualPackage,String actualVersion,long actualCode,Set<String> actualSigners,String ownPackage,long ownCode,Set<String> ownSigners,String advertised)throws Exception{
    if(!ownPackage.equals(actualPackage))throw new IOException("Downloaded APK is for a different app.");
    if(ScriptUpdateClient.compareVersions(actualVersion,advertised)!=0)throw new IOException("Downloaded APK version does not match the advertised release.");
    if(actualCode<=ownCode)throw new IOException("Downloaded APK is not newer than the installed app.");
    if(actualSigners==null||ownSigners==null||actualSigners.isEmpty()||!actualSigners.equals(ownSigners))throw new IOException("Downloaded APK has a different signing certificate.");
  }
}
