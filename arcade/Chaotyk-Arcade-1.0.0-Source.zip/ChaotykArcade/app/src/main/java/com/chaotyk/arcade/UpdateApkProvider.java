package com.chaotyk.arcade;
import android.content.*;
import android.database.*;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.*;

/** Read-only access to one verified update APK; the installer receives a URI grant. */
public class UpdateApkProvider extends ContentProvider {
  static Uri uri(Context context){return Uri.parse("content://"+context.getPackageName()+".updates/app-update.apk");}
  File file(Uri uri)throws FileNotFoundException{if(!"/app-update.apk".equals(uri.getPath()))throw new FileNotFoundException("Unknown update URI");File file=new File(getContext().getFilesDir(),"updates/app-update.apk");if(!file.isFile())throw new FileNotFoundException("No update downloaded");return file;}
  @Override public boolean onCreate(){return true;}
  @Override public String getType(Uri uri){return "application/vnd.android.package-archive";}
  @Override public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException{if(!mode.equals("r"))throw new FileNotFoundException("Read-only update");return ParcelFileDescriptor.open(file(uri),ParcelFileDescriptor.MODE_READ_ONLY);}
  @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String order){try{File file=file(uri);String[] columns=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;MatrixCursor cursor=new MatrixCursor(columns,1);Object[] row=new Object[columns.length];for(int i=0;i<columns.length;i++)row[i]=OpenableColumns.DISPLAY_NAME.equals(columns[i])?"Chaotyk-Arcade-update.apk":OpenableColumns.SIZE.equals(columns[i])?file.length():null;cursor.addRow(row);return cursor;}catch(Exception e){return null;}}
  @Override public Uri insert(Uri uri,ContentValues values){throw new SecurityException("Read only");}
  @Override public int update(Uri uri,ContentValues values,String selection,String[] args){throw new SecurityException("Read only");}
  @Override public int delete(Uri uri,String selection,String[] args){throw new SecurityException("Read only");}
}
