(function () {
    'use strict';

    const keys = new Set();
    const LEADERBOARD_KEY = 'chaotykArcadeLeaderboardV3';
    const WINDOW_LAYOUT_KEY = 'chaotykArcadeWindowLayoutV5';
    const POWER_DURATION_MULTIPLIER = 1.25;
    const poweredDuration = milliseconds => Math.ceil(milliseconds * POWER_DURATION_MULTIPLIER / 1000) * 1000;
    const games = [
        { id: 'solitaire', name: 'Solitaire', icon: '♠️', blurb: 'Classic Klondike with a full 52-card deck.' },
        { id: 'snake', name: 'Snake', icon: '🐍', blurb: 'Eat, grow, and avoid your tail.' },
        { id: 'mines', name: 'Minesweeper', icon: '💣', blurb: 'Clear the board without finding a mine.' },
        { id: '2048', name: '2048', icon: '🔢', blurb: 'Combine matching tiles to reach 2048.' },
        { id: 'layuplaunch', name: 'Layup Launch', icon: '🏀', blurb: 'Launch high, ricochet down, and sink the 20.' },
        { id: 'chainpanic', name: 'Chain Panic', icon: '🌀', blurb: 'Catch, swing, grow, bank—or unleash a black hole.' },
        { id: 'breakout', name: 'Breakout', icon: '🧱', blurb: 'Bounce the ball and clear every brick.' },
        { id: 'ttt', name: 'Tic-Tac-Toe', icon: '❌', blurb: 'Play a quick round against the computer.' },
        { id: 'asteroids', name: 'Asteroids', icon: '☄️', blurb: 'Classic survival or a powered-up space run.', modes: true },
        { id: 'invaders', name: 'Space Invaders', icon: '👾', blurb: 'Defend Earth in classic or enhanced waves.', modes: true },
        { id: 'reversi', name: 'Reversi', icon: '⚫', blurb: 'Outflank the computer—with optional abilities.', modes: true },
        { id: 'battleship', name: 'Battleship', icon: '🚢', blurb: 'Command a fleet with or without tactical powers.', modes: true },
        { id: 'blackjack', name: 'Blackjack', icon: '🃏', blurb: 'Classic casino rules or Chaotyk table events.', modes: true },
        { id: 'rummy', name: 'Gin Rummy', icon: '♦️', blurb: 'Draw, meld, and knock against the computer.', modes: true },
        { id: 'chess', name: 'Chess', icon: '♚', blurb: 'Play a complete game as White against the computer.' },
        { id: 'poker', name: 'Video Poker', icon: '🎰', blurb: 'Classic Jacks or Better five-card draw.' },
        { id: 'yahtzee', name: 'Yahtzee', icon: '🎲', blurb: 'Hold dice, chase combinations, and fill the scorecard.', modes: true },
        { id: 'match3', name: 'GigaGems', icon: '💎', blurb: 'Swap gems, build matches, and trigger huge cascades.', modes: true }
    ];

    let host = null;
    let root = null;
    let currentGame = null;
    let currentMode = 'original';
    let cleanupTouch = () => {};
    let cleanupGame = () => {};
    let cleanupWindow = () => {};
    let previousOverflow = '';
    let leaderboardCache = null;

    const resultRows = [
        ['layuplaunch:original','Layup Launch — Original'], ['layuplaunch:chaotyk','Layup Launch — Chaotyk'],
        ['chainpanic:original','Chain Panic — Original'], ['chainpanic:chaotyk','Chain Panic — Chaotyk'],
        ['solitaire', 'Solitaire'], ['snake', 'Snake'], ['mines', 'Minesweeper'],
        ['2048:original', '2048 — Original'], ['2048:chaotyk', '2048 — Chaotyk'],
        ['breakout', 'Breakout — Original'], ['breakout:chaotyk', 'Breakout — Chaotyk'], ['ttt', 'Tic-Tac-Toe'],
        ['asteroids:original', 'Asteroids — Original'], ['asteroids:chaotyk', 'Asteroids — Chaotyk'],
        ['invaders:original', 'Space Invaders — Original'], ['invaders:chaotyk', 'Space Invaders — Chaotyk'],
        ['reversi:original', 'Reversi — Original'], ['reversi:chaotyk', 'Reversi — Chaotyk'],
        ['battleship:original', 'Battleship — Original'], ['battleship:chaotyk', 'Battleship — Chaotyk'],
        ['blackjack:original', 'Blackjack — Original'], ['blackjack:chaotyk', 'Blackjack — Chaotyk'],
        ['rummy:original', 'Gin Rummy — Original'], ['rummy:chaotyk', 'Gin Rummy — Chaotyk'],
        ['chess', 'Chess'], ['poker', 'Video Poker'],
        ['yahtzee:original', 'Yahtzee — Original'], ['yahtzee:chaotyk', 'Yahtzee — Chaotyk'],
        ['match3:original', 'GigaGems — Original'], ['match3:chaotyk', 'GigaGems — Chaotyk']
    ];

    function loadLeaderboard() {
        if (leaderboardCache) return leaderboardCache;
        const saved = GM_getValue(LEADERBOARD_KEY, {});
        leaderboardCache = saved && typeof saved === 'object' && !Array.isArray(saved) ? saved : {};
        return leaderboardCache;
    }

    function saveLeaderboard(board) { leaderboardCache = board; GM_setValue(LEADERBOARD_KEY, board); }

    function recordBest(key, value, label, lowerIsBetter = false) {
        if (!Number.isFinite(value)) return;
        const board = loadLeaderboard();
        const old = board[key];
        if (!old || (lowerIsBetter ? value < old.value : value > old.value)) {
            board[key] = { value, label, updated: new Date().toISOString() };
            saveLeaderboard(board);
        }
    }

    function addWin(key) {
        const board = loadLeaderboard();
        const wins = (board[key]?.value || 0) + 1;
        board[key] = { value: wins, label: `${wins} win${wins === 1 ? '' : 's'}`, updated: new Date().toISOString() };
        saveLeaderboard(board);
    }

    const modeKey = id => `${id}:${currentMode}`;

    function openArcade() {
        previousOverflow = document.body.style.overflow;
        document.body.style.overflow = 'hidden';
        host = document.createElement('div');
        host.id = 'chaotyk-arcade-host';
        host.style.cssText='position:relative;z-index:1';
        root = host.attachShadow({ mode: 'open' });
        root.innerHTML = `
<style>
  :host{all:initial} *{box-sizing:border-box;scrollbar-width:none} *::-webkit-scrollbar{display:none;width:0;height:0} button{font:inherit}
  #backdrop{position:fixed;inset:0;z-index:2147483647;background:#0009;font-family:Arial,Helvetica,sans-serif;color:#eee}
  #arcade{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:min(560px,calc(100vmin - 8px));height:min(560px,calc(100vmin - 8px));min-width:min(560px,calc(100vmin - 8px));min-height:min(560px,calc(100vmin - 8px));max-width:calc(100vmin - 8px);max-height:calc(100vmin - 8px);aspect-ratio:1/1;container-type:size;display:flex;flex-direction:column;overflow:hidden;background:radial-gradient(circle at top,#221010,#090909 48%,#000);border:2px solid #a51f1f;border-radius:16px;box-shadow:0 30px 90px #000,0 0 35px #a00a}
  #resize-handle{position:absolute;right:1px;bottom:1px;z-index:20;width:24px;height:24px;cursor:nwse-resize;touch-action:none;background:linear-gradient(135deg,transparent 42%,#661919 43% 54%,transparent 55% 63%,#d33 64% 73%,transparent 74%);border-radius:0 0 13px 0}
  header{display:flex;align-items:center;justify-content:space-between;padding:13px 17px;background:#050505;border-bottom:1px solid #721616;cursor:grab;user-select:none;touch-action:none}
  header:active{cursor:grabbing}.top-actions,.top-actions *{cursor:pointer}
  h1{margin:0;color:#ff3434;font-size:clamp(21px,3.75cqw,56px);letter-spacing:3px;text-transform:uppercase;text-shadow:0 0 12px #f006}
  #sub{color:#aaa;font-size:clamp(10px,1.79cqw,26px);margin-top:3px}.top-actions{display:flex;gap:8px}
  .top-button,.action{padding:8px 12px;color:#ff4b4b;background:#151515;border:1px solid #7c2020;border-radius:8px;cursor:pointer;font-weight:800}
  .top-button:hover,.action:hover{color:white;background:#7d1717}
  .leaderboard{width:min(680px,100%);margin:auto}.leaderboard h2{margin:0 0 14px;color:#ff3d3d;text-align:center}.leaderboard-table{width:100%;border-collapse:collapse;background:#0b0b0b;border:1px solid #572020}.leaderboard-table th,.leaderboard-table td{padding:9px 12px;border-bottom:1px solid #321818;text-align:left}.leaderboard-table th{color:#ff5555;background:#160909}.leaderboard-table td:last-child{color:#fff;font-weight:800}.leaderboard-actions{display:flex;justify-content:center;gap:8px;flex-wrap:wrap;margin-top:14px}.leaderboard-file{display:none}
  #content{flex:1;min-width:0;min-height:0;padding:14px 18px 18px;overflow:auto;overflow-x:hidden}
  #menu{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));grid-auto-rows:minmax(0,1fr);gap:7px;width:100%;height:100%;align-content:stretch}
  .game-tile{display:grid;grid-template-columns:clamp(38px,5cqw,60px) minmax(0,1fr);align-items:center;gap:clamp(7px,1cqw,14px);width:100%;height:100%;min-width:0;min-height:0;padding:clamp(5px,.7cqw,10px) clamp(8px,1.3cqw,18px);overflow:hidden;color:#eee;text-align:left;background:#101010;border:1px solid #502020;border-radius:10px;cursor:pointer;box-shadow:0 6px 16px #0008}
  .game-tile:hover{transform:translateY(-2px);border-color:#f33;background:#1b0b0b;box-shadow:0 10px 24px #000,0 0 14px #f003}
  .icon{font-size:clamp(25px,4.46cqw,84px)}.game-name{display:block;overflow:hidden;text-overflow:ellipsis;color:#ff3d3d;font-size:clamp(13px,2.32cqw,42px);font-weight:900}.blurb{display:block;margin-top:2px;overflow:hidden;color:#aaa;font-size:clamp(8px,1.43cqw,28px);line-height:1.2}.keycap{padding:5px 8px;color:#ddd;background:#050505;border:1px solid #555;border-radius:6px;font-size:10px}
  .game-shell{height:100%;display:flex;flex-direction:column;align-items:center;gap:10px}.game-title{color:#ff3a3a;font-size:clamp(19px,calc(14px + .65cqw),26px);font-weight:900;letter-spacing:2px}.status{min-height:20px;color:#ddd;font-size:clamp(12px,calc(9px + .35cqw),15px);text-align:center}.row{display:flex;align-items:center;gap:9px}
  canvas{max-width:100%;max-height:calc(100cqh - 155px);width:auto;height:auto;background:#060606;border:1px solid #6d1d1d;border-radius:8px;box-shadow:0 8px 25px #000}
  #mine-grid{--mine-cell:clamp(24px,min(4.5cqw,6cqh),34px);display:grid;grid-template-columns:repeat(9,var(--mine-cell));gap:2px;padding:7px;background:#080808;border:1px solid #6d1d1d;border-radius:8px}
  .mine-cell{width:var(--mine-cell);height:var(--mine-cell);padding:0;color:#ddd;background:#242424;border:1px outset #555;border-radius:3px;cursor:pointer;font-size:clamp(11px,2cqh,16px);font-weight:900}.mine-cell.open{background:#0d0d0d;border:1px solid #282828}.mine-cell.mine{color:#ff3030}.n1{color:#5ca8ff}.n2{color:#4bd66b}.n3{color:#ff5555}.n4{color:#b47cff}
  #grid2048{display:grid;grid-template-columns:repeat(var(--grid-size,4),var(--tile-size,82px));gap:8px;padding:9px;background:#100707;border:1px solid #6d1d1d;border-radius:10px}.tile2048{width:var(--tile-size,82px);height:var(--tile-size,82px);display:flex;align-items:center;justify-content:center;color:#fff;background:#191919;border-radius:7px;font-size:25px;font-weight:900}.v2{background:#3b2222}.v4{background:#582424}.v8{background:#7c2920}.v16{background:#9b321d}.v32{background:#b8401d}.v64{background:#d34a1b}.v128{background:#a26b12}.v256{background:#bd7d0c}.v512{background:#d99400}.v1024,.v2048{background:#f0aa00;color:#111;font-size:20px}
  #ttt-board{--ttt-cell:clamp(64px,min(11cqw,18cqh),105px);display:grid;grid-template-columns:repeat(3,var(--ttt-cell));gap:7px}.ttt-cell{width:var(--ttt-cell);height:var(--ttt-cell);color:#ff3a3a;background:#101010;border:1px solid #692020;border-radius:9px;cursor:pointer;font-size:clamp(34px,min(6cqw,9cqh),52px);font-weight:900}.ttt-cell:hover{background:#1e0b0b}
  #chess-board{--chess-cell:clamp(34px,min(6cqw,8cqh),55px);display:grid;grid-template-columns:repeat(8,var(--chess-cell));border:3px solid #591919;box-shadow:0 8px 25px #000}.chess-cell{width:var(--chess-cell);height:var(--chess-cell);padding:0;border:0;cursor:pointer;font-size:clamp(23px,min(4cqw,5.5cqh),38px);line-height:var(--chess-cell)}.chess-cell.light{background:#d6b28a}.chess-cell.dark{background:#7c3c34}.chess-cell.selected{box-shadow:inset 0 0 0 4px #ffda35}.chess-cell.legal{box-shadow:inset 0 0 0 4px #52d96b}.chess-cell.capture{box-shadow:inset 0 0 0 4px #ff4343}.chess-cell:disabled{cursor:default}.poker-paytable{display:grid;grid-template-columns:1fr auto;gap:4px 18px;padding:9px 14px;color:#bbb;background:#090909;border:1px solid #502020;border-radius:8px;font-size:clamp(10px,1.6cqh,12px)}.poker-paytable .active{color:#ffd42a;font-weight:900}.poker-card{position:relative}.hold-tag{position:absolute;left:0;right:0;bottom:-20px;color:#ffd42a;font:900 10px Arial;text-align:center}.poker-controls{margin-top:22px}
  #sol-board{width:100%;display:grid;grid-template-columns:130px 1fr;gap:12px;min-height:360px}.sol-side{display:flex;flex-direction:column;gap:10px}.sol-row{display:flex;gap:7px;flex-wrap:wrap}.sol-tableau{display:grid;grid-template-columns:repeat(7,minmax(55px,1fr));gap:6px}.sol-column{min-height:315px;padding:4px;background:#ffffff05;border:1px solid #391515;border-radius:8px}.sol-card,.sol-back,.sol-empty{width:54px;height:74px;border-radius:7px}.sol-card{display:flex;flex-direction:column;align-items:center;justify-content:center;color:#111;background:linear-gradient(145deg,#fff,#d2d2d2);border:1px solid #777;font-family:Georgia,serif;font-size:17px;font-weight:900;cursor:pointer}.sol-card.red{color:#b50000}.sol-card.selected{outline:3px solid #f22;box-shadow:0 0 13px #f00}.sol-suit{font-size:24px}.sol-back{background:repeating-linear-gradient(45deg,#151515,#151515 5px,#4a0909 5px,#4a0909 10px);border:2px solid #a62323}.sol-empty{display:flex;align-items:center;justify-content:center;color:#712323;border:1px dashed #672121;font-size:25px;cursor:pointer}.sol-stack{display:block;margin:0 auto}.sol-stack+.sol-stack{margin-top:-45px}.sol-stack.down+.sol-stack{margin-top:-57px}.sol-label{color:#f44;font-size:10px;font-weight:900;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px}
  .help{color:#888;font-size:clamp(10px,calc(8px + .3cqw),13px);text-align:center}
  .mode-grid{display:grid;grid-template-columns:repeat(2,minmax(230px,1fr));gap:18px;width:min(650px,100%);margin:auto}.mode-card{min-height:180px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:24px;color:#eee;background:#111;border:1px solid #633;border-radius:14px;cursor:pointer;text-align:center}.mode-card strong{color:#ff4545;font-size:22px}.mode-card span{color:#aaa;font-size:12px;line-height:1.5}.mode-card:hover{transform:translateY(-3px);border-color:#f33;box-shadow:0 0 20px #f004}.mode-card.chaotyk{background:radial-gradient(circle at top,#351010,#0b0b0b)}
  .ability-bar{display:flex;gap:7px;flex-wrap:wrap;justify-content:center}.ability{padding:6px 9px;color:#ffd2d2;background:#301010;border:1px solid #a33;border-radius:6px;cursor:pointer;font-size:11px;font-weight:800}.ability:disabled{opacity:.35;cursor:not-allowed}
  .board-pair{display:flex;gap:clamp(8px,2cqw,18px);align-items:flex-start;justify-content:center;flex-wrap:wrap}.board-wrap{text-align:center}.board-name{color:#f44;font-size:11px;font-weight:900;margin-bottom:5px}.cell-board{display:grid;gap:2px;padding:6px;background:#080808;border:1px solid #632020;border-radius:8px}.battle-board{--battle-cell:clamp(21px,min(3.4cqw,4.7cqh),29px);grid-template-columns:repeat(10,var(--battle-cell))}.battle-cell{width:var(--battle-cell);height:var(--battle-cell);padding:0;color:#ddd;background:#102433;border:1px solid #1f4b67;cursor:pointer;font-size:clamp(10px,1.8cqh,13px)}.battle-cell.ship{background:#565d62}.battle-cell.hit{color:#fff;background:#a51616}.battle-cell.miss{color:#8ccfff;background:#132b3b}.battle-cell.sonar{box-shadow:inset 0 0 0 2px #ffd21c}
  .reversi-board{--rev-cell:clamp(29px,min(5.3cqw,7cqh),47px);grid-template-columns:repeat(8,var(--rev-cell));background:#092b18}.rev-cell{width:var(--rev-cell);height:var(--rev-cell);padding:0;background:#116133;border:1px solid #0a4222;cursor:pointer;border-radius:2px}.disc{display:block;width:76%;height:76%;margin:auto;border-radius:50%;box-shadow:inset 0 0 8px #0008,0 2px 3px #000}.disc.black{background:#111}.disc.white{background:#eee}.rev-cell.legal{box-shadow:inset 0 0 0 3px #ff4}
  .playing-cards{display:flex;gap:clamp(4px,.8cqw,7px);justify-content:center;flex-wrap:wrap;min-height:clamp(74px,14cqh,94px)}.playing-card{width:clamp(48px,min(7cqw,10cqh),62px);height:clamp(68px,min(10cqw,14cqh),88px);padding:5px;display:flex;flex-direction:column;justify-content:space-between;color:#111;background:#f1f1ed;border:1px solid #888;border-radius:7px;font-family:Georgia,serif;font-size:clamp(14px,2.8cqh,18px);font-weight:900;box-shadow:0 4px 8px #0008}.playing-card.red{color:#b40000}.playing-card.back{background:repeating-linear-gradient(45deg,#151515,#151515 6px,#510c0c 6px,#510c0c 12px);border:2px solid #a22}.hand-area{width:min(720px,100%);padding:clamp(6px,1.5cqh,10px);background:#ffffff05;border:1px solid #3b1919;border-radius:9px}.hand-label{color:#f44;font-size:clamp(10px,1.7cqh,12px);font-weight:900;margin-bottom:6px}.playing-card.selectable{cursor:pointer}.playing-card.selected{outline:3px solid #f22;transform:translateY(-5px)}
  /* v3.5.5: each game grows inside the square arcade while preserving its natural shape. */
  .game-tile{grid-template-columns:clamp(38px,5.8cqw,88px) minmax(0,1fr);column-gap:clamp(8px,1.4cqw,20px)}
  .icon{display:flex;align-items:center;justify-content:center;width:100%;line-height:1}
  .game-shell{width:100%;gap:clamp(7px,1.25cqh,16px)}
  .game-title{font-size:clamp(19px,2.6cqw,38px)}.status{font-size:clamp(12px,1.45cqw,21px)}
  .game-shell .action{padding:clamp(7px,1cqh,13px) clamp(10px,1.4cqw,20px);font-size:clamp(11px,1.25cqw,18px)}
  canvas{width:min(90cqw,calc((100cqh - 190px)*1.5));max-width:100%;max-height:calc(100cqh - 175px);height:auto}
  .game-snake canvas{width:min(82cqw,calc((100cqh - 190px)*1.25))}
  #mine-grid{--mine-cell:clamp(24px,min(6.4cqw,7.4cqh),66px);gap:clamp(2px,.35cqw,5px);padding:clamp(7px,1cqw,13px)}
  #grid2048{gap:clamp(8px,1cqw,14px);padding:clamp(9px,1.1cqw,15px)}
  .game-2048 #grid2048{--tile-size:clamp(52px,min(15cqw,13cqh),132px)!important}.game-2048 .tile2048{font-size:clamp(20px,3.2cqw,42px)}
  #ttt-board{--ttt-cell:clamp(64px,min(19cqw,20cqh),190px);gap:clamp(7px,1cqw,14px)}.ttt-cell{font-size:clamp(34px,min(10cqw,11cqh),100px)}
  .reversi-board{--rev-cell:clamp(29px,min(9cqw,8.8cqh),84px)}
  .battle-board{--battle-cell:clamp(21px,min(4.5cqw,5.8cqh),50px)}.battle-cell{font-size:clamp(10px,1.55cqw,18px)}
  #chess-board{--chess-cell:clamp(34px,min(9.5cqw,8.2cqh),90px)}.chess-cell{font-size:clamp(23px,min(6.5cqw,5.8cqh),64px)}
  .playing-cards{gap:clamp(4px,.8cqw,11px);min-height:clamp(74px,14cqh,150px)}
  .playing-card{width:clamp(48px,min(7cqw,10cqh),96px);height:clamp(68px,min(10cqw,14cqh),136px);padding:clamp(5px,.7cqw,10px);font-size:clamp(14px,2.2cqw,28px)}
  .hand-area{width:min(900px,100%);padding:clamp(6px,1.5cqh,16px)}.hand-label{font-size:clamp(10px,1.25cqw,17px)}
  .poker-paytable{gap:clamp(4px,.6cqh,8px) clamp(18px,2cqw,30px);padding:clamp(9px,1.2cqh,16px) clamp(14px,1.8cqw,24px);font-size:clamp(10px,1.35cqw,19px)}
  #sol-board{--sol-card:clamp(54px,min(8.5cqw,10.8cqh),98px);--sol-card-h:calc(var(--sol-card)*1.37);width:max-content;max-width:100%;grid-template-columns:calc(var(--sol-card)*2.25) auto;gap:clamp(12px,1.6cqw,24px);min-height:min(68cqh,700px)}
  .sol-tableau{grid-template-columns:repeat(7,var(--sol-card));gap:clamp(5px,.65cqw,10px)}.sol-column{min-height:min(58cqh,620px);padding:clamp(4px,.5cqw,8px)}
  .sol-card,.sol-back,.sol-empty{width:var(--sol-card);height:var(--sol-card-h)}.sol-card{font-size:clamp(17px,2cqw,30px)}.sol-suit{font-size:clamp(24px,3cqw,44px)}.sol-empty{font-size:clamp(25px,3cqw,44px)}
  .sol-stack+.sol-stack{margin-top:calc(var(--sol-card-h)*-.61)}.sol-stack.down+.sol-stack{margin-top:calc(var(--sol-card-h)*-.77)}.sol-label{font-size:clamp(10px,1.1cqw,16px)}
  /* v3.5.6: base all game measurements on usable content space, not the outer window. */
  #content{container-type:size}
  .game-shell{min-width:0;min-height:0;overflow:visible}
  .game-snake,.game-mines,.game-2048,.game-breakout,.game-ttt,.game-asteroids,.game-invaders,.game-reversi{justify-content:center}
  .game-title{flex:0 0 auto;font-size:clamp(19px,3.2cqw,42px)}
  .status{flex:0 0 auto;font-size:clamp(12px,1.8cqw,23px)}
  .help{flex:0 0 auto;max-width:92cqw;font-size:clamp(10px,1.4cqw,18px);line-height:1.3}
  .game-shell .action{flex:0 0 auto;font-size:clamp(11px,1.55cqw,19px)}
  #mine-grid{--mine-cell:clamp(24px,min(7.1cqw,8.1cqh),82px)}
  .game-2048 #grid2048{--tile-size:clamp(42px,min(15cqw,14cqh),150px)!important}
  #ttt-board{--ttt-cell:clamp(58px,min(20cqw,21cqh),210px)}
  .reversi-board{--rev-cell:clamp(27px,min(10cqw,9.4cqh),96px)}
  canvas{width:min(92cqw,calc((100cqh - 150px)*1.5));max-height:calc(100cqh - 150px)}
  .game-snake canvas{width:min(86cqw,calc((100cqh - 150px)*1.25))}
  .mode-grid{width:min(88cqw,980px);gap:clamp(12px,2.2cqw,30px)}
  .mode-card{min-height:clamp(150px,30cqh,310px);gap:clamp(9px,1.8cqh,20px);padding:clamp(16px,3cqw,34px)}
  .mode-card strong{font-size:clamp(20px,3cqw,38px)}.mode-card span{font-size:clamp(11px,1.55cqw,19px)}
  .board-name{font-size:clamp(11px,1.35cqw,18px)}
  .ability{font-size:clamp(11px,1.25cqw,17px)}
  .yahtzee-layout{display:grid;grid-template-columns:minmax(260px,1fr) minmax(270px,1fr);gap:clamp(10px,2cqw,24px);width:min(92cqw,1050px);min-height:0}.dice-area{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:clamp(10px,2cqh,20px)}.dice-row{display:flex;justify-content:center;gap:clamp(7px,1.2cqw,15px)}.die{width:clamp(48px,min(9cqw,12cqh),90px);aspect-ratio:1;padding:0;color:#111;background:#f4f0e8;border:3px solid #777;border-radius:16%;font-size:clamp(25px,5cqw,50px);font-weight:900;cursor:pointer;box-shadow:0 6px 12px #0008}.die.held{color:#fff;background:#8d2020;border-color:#ff5656;transform:translateY(-7px)}.yahtzee-card{display:grid;grid-template-columns:1fr auto;align-content:start;gap:3px 8px;min-height:0;padding:8px;background:#080808;border:1px solid #572020;border-radius:9px;overflow:auto}.score-choice{display:contents}.score-choice button{grid-column:1/-1;display:flex;justify-content:space-between;padding:clamp(4px,.7cqh,8px) clamp(7px,1cqw,12px);color:#ddd;background:#121212;border:1px solid #392020;border-radius:5px;cursor:pointer;font-size:clamp(10px,1.15cqw,15px)}.score-choice button:hover:not(:disabled){background:#491313}.score-choice button:disabled{color:#888;cursor:default}.score-total{display:flex;justify-content:space-between;grid-column:1/-1;padding:5px;color:#ff5555;font-weight:900;border-top:1px solid #572020}
  .match3-layout{display:flex;align-items:center;justify-content:center;gap:clamp(10px,2cqw,24px);width:100%;min-height:0}.match3-board{--gem:clamp(34px,min(8.4cqw,8.2cqh),78px);display:grid;grid-template-columns:repeat(8,var(--gem));gap:clamp(2px,.35cqw,5px);padding:clamp(5px,.8cqw,10px);background:#090909;border:2px solid #652020;border-radius:12px}.gem{width:var(--gem);height:var(--gem);padding:0;border:2px solid #351818;border-radius:18%;cursor:pointer;font-size:calc(var(--gem)*.55);line-height:1;background:#171717;box-shadow:inset 0 0 12px #0008}.gem.selected{outline:4px solid #fff;transform:scale(.9)}.gem.g0{color:#ff3d55}.gem.g1{color:#48a7ff}.gem.g2{color:#4ee06f}.gem.g3{color:#ffd53c}.gem.g4{color:#be63ff}.gem.g5{color:#ff8d35}.gem.special{border-color:#fff;box-shadow:inset 0 0 12px #fff8,0 0 10px currentColor}.match3-side{display:flex;flex-direction:column;gap:10px;width:min(180px,22cqw)}
  @media(max-width:760px){.yahtzee-layout{grid-template-columns:1fr}.yahtzee-card{max-height:42cqh}.match3-layout{flex-direction:column}.match3-side{width:100%;flex-direction:row;justify-content:center;flex-wrap:wrap}}
  @media(max-width:700px){#content{padding:10px;overflow:auto;overflow-x:hidden}#menu{grid-template-columns:repeat(2,minmax(0,1fr));height:100%}.game-tile{padding:5px 7px}#grid2048{--tile-size:clamp(42px,min(13cqw,10cqh),55px)}.tile2048{font-size:18px}#sol-board{grid-template-columns:1fr;width:100%}.sol-tableau{grid-template-columns:repeat(7,minmax(42px,1fr))}}

  #arcade{inset:0!important;transform:none!important;width:100%!important;height:100%!important;min-width:0!important;min-height:0!important;max-width:none!important;max-height:none!important;aspect-ratio:auto!important;border:0;border-radius:0}
  header{cursor:default;touch-action:auto;padding:12px 16px;gap:10px;flex-wrap:wrap;flex-shrink:0}header:active{cursor:default}h1{font-size:clamp(19px,3vw,30px);letter-spacing:2px}#sub{font-size:11px}.top-button{min-height:40px;padding:8px 10px}.top-actions{gap:6px}
  #resize-handle{display:none}#content{padding:12px;overscroll-behavior:contain}#menu{height:auto;grid-template-columns:repeat(auto-fit,minmax(225px,1fr));grid-auto-rows:minmax(94px,auto);gap:10px}.game-tile{padding:13px;min-height:94px;grid-template-columns:42px 1fr}.game-name{font-size:17px}.blurb{font-size:12px;white-space:normal}.icon{font-size:32px}.game-shell{height:auto;min-height:100%;gap:10px}.help{font-size:12px;line-height:1.45;flex-shrink:0}.row{flex-wrap:wrap;justify-content:center}.action{min-height:42px}.status{font-size:14px}
  canvas{touch-action:none;max-width:100%;max-height:calc(100dvh - 275px);width:auto;height:auto;flex-shrink:1}.tablet-controls{display:flex;gap:9px;justify-content:center;flex-wrap:wrap;flex-shrink:0;width:100%;padding:5px}.tablet-key{min-width:64px;min-height:54px;padding:12px 17px;background:#251115;color:#fff;border:1px solid #dd3548;border-radius:12px;font-size:20px;font-weight:bold;touch-action:none;user-select:none}.tablet-key.active{background:#c52c3e;box-shadow:0 0 20px #ff394455}
  #mine-grid{--mine-cell:clamp(28px,min(8vw,7vh),48px)}.mode-card{min-height:90px}.leaderboard{font-size:14px}.leaderboard-table td{padding:10px}.breakout-setup{overflow:auto}
  @media(max-width:600px){#menu{grid-template-columns:repeat(2,minmax(0,1fr))}.game-tile{display:flex;flex-direction:column;align-items:flex-start;gap:7px}.game-name{font-size:15px}.blurb{font-size:11px}header{padding:9px 10px}#content{padding:8px}.top-button{font-size:12px}.sol-tableau{grid-template-columns:repeat(7,minmax(36px,1fr))}.mode-grid{grid-template-columns:1fr}.yahtzee-layout{grid-template-columns:1fr}.yahtzee-card{max-height:none}.match3-side{width:100%;flex-direction:row;flex-wrap:wrap}.tablet-key{min-width:54px}.game-shell{overflow:visible}}
</style>
<div id="backdrop"><section id="arcade" role="dialog" aria-modal="true" aria-label="Chaotyk Arcade">
  <header><div><h1>Chaotyk Arcade</h1><div id="sub">18 games · Offline · v1.0.1 <span style="color:#b6ff45;font-weight:bold">· UPDATE TEST ✓</span></div></div><div class="top-actions"><button id="leaderboard-button" class="top-button">Leaderboard</button><button id="menu-button" class="top-button">Menu</button><button id="close-button" class="top-button">×</button></div></header>
  <main id="content"></main><div id="resize-handle" title="Resize arcade"></div>
</section></div>`;
        document.documentElement.appendChild(host);
        root.getElementById('leaderboard-button').addEventListener('click', showLeaderboard);
        root.getElementById('menu-button').addEventListener('click', showMenu);
        root.getElementById('close-button').textContent = '⋮';
        root.getElementById('close-button').setAttribute('aria-label','App options');
        root.getElementById('close-button').addEventListener('click', () => window.ArcadeNative?.menu());
        root.getElementById('backdrop').addEventListener('click', event => { if (event.target.id === 'backdrop') closeArcade(); });

        showMenu();
    }

    function setupWindowControls() {
        const arcade = root.getElementById('arcade'), header = root.querySelector('header'), handle = root.getElementById('resize-handle');
        const saved = GM_getValue(WINDOW_LAYOUT_KEY, null);
        const clamp = (value, min, max) => Math.min(Math.max(value, min), Math.max(min, max));
        let baseWidth, baseHeight, maxScale;
        const measureBase = () => {
            baseWidth = baseHeight = Math.min(560, window.innerWidth - 8, window.innerHeight - 8);
            maxScale = Math.max(1, (Math.min(window.innerWidth, window.innerHeight) - 8) / baseWidth);
        };
        measureBase();
        let scale = clamp(Number(saved?.scale) || 1, 1, maxScale);
        const width = baseWidth * scale, height = baseHeight * scale;
        const left = clamp(Number(saved?.left) || (window.innerWidth - width) / 2, 4, window.innerWidth - width - 4);
        const top = clamp(Number(saved?.top) || (window.innerHeight - height) / 2, 4, window.innerHeight - height - 4);
        Object.assign(arcade.style, { width: `${width}px`, height: `${height}px`, left: `${left}px`, top: `${top}px`, transform: 'none' });

        let drag = null, resizing = null, saveTimer = null;
        const constrain = () => {
            const rect = arcade.getBoundingClientRect();
            scale = clamp(scale, 1, maxScale);
            const w = baseWidth * scale, h = baseHeight * scale;
            const x = clamp(rect.left, 4, window.innerWidth - w - 4), y = clamp(rect.top, 4, window.innerHeight - h - 4);
            Object.assign(arcade.style, { width: `${w}px`, height: `${h}px`, left: `${x}px`, top: `${y}px`, transform: 'none' });
            if (!currentGame) { const content = root.getElementById('content'); content.scrollLeft = 0; content.scrollTop = 0; }
        };
        const save = () => {
            clearTimeout(saveTimer);
            saveTimer = setTimeout(() => { const r = arcade.getBoundingClientRect(); GM_setValue(WINDOW_LAYOUT_KEY, { scale, left: r.left, top: r.top }); }, 120);
        };
        const pointerDown = event => {
            if (event.button !== 0 || event.target.closest('button')) return;
            const rect = arcade.getBoundingClientRect();
            drag = { x: event.clientX, y: event.clientY, left: rect.left, top: rect.top };
            header.setPointerCapture?.(event.pointerId);
            event.preventDefault();
        };
        const pointerMove = event => {
            if (drag) {
                const rect = arcade.getBoundingClientRect();
                const x = clamp(drag.left + event.clientX - drag.x, 4, window.innerWidth - rect.width - 4);
                const y = clamp(drag.top + event.clientY - drag.y, 4, window.innerHeight - rect.height - 4);
                arcade.style.left = `${x}px`; arcade.style.top = `${y}px`;
            } else if (resizing) {
                const dx = (event.clientX - resizing.x) / baseWidth, dy = (event.clientY - resizing.y) / baseHeight;
                scale = clamp(resizing.scale + (Math.abs(dx) >= Math.abs(dy) ? dx : dy), 1, maxScale);
                constrain();
            }
        };
        const resizeDown = event => { if (event.button !== 0) return; resizing = { x: event.clientX, y: event.clientY, scale }; handle.setPointerCapture?.(event.pointerId); event.preventDefault(); event.stopPropagation(); };
        const pointerUp = () => { if (drag || resizing) { drag = resizing = null; save(); } };
        const viewportResized = () => { measureBase(); constrain(); save(); };
        header.addEventListener('pointerdown', pointerDown);
        handle.addEventListener('pointerdown', resizeDown);
        window.addEventListener('pointermove', pointerMove, true);
        window.addEventListener('pointerup', pointerUp, true);
        window.addEventListener('pointercancel', pointerUp, true);
        window.addEventListener('resize', viewportResized);
        cleanupWindow = () => { clearTimeout(saveTimer); header.removeEventListener('pointerdown', pointerDown); handle.removeEventListener('pointerdown', resizeDown); window.removeEventListener('pointermove', pointerMove, true); window.removeEventListener('pointerup', pointerUp, true); window.removeEventListener('pointercancel', pointerUp, true); window.removeEventListener('resize', viewportResized); };
    }

    function closeArcade() { window.ArcadeNative?.exit(); return;

        cleanupTouch();
        cleanupGame();
        cleanupGame = () => {};
        cleanupWindow();
        cleanupWindow = () => {};
        host?.remove();
        host = null;
        root = null;
        currentGame = null;
        document.body.style.overflow = previousOverflow;
    }

    function showMenu() {
        cleanupTouch();
        cleanupGame();
        cleanupGame = () => {};
        currentGame = null;
        const content = root.getElementById('content');
        content.innerHTML = `<div id="menu">${games.map(game => `<button class="game-tile" data-game="${game.id}"><span class="icon">${game.icon}</span><span><span class="game-name">${game.name}</span><span class="blurb">${game.blurb}</span></span></button>`).join('')}</div>`;
        content.querySelectorAll('.game-tile').forEach(button => button.addEventListener('click', () => launch(button.dataset.game)));
    }

    function showLeaderboard() {
        cleanupTouch();
        cleanupGame();
        cleanupGame = () => {};
        currentGame = 'leaderboard';
        const board = loadLeaderboard();
        const rows = resultRows.map(([key, name]) => `<tr><td>${name}</td><td>${String(board[key]?.label || 'No result yet').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}</td></tr>`).join('');
        root.getElementById('content').innerHTML = `<section class="leaderboard"><h2>Leaderboard</h2><table class="leaderboard-table"><thead><tr><th>Game</th><th>Best Result</th></tr></thead><tbody>${rows}</tbody></table><div class="leaderboard-actions"><button class="action" id="export-results">Export</button><button class="action" id="import-results">Import</button><button class="action" id="reset-results">Reset</button><input class="leaderboard-file" id="import-file" type="file" accept="application/json,.json"></div></section>`;
        root.getElementById('export-results').onclick = exportLeaderboard;
        root.getElementById('import-results').onclick = () => window.ArcadeNative ? window.ArcadeNative.importScores() : root.getElementById('import-file').click();
        root.getElementById('import-file').onchange = importLeaderboard;
        root.getElementById('reset-results').onclick = () => { if (confirm('Reset every Chaotyk Arcade leaderboard result?')) { saveLeaderboard({}); showLeaderboard(); } };
    }

    function exportLeaderboard() {
        if(window.ArcadeNative){window.ArcadeNative.exportScores(JSON.stringify({version:3,exported:new Date().toISOString(),results:loadLeaderboard()},null,2));return;}
        const blob = new Blob([JSON.stringify({ version: 3, exported: new Date().toISOString(), results: loadLeaderboard() }, null, 2)], { type: 'application/json' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `chaotyk-arcade-leaderboard-${new Date().toISOString().slice(0, 10)}.json`;
        link.click();
        setTimeout(() => URL.revokeObjectURL(link.href), 1000);
    }

    function importLeaderboard(event) {
        const file = event.target.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => {
            try {
                const parsed = JSON.parse(reader.result);
                const results = parsed?.results || parsed;
                if (!results || typeof results !== 'object' || Array.isArray(results)) throw new Error('Invalid leaderboard data');
                saveLeaderboard(results);
                showLeaderboard();
            } catch (error) { alert(`Could not import leaderboard: ${error.message}`); }
        };
        reader.readAsText(file);
    }

    function launch(id) {
        if (!root) return;
        cleanupTouch();
        cleanupGame();
        cleanupGame = () => {};
        currentGame = id;
        const game = games.find(item => item.id === id);
        if (id === 'layuplaunch') { layupLaunchGame(); return; }
        if (id === 'chainpanic') { chooseChainPanicMode(); return; }
        if (id === 'breakout') { chooseBreakoutMode(); return; }
        if (game?.modes || id === '2048') chooseMode(game);
        else { currentMode = 'original'; ({ solitaire: solitaireGame, snake: snakeGame, mines: minesGame, breakout: breakoutGame, ttt: tttGame, chess: chessGame, poker: videoPokerGame })[id](); }
    }

    function chooseMode(game) {
        shell(game.name, `<div class="mode-grid"><button class="mode-card" data-mode="original"><strong>Original Mode</strong><span>Traditional rules and familiar gameplay.</span></button><button class="mode-card chaotyk" data-mode="chaotyk"><strong>Chaotyk Mode</strong><span>Power-ups, abilities, special events, and surprises.</span></button></div>`, 'Choose a mode. You can return here from the arcade menu at any time.');
        root.querySelectorAll('.mode-card').forEach(button => button.addEventListener('click', () => { currentMode = button.dataset.mode; ({ '2048': game2048, asteroids: asteroidsGame, invaders: invadersGame, reversi: reversiGame, battleship: battleshipGame, blackjack: blackjackGame, rummy: rummyGame, yahtzee: yahtzeeGame, match3: match3Game })[game.id](currentMode === 'chaotyk'); }));
    }

    function shell(title, body, help = '') {
        root.getElementById('content').innerHTML = `<div class="game-shell game-${currentGame || 'generic'}"><div class="game-title">${title}</div>${body}<div class="help">${help}</div></div>`;
    }


    function layupLaunchGame(){const arcadeRoot=root;

let closeGame=null;const previous=document.activeElement,host=document.createElement('div');host.id='layup-launch-host';host.style.cssText='display:block;width:100%;height:100%;min-height:310px;background:#080f1b';const gameRoot=host.attachShadow({mode:'open'});
gameRoot.innerHTML=`<style>*{box-sizing:border-box}section{height:100%;display:flex;flex-direction:column;color:#e8f5ff;background:#07121e;font:14px system-ui,sans-serif}header{display:flex;align-items:center;flex-wrap:wrap;gap:10px;padding:7px 9px;background:#101e2d;border-bottom:1px solid #34516a}strong{letter-spacing:2px;color:#ffb766}small{color:#a2b8ca}#stats{flex:1;text-align:center;font-variant-numeric:tabular-nums}button{min-height:38px;padding:8px 13px;border:1px solid #45647f;background:#172d40;color:white;border-radius:8px;cursor:pointer;font:600 13px system-ui}button:hover{filter:brightness(1.2)}button:disabled{opacity:.4;cursor:default}.primary{background:#ffb766;color:#142300;border-color:#ffb766}#controls{display:flex;justify-content:center;align-items:center;gap:8px;flex-wrap:wrap;padding:8px;background:#0e1c2b;border-top:1px solid #34516a}label{display:flex;align-items:center;gap:8px}input{accent-color:#ffb766;width:110px;min-height:32px}output{min-width:42px;font-variant-numeric:tabular-nums}main{position:relative;flex:1;min-height:0;overflow:hidden}canvas{display:block;width:100%;height:100%;touch-action:none;user-select:none}#screen{position:absolute;inset:0;background:#050d18b8;display:grid;place-items:center;padding:16px}#screen[hidden]{display:none}article{width:550px;max-width:100%;max-height:100%;overflow:auto;background:#102538;border:1px solid #416a84;border-radius:18px;padding:26px;box-shadow:0 20px 80px #0008}h1{margin:0;color:#ffb766;font-size:27px;letter-spacing:2px}p{color:#c1d7e6;line-height:1.6}.modes{display:grid;grid-template-columns:1fr 1fr;gap:12px}.modes button{min-height:100px;line-height:1.5}.modes b{display:block;color:#ffb766;font-size:18px}.modes span{font-size:12px;color:#c1d7e6}footer{padding:8px 16px;color:#c6d8e6;font-size:12px;min-height:32px;background:#0d1927}@media(max-width:1000px){header{padding:6px 9px;gap:7px;font-size:12px}small{display:none}#controls{gap:7px;padding:6px}label{font-size:12px;gap:5px}input{width:100px}article{padding:18px}h1{font-size:26px}}</style>
<section><header><strong>LAYUP LAUNCH</strong><small>CHAOTYK · ARCADE</small><span id="stats"></span><button id="sound">Sound: on</button><button id="pause">Pause</button><button id="expand">Expand</button><button id="new">Modes</button><button id="exit">Arcade menu</button></header><main><canvas tabindex="0" aria-label="Layup Launch game board"></canvas><div id="screen"><article id="card"></article></div></main><div id="controls"><label>Angle <input id="angle" type="range" min="35" max="85" step="1" value="68"><output id="angleValue">68°</output></label><label>Power <input id="power" type="range" min="35" max="100" step="1" value="90"><output id="powerValue">90%</output></label><button id="fire" class="primary">Launch ball</button></div><footer id="note"></footer></section>`;arcadeRoot.getElementById('content').replaceChildren(host);
const arcadeWindow=arcadeRoot.getElementById('arcade'),originalWindowStyle=arcadeWindow.style.cssText;let expanded=false;
function expandWindow(){Object.assign(arcadeWindow.style,{left:'8px',top:'8px',transform:'none',width:'calc(100vw - 16px)',height:'calc(100dvh - 16px)',minWidth:'0',minHeight:'0',maxWidth:'none',maxHeight:'none',aspectRatio:'auto'});}
function restoreWindow(){arcadeWindow.style.cssText=originalWindowStyle;const r=arcadeWindow.getBoundingClientRect();arcadeWindow.style.left=Math.max(4,Math.min(r.left,innerWidth-r.width-4))+'px';arcadeWindow.style.top=Math.max(4,Math.min(r.top,innerHeight-r.height-4))+'px';}
const onCourtResize=()=>{if(expanded)expandWindow();};addEventListener('resize',onCourtResize);
const $=id=>gameRoot.getElementById(id),canvas=gameRoot.querySelector('canvas'),ctx=canvas.getContext('2d');
const W=1100,H=820,BX=460,BY=205,BW=560,BOTTOM=650,CUPBOTTOM=744,G=700,R=10,anchor={x:150,y:710},values=[5,5,10,20,10,5,5];
let state='menu',mode='original',bumpers=[],ball=null,score=0,used=0,best=0,angle=68,power=90,drag=null,trail=[],sparks=[],popups=[],flashBucket=-1,flashTime=0,delay=0,flight=0,still=0,raf=0,last=0,acc=0,dead=false,muted=false,audio=null,layoutNo=0;
function note(s){$('note').textContent=s;}
function beep(freq=400,d=.07){if(muted)return;try{audio||=new(window.AudioContext||window.webkitAudioContext)();audio.resume().catch(()=>{});const o=audio.createOscillator(),g=audio.createGain();o.frequency.setValueAtTime(freq,audio.currentTime);g.gain.setValueAtTime(.035,audio.currentTime);g.gain.exponentialRampToValueAtTime(.001,audio.currentTime+d);o.connect(g);g.connect(audio.destination);o.start();o.stop(audio.currentTime+d);}catch{}}
function segment(x,y,length,a){return{x1:x-Math.cos(a)*length/2,y1:y-Math.sin(a)*length/2,x2:x+Math.cos(a)*length/2,y2:y+Math.sin(a)*length/2};}
function randomBoard(){bumpers=[];for(let row=0;row<5;row++)for(let col=0;col<4;col++){const x=BX+70+col*135+(Math.random()-.5)*32,y=BY+52+row*77+(Math.random()-.5)*20;const a=(Math.random()-.5)*2.1;const length=48+Math.random()*25;bumpers.push({...segment(x,y,length,a),hit:0});}layoutNo++;}
function controls(){const enabled=state==='aim';$('angle').disabled=$('power').disabled=$('fire').disabled=!enabled;$('angle').value=angle;$('power').value=power;$('angleValue').textContent=Math.round(angle)+'°';$('powerValue').textContent=Math.round(power)+'%';}
function start(which){mode=which;score=0;used=0;ball=null;trail=[];sparks=[];popups=[];flashTime=0;drag=null;angle=68;power=90;state='aim';randomBoard();currentMode=mode;best=loadLeaderboard()['layuplaunch:'+mode]?.value||0;$('screen').hidden=true;$('pause').textContent='Pause';controls();note('Drag back from the launcher and release, or adjust angle and power then tap Launch. Clear the board’s open top!');canvas.focus();}
function menu(){state='menu';ball=null;drag=null;controls();$('screen').hidden=false;$('card').innerHTML=`<h1>LAYUP LAUNCH</h1><p>Launch from the bottom left, arc over the board, then bounce into a scoring pocket. Ten balls. Every shot counts.</p><div class="modes"><button id="original"><b>Original</b><span>Fresh random board each game. Same layout for all ten shots.</span></button><button id="chaotyk"><b>Chaotyk</b><span>Fresh layout between shots. Bumpers stay still while the ball moves.</span></button></div><p>Drag back from the glowing launcher to aim and set power. Release to fire. You can also use the sliders and Launch button. Center pocket = 20 points; misses = 0.</p>`;$('original').onclick=()=>{beep();start('original');};$('chaotyk').onclick=()=>{beep();start('chaotyk');};note('Ten shots · Mouse or touch · P pauses · Expand for a bigger court');}
function velocity(){const a=angle*Math.PI/180,speed=500+power*5.5;return{vx:Math.cos(a)*speed,vy:-Math.sin(a)*speed};}
function launch(){if(state!=='aim')return;const v=velocity();ball={x:anchor.x,y:anchor.y,...v,entered:false};used++;flight=0;still=0;trail=[];state='flight';drag=null;controls();note('Ball '+used+' of 10 · '+(mode==='chaotyk'?'Bumpers locked until this shot ends.':'Same board—learn the ricochets.'));beep(220,.12);canvas.focus();}
function award(index){if(state!=='flight')return;const pts=index>=0?values[index]:0;score+=pts;flashBucket=index;flashTime=1.2;popups.push({x:index>=0?BX+(index+.5)*BW/7:ball.x,y:index>=0?BOTTOM+55:Math.min(H-40,ball.y),label:pts?'+'+pts:'MISS',life:1.3});ball=null;state='settle';delay=1.25;note(pts?'Pocket scored: +'+pts+' points.':'Miss—no points for this ball.');beep(pts?350+pts*25:130,.15);controls();}
function next(){if(used>=10){state='over';if(score>best){best=score;recordBest('layuplaunch:'+mode,best,best+' points');}$('screen').hidden=false;$('card').innerHTML=`<h1>ROUND COMPLETE</h1><h2>${score} points</h2><p>${mode==='chaotyk'?'Chaotyk':'Original'} · 10 balls · Best: ${best}</p><button class="primary" id="again">Play again</button> <button id="choose">Choose mode</button>`;$('again').onclick=()=>start(mode);$('choose').onclick=menu;controls();return;}if(mode==='chaotyk'){randomBoard();note('Board reshuffled. Line up your next shot.');}else note('Next ball ready. Same board, another chance at the 20.');state='aim';trail=[];controls();}
function bounce(b,s,restitution=.64,fx=true){const dx=s.x2-s.x1,dy=s.y2-s.y1,len2=dx*dx+dy*dy,t=Math.max(0,Math.min(1,((b.x-s.x1)*dx+(b.y-s.y1)*dy)/len2)),px=s.x1+t*dx,py=s.y1+t*dy,nx=b.x-px,ny=b.y-py,d=Math.hypot(nx,ny),radius=R+3;if(d>=radius)return;let ux=d>1e-6?nx/d:-dy/Math.sqrt(len2),uy=d>1e-6?ny/d:dx/Math.sqrt(len2);const v=b.vx*ux+b.vy*uy;if(v>0&&d<1e-6){ux=-ux;uy=-uy;}b.x=px+ux*(radius+.05);b.y=py+uy*(radius+.05);const vn=b.vx*ux+b.vy*uy;if(vn<0){b.vx-=(1+restitution)*vn*ux;b.vy-=(1+restitution)*vn*uy;b.vx*=.995;b.vy*=.995;if(fx&&Math.abs(vn)>30){s.hit=.2;beep(Math.min(1100,280+Math.abs(vn)*.4),.035);for(let i=0;i<5;i++)sparks.push({x:px,y:py,vx:(Math.random()-.5)*150,vy:(Math.random()-.5)*150,life:.25});}}}
function physics(b,dt,fx=true){b.vy+=G*dt;b.x+=b.vx*dt;b.y+=b.vy*dt;for(const s of bumpers)bounce(b,s,.64,fx);for(const x of[BX,BX+BW])bounce(b,{x1:x,y1:BY,x2:x,y2:CUPBOTTOM},.55,fx);for(let i=1;i<7;i++)bounce(b,{x1:BX+i*BW/7,y1:BOTTOM+16,x2:BX+i*BW/7,y2:CUPBOTTOM},.35,fx);if(b.x>BX+R&&b.x<BX+BW-R&&b.y>BY&&b.y<BOTTOM)b.entered=true;}
function step(dt){if(state==='flight'){flight+=dt;physics(ball,dt);trail.push({x:ball.x,y:ball.y});if(trail.length>110)trail.shift();if(ball.y>CUPBOTTOM-R&&ball.x>BX&&ball.x<BX+BW&&ball.entered){award(Math.min(6,Math.floor((ball.x-BX)/(BW/7))));return;}if(ball.y>H+R||ball.x<-100||ball.x>W+150||flight>22){award(-1);return;}if(Math.hypot(ball.vx,ball.vy)<20&&ball.entered){still+=dt;if(still>.8){ball.vx+=(ball.x%2<1?-1:1)*35;ball.vy-=45;still=0;}}else still=0;}else if(state==='settle'){delay-=dt;if(delay<=0)next();}}
function point(e){const b=canvas.getBoundingClientRect(),s=Math.min(b.width/W,b.height/H);return{x:(e.clientX-b.left-(b.width-W*s)/2)/s,y:(e.clientY-b.top-(b.height-H*s)/2)/s};}
function aim(e){if(!drag||e.pointerId!==drag.id)return;const p=point(e),dx=anchor.x-p.x,dy=anchor.y-p.y,d=Math.hypot(dx,dy);drag.distance=d;if(d<8)return;angle=Math.max(35,Math.min(85,Math.atan2(Math.max(1,-dy),Math.max(1,dx))*180/Math.PI));power=Math.round(Math.max(35,Math.min(100,d/150*100)));drag.x=p.x;drag.y=p.y;controls();}
canvas.addEventListener('pointerdown',e=>{if(state!=='aim'||e.button!==0||drag)return;const p=point(e);if(Math.hypot(p.x-anchor.x,p.y-anchor.y)>95){note('Drag back from the glowing launcher at bottom left—or use the sliders.');return;}e.preventDefault();drag={id:e.pointerId,x:p.x,y:p.y,distance:0};canvas.setPointerCapture(e.pointerId);});canvas.addEventListener('pointermove',aim);canvas.addEventListener('pointerup',e=>{if(!drag||e.pointerId!==drag.id)return;aim(e);const fire=drag.distance>12;drag=null;if(fire)launch();});canvas.addEventListener('pointercancel',()=>drag=null);canvas.addEventListener('lostpointercapture',()=>drag=null);canvas.addEventListener('contextmenu',e=>e.preventDefault());
$('angle').oninput=()=>{angle=Number($('angle').value);controls();};$('power').oninput=()=>{power=Number($('power').value);controls();};$('fire').onclick=launch;$('new').onclick=menu;
let beforePause=null;function pause(){if(['flight','settle','aim'].includes(state)){beforePause=state;state='paused';drag=null;$('pause').textContent='Resume';controls();}else if(state==='paused'){state=beforePause;$('pause').textContent='Pause';controls();}}
$('expand').style.display='none';$('expand').onclick=()=>{expanded=!expanded;if(expanded)expandWindow();else restoreWindow();$('expand').textContent=expanded?'Shrink':'Expand';};$('pause').onclick=pause;$('sound').onclick=()=>{muted=!muted;$('sound').textContent='Sound: '+(muted?'off':'on');};$('exit').onclick=showMenu;const key=e=>{if(e.code==='Escape'){e.preventDefault();closeGame();}else if(e.code==='KeyP'&&!e.repeat){e.preventDefault();pause();}};gameRoot.addEventListener('keydown',key);const blur=()=>{drag=null;if(['aim','flight','settle'].includes(state))pause();};const hidden=()=>{if(document.hidden)blur();};addEventListener('blur',blur);document.addEventListener('visibilitychange',hidden);
closeGame=()=>{dead=true;cancelAnimationFrame(raf);removeEventListener('blur',blur);document.removeEventListener('visibilitychange',hidden);audio?.close().catch(()=>{});host.remove();removeEventListener('resize',onCourtResize);restoreWindow();closeGame=null;previous?.focus?.({preventScroll:true});};
function circle(x,y,r,c){ctx.fillStyle=c;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();}
function line(x1,y1,x2,y2,c,width=3){ctx.strokeStyle=c;ctx.lineWidth=width;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();}
function basketball(x,y,r,alpha=1){ctx.save();ctx.globalAlpha=alpha;ctx.shadowColor='#ff8a35';ctx.shadowBlur=12;const grad=ctx.createRadialGradient(x-r*.35,y-r*.4,r*.1,x,y,r);grad.addColorStop(0,'#ffd295');grad.addColorStop(.45,'#f58c34');grad.addColorStop(1,'#b94b16');circle(x,y,r,grad);ctx.shadowBlur=0;ctx.strokeStyle='#5c2b14';ctx.lineWidth=Math.max(1,r*.12);ctx.beginPath();ctx.moveTo(x-r,y);ctx.lineTo(x+r,y);ctx.moveTo(x,y-r);ctx.lineTo(x,y+r);ctx.stroke();ctx.beginPath();ctx.ellipse(x,y,r*.45,r,0,0,Math.PI*2);ctx.stroke();ctx.restore();}
function render(){
const box=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2),w=Math.max(1,Math.round(box.width*dpr)),h=Math.max(1,Math.round(box.height*dpr));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#080e19';ctx.fillRect(0,0,w,h);const scale=Math.min(w/W,h/H);ctx.translate((w-W*scale)/2,(h-H*scale)/2);ctx.scale(scale,scale);
const bg=ctx.createLinearGradient(0,0,W,H);bg.addColorStop(0,'#14273d');bg.addColorStop(1,'#080e18');ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
// Stadium light beams and an understated parquet apron.
ctx.fillStyle='#d6e9ff05';for(let i=0;i<5;i++){ctx.beginPath();ctx.moveTo(i*270,0);ctx.lineTo(i*270-120,H);ctx.lineTo(i*270+230,H);ctx.fill();}
ctx.fillStyle='#784b31';ctx.fillRect(0,760,W,60);for(let x=0;x<W;x+=110){ctx.fillStyle=x%220?'#8b593a':'#805033';ctx.fillRect(x,760,109,60);line(x,760,x,820,'#b17b4b',1);}line(0,760,W,760,'#c59363',2);
// Large in-arena scoreboard.
ctx.fillStyle='#050a12';ctx.fillRect(405,36,620,100);ctx.strokeStyle='#405b78';ctx.lineWidth=2;ctx.strokeRect(405,36,620,100);ctx.textAlign='center';ctx.font='bold 13px system-ui';ctx.fillStyle='#8da6bd';ctx.fillText('TOTAL POINTS',510,64);ctx.fillText('SHOTS REMAINING',726,64);ctx.fillText('PERSONAL BEST',930,64);ctx.font='bold 43px monospace';ctx.fillStyle='#ffc577';ctx.fillText(String(score).padStart(3,'0'),510,112);ctx.fillStyle='#ebf6ff';ctx.fillText(String(10-used).padStart(2,'0'),726,112);ctx.font='bold 32px monospace';ctx.fillStyle='#89c9e6';ctx.fillText(best,930,109);ctx.textAlign='left';
ctx.fillStyle='#ffd09b';ctx.font='900 32px system-ui';ctx.fillText('LAYUP',48,70);ctx.fillText('LAUNCH',48,107);ctx.font='bold 12px system-ui';ctx.fillStyle='#8da6bd';ctx.fillText(mode==='chaotyk'?'CHAOTYK COURT':'ORIGINAL COURT',50,137);
// The board remains physically identical to the test: open at the top.
ctx.shadowColor='#000';ctx.shadowBlur=22;ctx.fillStyle='#19354a';ctx.fillRect(BX-8,BY-2,BW+16,CUPBOTTOM-BY+14);ctx.shadowBlur=0;const panel=ctx.createLinearGradient(BX,BY,BX+BW,BOTTOM);panel.addColorStop(0,'#244b62');panel.addColorStop(1,'#12293b');ctx.fillStyle=panel;ctx.fillRect(BX,BY,BW,BOTTOM-BY);ctx.save();ctx.beginPath();ctx.rect(BX,BY,BW,BOTTOM-BY);ctx.clip();ctx.strokeStyle='#b3dbed0d';ctx.lineWidth=1;for(let x=BX;x<BX+BW;x+=40){ctx.beginPath();ctx.moveTo(x,BY);ctx.lineTo(x,BOTTOM);ctx.stroke();}for(let y=BY;y<BOTTOM;y+=40){ctx.beginPath();ctx.moveTo(BX,y);ctx.lineTo(BX+BW,y);ctx.stroke();}ctx.restore();
ctx.fillStyle='#a8d1e4';ctx.font='bold 13px system-ui';ctx.textAlign='center';ctx.fillText('ARC OVER THE TOP • FIND YOUR LINE',BX+BW/2,BY-22);ctx.textAlign='left';line(BX,BY,BX,CUPBOTTOM,'#638aa2',9);line(BX+BW,BY,BX+BW,CUPBOTTOM,'#638aa2',9);
for(const b of bumpers){line(b.x1+2,b.y1+4,b.x2+2,b.y2+4,'#07111c',10);ctx.shadowBlur=b.hit>0?20:0;ctx.shadowColor='#ffd181';line(b.x1,b.y1,b.x2,b.y2,b.hit>0?'#fff1c9':'#eea75a',7);ctx.shadowBlur=0;circle((b.x1+b.x2)/2,(b.y1+b.y2)/2,4,'#59768c');circle((b.x1+b.x2)/2,(b.y1+b.y2)/2,1.5,'#d5e5ef');}
const cw=BW/7;for(let i=0;i<7;i++){const active=flashTime>0&&flashBucket===i,x=BX+i*cw;ctx.fillStyle=active?'#8c6036':i===3?'#394824':'#102131';ctx.fillRect(x+3,BOTTOM+18,cw-6,CUPBOTTOM-BOTTOM-18);ctx.fillStyle=active?'#ffde97':i===3?'#c8ed77':'#d0e1ee';ctx.font='900 24px system-ui';ctx.textAlign='center';ctx.fillText(values[i],x+cw/2,BOTTOM+3);
// Distinct miniature rims and netting, with no change to collision geometry.
ctx.strokeStyle=active?'#fff1ce':'#d0e0ee77';ctx.lineWidth=1.2;for(let n=0;n<4;n++){ctx.beginPath();ctx.moveTo(x+8+n*16,BOTTOM+25);ctx.lineTo(x+16+n*12,CUPBOTTOM-10);ctx.stroke();}for(let n=0;n<4;n++){ctx.beginPath();ctx.moveTo(x+8,BOTTOM+30+n*15);ctx.lineTo(x+cw-8,BOTTOM+30+n*15);ctx.stroke();}line(x+7,BOTTOM+20,x+cw-7,BOTTOM+20,active?'#ffe8b8':'#f38e43',5);if(i>0)line(x,BOTTOM+16,x,CUPBOTTOM,'#63839a',4);}ctx.textAlign='left';line(BX,CUPBOTTOM,BX+BW,CUPBOTTOM,'#63839a',5);
// Launch pedestal, angle dial and a recognizable basketball.
ctx.strokeStyle='#82a8c333';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(anchor.x,anchor.y+38,85,22,0,0,Math.PI*2);ctx.stroke();line(anchor.x-42,anchor.y+35,anchor.x-16,anchor.y-24,'#8fb0c6',12);line(anchor.x+42,anchor.y+35,anchor.x+16,anchor.y-24,'#8fb0c6',12);ctx.fillStyle='#d4e4f0';ctx.font='bold 14px system-ui';ctx.textAlign='center';ctx.fillText('PULL BACK & RELEASE',anchor.x,anchor.y+76);ctx.textAlign='left';
if(state==='aim'){const v=velocity(),preview={x:anchor.x,y:anchor.y,...v};ctx.globalAlpha=.65;for(let i=0;i<110;i++){preview.vy+=G*.018;preview.x+=preview.vx*.018;preview.y+=preview.vy*.018;if(preview.x>BX-R&&preview.y>BY-R||preview.x>W||preview.y>H||preview.y<0)break;if(i%4===0)circle(preview.x,preview.y,3,'#ffd199');}ctx.globalAlpha=1;if(drag){const d=Math.min(90,drag.distance),a=angle*Math.PI/180;line(anchor.x-16,anchor.y-24,anchor.x-Math.cos(a)*d,anchor.y+Math.sin(a)*d,'#d6b970',5);line(anchor.x+16,anchor.y-24,anchor.x-Math.cos(a)*d,anchor.y+Math.sin(a)*d,'#d6b970',5);}basketball(anchor.x,anchor.y,R+2);}
for(let i=0;i<trail.length;i+=3){ctx.globalAlpha=i/trail.length*.4;circle(trail[i].x,trail[i].y,3,'#ffc78a');}ctx.globalAlpha=1;if(ball)basketball(ball.x,ball.y,R);
for(const p of sparks){ctx.globalAlpha=Math.max(0,p.life*4);circle(p.x,p.y,2,'#ffdb9e');}ctx.globalAlpha=1;for(const p of popups){ctx.fillStyle=p.label==='MISS'?'#ff9d90':'#ffdc9c';ctx.font='bold 32px system-ui';ctx.textAlign='center';ctx.fillText(p.label,p.x,p.y-(1.3-p.life)*30);}ctx.textAlign='left';if(state==='paused'){ctx.fillStyle='#0009';ctx.fillRect(0,0,W,H);ctx.fillStyle='#ffbf73';ctx.font='bold 40px system-ui';ctx.textAlign='center';ctx.fillText('PAUSED',W/2,H/2);ctx.textAlign='left';}$('stats').textContent=(mode==='chaotyk'?'Chaotyk':'Original')+' · '+score+' pts · '+(10-used)+' balls';}

function frame(now){if(dead)return;const dt=last?Math.min(.05,(now-last)/1000):0;last=now;if(state!=='paused'){acc+=dt;while(acc>=1/240){step(1/240);acc-=1/240;}flashTime=Math.max(0,flashTime-dt);for(const b of bumpers)b.hit=Math.max(0,b.hit-dt);for(const p of sparks){p.x+=p.vx*dt;p.y+=p.vy*dt;p.life-=dt;}sparks=sparks.filter(p=>p.life>0);for(const p of popups)p.life-=dt;popups=popups.filter(p=>p.life>0);}render();raf=requestAnimationFrame(frame);}
cleanupGame=()=>{if(closeGame)closeGame();};
// TEST_HOOK
menu();raf=requestAnimationFrame(frame);
    }

    function chooseChainPanicMode(){
      shell('Chain Panic', '<div class="mode-grid" style="grid-template-columns:repeat(auto-fit,minmax(min(190px,100%),1fr));overflow:auto"><button class="mode-card" data-mode="original"><strong>Original Mode</strong><span>Catch, swing, throw, and bank growing clusters.</span></button><button class="mode-card chaotyk" data-mode="chaotyk"><strong>Chaotyk Mode</strong><span>Every fifth goal spawns a Gravitron. Grow it into a black hole for an uncapped multiplier.</span></button></div>', 'Mouse and tablet touch supported.');
      root.querySelectorAll('.mode-card').forEach(b=>b.onclick=()=>{currentMode=b.dataset.mode;chainPanicGame(currentMode==='chaotyk');});
    }
    function chainPanicGame(chaotyk){const arcadeRoot=root;

 const previous=document.activeElement;
 let closeGame=null;
 const host=document.createElement('div');host.id='chain-panic-host';host.style.cssText='display:block;width:100%;height:100%;min-height:300px;background:#060912;';
 const uiRoot=host.attachShadow({mode:'open'});
 uiRoot.innerHTML=`<style>*{box-sizing:border-box}section{height:100%;display:flex;flex-direction:column;background:#080d18;color:#edf5ff;font:14px system-ui,sans-serif}header{display:flex;align-items:center;gap:12px;padding:7px 9px;border-bottom:1px solid #26334a;flex-wrap:wrap}strong{letter-spacing:2px;color:#b9ff49}small{color:#9cacc4}button{background:#17243a;color:#fff;border:1px solid #425371;border-radius:7px;padding:9px 12px;min-height:42px;cursor:pointer;font:inherit}button:hover{background:#2a3d56}button.primary{background:#b9ff49;color:#101706;font-weight:800}#stats{flex:1;text-align:center;font-variant-numeric:tabular-nums}main{flex:1;min-height:0;position:relative;overflow:hidden}canvas{width:100%;height:100%;display:block;touch-action:none;-webkit-user-select:none;user-select:none}#menu{position:absolute;inset:0;display:grid;place-items:center;background:#050914aa;padding:18px}article{width:490px;max-width:100%;max-height:100%;overflow:auto;background:#101a2d;border:1px solid #40506a;border-radius:18px;padding:18px;box-shadow:0 20px 80px #0008}h1{font-size:26px;letter-spacing:2px;margin:0;color:#b9ff49}h2{font-size:20px}p{line-height:1.6;color:#bfcee1}li{margin:10px 0;line-height:1.45}b{color:#fff}footer{padding:9px 18px;color:#9cacc4;border-top:1px solid #26334a;font-size:12px}#menu[hidden]{display:none}@media(max-width:600px){header{padding:8px;font-size:12px}article{padding:18px}h1{font-size:27px}small{display:none}}</style>
 <section><header><strong>CHAIN PANIC</strong><small>CHAOTYK · ${chaotyk?'CHAOTYK MODE':'ORIGINAL'}</small><span id="stats"></span><button id="sound">Sound: on</button><button id="pause">Pause</button><button id="exit">Modes</button></header><main><canvas tabindex="0" aria-label="Chain Panic game arena"></canvas><div id="menu"><article id="card"></article></div></main><footer>Mouse / finger: steer · Hold: catch & swing · Release: throw · P: pause</footer></section>`;
 const arcadeContent=arcadeRoot.getElementById('content');arcadeContent.replaceChildren(host);
 const $=id=>uiRoot.getElementById(id),canvas=uiRoot.querySelector('canvas'),ctx=canvas.getContext('2d');
 let raf=0,dead=false,state='menu',last=0,acc=0,held=null,holding=false,angle=0,grabDelay=0,score=0,lives=3,best=0,goals=0,nextLifeScore=50000,activePointer=null,spawnClock=0,shake=0,toast='',toastTime=0,muted=false,audio=null;
 const W=1100,H=680,core={x:W/2,y:H/2},pointer={x:W/2,y:H/2},colors=['#5ce8ff','#bf8bff','#ffb14a','#70ff6a'],groups=[],particles=[],shockwaves=[],absorptions=[];
 best=loadLeaderboard()[modeKey('chainpanic')]?.value||0;
 function tone(freq=400,dur=.06){if(muted)return;try{audio ||= new (window.AudioContext||window.webkitAudioContext)();if(audio.state==='suspended')audio.resume();const o=audio.createOscillator(),g=audio.createGain();o.type='sine';o.frequency.setValueAtTime(freq,audio.currentTime);g.gain.setValueAtTime(.045,audio.currentTime);g.gain.exponentialRampToValueAtTime(.001,audio.currentTime+dur);o.connect(g);g.connect(audio.destination);o.start();o.stop(audio.currentTime+dur);}catch{}}
 function message(s){toast=s;toastTime=2;}
 function bits(x,y,c,n=14){for(let i=0;i<n;i++){let a=Math.random()*Math.PI*2,v=50+Math.random()*200;particles.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,life:.4+Math.random()*.5,c});}}
 function spawn(x,y){const type=Math.floor(Math.random()*3);groups.push({x:x??(45+Math.random()*(W-90)),y:y??(65+Math.random()*(H-130)),vx:(Math.random()-.5)*55,vy:(Math.random()-.5)*55,a:Math.random()*6.28,spin:(Math.random()-.5),parts:[{x:0,y:0,r:type===2?17:13,type}],heat:0,banks:0,thrown:false,catchGrace:0});}

 function spawnLifeBall(){const x=100+Math.random()*(W-200),y=100+Math.random()*(H-200);groups.push({x,y,vx:(Math.random()-.5)*55,vy:(Math.random()-.5)*55,a:0,spin:0,parts:[{x:0,y:0,r:11,type:3}],lifeCredits:1,heat:0,banks:0,thrown:false,catchGrace:0});bits(x,y,'#70ff6a',28);tone(1000,.18);}
 function lifeMilestones(){let added=0;if(chaotyk){while(score>=nextLifeScore){spawnLifeBall();nextLifeScore+=50000;added++;}}return added;}
 function value(g){return g.kind==='blackhole'?12:g.parts.length;}
 function mult(g){return g.kind==='blackhole'?1+(g.banks||0)+(g.eaten||0):1+Math.min(g.banks||0,5);}
 function reach(g){return g.kind==='blackhole'?300:100+g.parts.length*14;}
 function spawnGravitron(){const a=Math.random()*Math.PI*2;groups.push({kind:'gravitron',x:W/2,y:90,vx:Math.cos(a)*210,vy:Math.sin(a)*210,a:0,spin:1.5,parts:[{x:0,y:0,r:13,type:0}],heat:0,banks:0,thrown:true,catchGrace:.5,eaten:0});bits(W/2,90,'#df8cff',40);tone(130,.3);}
 function pack(g){g.parts.forEach((p,i)=>{if(!i){p.x=p.y=0;return;}const ring=i<=6?1:2,n=ring===1?6:12,k=ring===1?i-1:i-7,a=k/n*Math.PI*2+(ring===2?.26:0);p.x=Math.cos(a)*ring*23;p.y=Math.sin(a)*ring*23;});}
 function absorb(g,b){
  if(g===b||!groups.includes(g)||!groups.includes(b))return;
  const count=value(b),large=b.kind==='blackhole'||b.parts.length>1;
  g.lifeCredits=(g.lifeCredits||0)+(b.lifeCredits||0);
  if(g.kind==='blackhole'){
   const gain=b.kind==='blackhole'?mult(b):count+Math.max(0,mult(b)-1);
   g.eaten=(g.eaten||0)+gain;g.heat=Math.max(g.heat,b.heat||0)+count*1.5;
   if(large){absorptions.push({target:g,age:0,parts:b.parts.map(part=>({...world(b,part),r:part.r,c:b.kind==='blackhole'?'#c88aff':colors[part.type]}))});shake=Math.max(shake,9);message((b.kind==='blackhole'?'BLACK HOLES COMBINED!':'CLUSTER CONSUMED!')+' 12 ×'+mult(g));toastTime=2.5;bits(g.x,g.y,'#cf8aff',30);tone(85,.3);}
  }else{for(const part of b.parts){if(g.kind==='blackhole'){g.eaten++;continue;}g.parts.push({...part,x:0,y:0});if(g.parts.length>12){g.kind='blackhole';g.parts=[{x:0,y:0,r:13,type:0}];g.eaten=1;message('BLACK HOLE! 12-piece base · multiplier grows without a cap');bits(g.x,g.y,'#df8cff',50);tone(70,.35);}else pack(g);}g.heat+=count*2;}
  bits(b.x,b.y,'#df8cff',8);groups.splice(groups.indexOf(b),1);tone(Math.min(1600,440+mult(g)*12));
 }
 function gravity(dt){for(const g of [...groups]){
  if(!g.kind||!groups.includes(g))continue;
  for(const b of [...groups]){
   if(b===g||b===held||!groups.includes(b))continue;
   if(g.kind!=='blackhole'&&(b.kind||b.thrown||b.parts.length!==1))continue;
   // Resolve black-hole pairs once: held hole wins, then higher multiplier,
   // then stable array order. Removed bodies cannot absorb anything later.
   if(g.kind==='blackhole'&&b.kind==='blackhole'&&g!==held&&(mult(g)<mult(b)||mult(g)===mult(b)&&groups.indexOf(g)>groups.indexOf(b)))continue;
   const dx=g.x-b.x,dy=g.y-b.y,d=Math.hypot(dx,dy),r=reach(g);if(d>r)continue;
   if(d<radius(g)+radius(b)+6){absorb(g,b);continue;}
   const force=(g.kind==='blackhole'?1100:650)*(1-d/r)+180;b.vx+=dx/Math.max(1,d)*force*dt;b.vy+=dy/Math.max(1,d)*force*dt;
   const speed=Math.hypot(b.vx,b.vy);if(speed>500){b.vx*=500/speed;b.vy*=500/speed;}
  }
 }}

 function radius(g){if(g.kind==='blackhole')return 13;return Math.max(...g.parts.map(p=>Math.hypot(p.x,p.y)+p.r));}
 function world(g,p){const c=Math.cos(g.a),s=Math.sin(g.a);return {x:g.x+p.x*c-p.y*s,y:g.y+p.x*s+p.y*c};}
 function clearInput(){holding=false;activePointer=null;if(held)release();}
 function start(){groups.length=0;particles.length=0;shockwaves.length=0;absorptions.length=0;held=null;holding=false;score=0;goals=0;nextLifeScore=50000;lives=3;core.x=pointer.x=W/2;core.y=pointer.y=H/2;spawnClock=0;grabDelay=0;shake=0;state='play';$('menu').hidden=true;$('pause').textContent='Pause';for(let i=0;i<24;i++)spawn();message('Hold near a piece to catch it!');canvas.focus();tone(520);}
 function intro(){state='menu';$('menu').hidden=false;$('card').innerHTML=`<h1>CHAIN PANIC</h1><p>Build a wrecking ball. Bank it before it blows.</p><ol><li><b>Move</b> your mouse or drag your finger to steer your white energy core.</li><li><b>Hold left click / touch</b> near a piece to catch it. It swings automatically. The dotted line shows your throw direction.</li><li><b>Release</b> to throw. Hit loose pieces to glue them into a bigger, oddly shaped cluster.</li><li><b>Catch it again</b> to cool it down. Throw clusters of 2+ pieces through either glowing side gate to score.</li></ol><p>Cyan = normal · Purple = bouncy · Orange = heavy.<br>Wall rebounds multiply your payout. Every overheated burst costs one life—anywhere in the arena! Three lives · No time limit.</p><button class="primary" id="start">Start run</button><p>Best: ${best.toLocaleString()} · ${chaotyk?'Every fifth goal spawns a Gravitron. At 13 pieces it collapses into a black hole: 12-piece value, uncapped multiplier from wall bounces and swallowed pieces. Black holes swallow entire clusters and other black holes, combining their multipliers and carried lives. They still overheat! Every 50,000 points spawns a green life ball: collect it into a cluster and bank it for +1 life. Black holes can carry it too.':'Original rules: catch, swing, grow, bank.'}</p>`;$('start').onclick=start;}
 function finish(){state='over';clearInput();if(score>best)best=score;recordBest(modeKey('chainpanic'),score,score.toLocaleString()+' points');$('menu').hidden=false;$('card').innerHTML=`<h1>RUN COMPLETE</h1><p>All lives lost. Bank or cool clusters before they burst.</p><h2>${score.toLocaleString()} points</h2><p>Best: ${best.toLocaleString()}</p><button class="primary" id="again">One more run</button> <button id="help">How to play</button>`;$('again').onclick=start;$('help').onclick=intro;}
 function release(){if(!held)return;held.thrown=true;held.catchGrace=.45;held.vx=-Math.sin(angle)*440;held.vy=Math.cos(angle)*440;held.spin=3;bits(held.x,held.y,'#b9ff49',5);tone(240);held=null;grabDelay=.18;}
 function pause(){if(state==='play'){clearInput();state='paused';$('pause').textContent='Resume';}else if(state==='paused'){state='play';$('pause').textContent='Pause';}}
 function pos(e){const r=canvas.getBoundingClientRect(),scale=Math.min(r.width/W,r.height/H),ox=(r.width-W*scale)/2,oy=(r.height-H*scale)/2;pointer.x=Math.max(22,Math.min(W-22,(e.clientX-r.left-ox)/scale));pointer.y=Math.max(22,Math.min(H-22,(e.clientY-r.top-oy)/scale));}
 canvas.addEventListener('pointermove',e=>{if(activePointer===null&&e.pointerType==='mouse'||e.pointerId===activePointer)pos(e);});
 canvas.addEventListener('pointerdown',e=>{if(e.button!==0||state!=='play'||activePointer!==null)return;e.preventDefault();activePointer=e.pointerId;pos(e);holding=true;canvas.setPointerCapture(e.pointerId);tone(160,.02);});
 canvas.addEventListener('pointerup',e=>{if(e.pointerId!==activePointer)return;pos(e);holding=false;activePointer=null;release();try{canvas.releasePointerCapture(e.pointerId);}catch{}});
 canvas.addEventListener('pointercancel',e=>{if(e.pointerId===activePointer)clearInput();});canvas.addEventListener('lostpointercapture',e=>{if(e.pointerId===activePointer)clearInput();});canvas.addEventListener('contextmenu',e=>e.preventDefault());
 function key(e){if(e.code==='KeyP'&&!e.repeat){e.preventDefault();pause();}}
 uiRoot.addEventListener('keydown',key);const blur=()=>{if(state==='play')pause();};addEventListener('blur',blur);const visibility=()=>{if(document.hidden)blur();};document.addEventListener('visibilitychange',visibility);
 $('exit').onclick=()=>{cleanupGame();cleanupGame=()=>{};chooseChainPanicMode();};$('pause').onclick=pause;$('sound').onclick=()=>{muted=!muted;$('sound').textContent='Sound: '+(muted?'off':'on');};
 closeGame=()=>{dead=true;cancelAnimationFrame(raf);removeEventListener('blur',blur);document.removeEventListener('visibilitychange',visibility);host.remove();if(audio)audio.close().catch(()=>{});closeGame=null;previous?.focus?.({preventScroll:true});};
 function tick(dt){
 grabDelay-=dt;toastTime-=dt;shake=Math.max(0,shake-dt*35);spawnClock+=dt;gravity(dt);
 if(spawnClock>1.5&&groups.length<35){spawnClock=0;spawn();}
 core.x+=(pointer.x-core.x)*Math.min(1,dt*10);core.y+=(pointer.y-core.y)*Math.min(1,dt*10);
 if(holding&&!held&&grabDelay<=0){let target=null,distance=180;for(const g of groups){const d=Math.hypot(g.x-core.x,g.y-core.y);if(d<distance&&g.catchGrace<=0){target=g;distance=d;}}if(target){held=target;angle=Math.atan2(held.y-core.y,held.x-core.x);held.heat=Math.max(0,held.heat-25);tone(660);message('Caught! Release along the dotted line.');}}
 if(held){angle+=dt*3;const reach=85+Math.min(55,radius(held));held.x=Math.max(radius(held)+8,Math.min(W-radius(held)-8,core.x+Math.cos(angle)*reach));held.y=Math.max(radius(held)+8,Math.min(H-radius(held)-8,core.y+Math.sin(angle)*reach));held.a+=dt*2.5;held.heat=Math.max(0,held.heat-dt*16);}
 for(const g of [...groups]){
 if(!groups.includes(g))continue;g.catchGrace-=dt;
 if(g!==held){g.x+=g.vx*dt;g.y+=g.vy*dt;g.a+=g.spin*dt;const r=radius(g),gate=g.y>H/2-100&&g.y<H/2+100;
 if(g.thrown&&value(g)>=2&&gate&&(g.x-r<22||g.x+r>W-22)){
 const earned=value(g)*value(g)*10*mult(g);score+=earned;goals++;const awarded=chaotyk?(g.lifeCredits||0):0;lives+=awarded;const lifeSpawns=lifeMilestones();recordBest(modeKey('chainpanic'),score,score.toLocaleString()+' points');if(chaotyk&&goals%5===0)spawnGravitron();message('BANKED +'+earned+(awarded?' · +'+awarded+' LIFE'+(awarded===1?'':'S'):'')+(lifeSpawns?' · GREEN LIFE BALL SPAWNED!':''));bits(g.x,g.y,'#b9ff49',35);groups.splice(groups.indexOf(g),1);tone(880,.16);continue;}
 let bounced=false;if(g.x<r+18){g.x=r+18;g.vx=Math.abs(g.vx);bounced=true;}if(g.x>W-r-18){g.x=W-r-18;g.vx=-Math.abs(g.vx);bounced=true;}if(g.y<r+18){g.y=r+18;g.vy=Math.abs(g.vy);bounced=true;}if(g.y>H-r-18){g.y=H-r-18;g.vy=-Math.abs(g.vy);bounced=true;}
 if(bounced&&g.thrown){g.banks++;g.heat+=4;tone(320);}
 if(g.thrown)g.heat+=dt*(8+value(g)*.65)*.5;
 }
 if(g.heat>=100){lives=Math.max(0,lives-1);shake=20;message('OVERHEATED BURST! −1 LIFE');toastTime=3;shockwaves.push({x:g.x,y:g.y,age:0});tone(60,.45);bits(g.x,g.y,'#ff5879',65);bits(g.x,g.y,'#ffb14a',25);groups.splice(groups.indexOf(g),1);if(held===g)held=null;for(let j=0;j<Math.min(4,g.parts.length);j++)spawn(Math.max(40,Math.min(W-40,g.x+(Math.random()-.5)*100)),Math.max(40,Math.min(H-40,g.y+(Math.random()-.5)*100)));if(lives<=0){finish();return;}}
 }
 // Compound-body contact: each attached piece contributes to the collision outline.
 for(let i=0;i<groups.length;i++){const a=groups[i];if(a.kind||!a.thrown&&a!==held)continue;for(let j=groups.length-1;j>=0;j--){const b=groups[j];if(a===b||b.kind||b===held||b.parts.length!==1||b.thrown||a.parts.length>=18)continue;if(Math.hypot(a.x-b.x,a.y-b.y)>radius(a)+18)continue;const contact=a.parts.some(p=>{const v=world(a,p);return Math.hypot(v.x-b.x,v.y-b.y)<p.r+b.parts[0].r;});if(!contact)continue;const dx=b.x-a.x,dy=b.y-a.y,c=Math.cos(a.a),s=Math.sin(a.a),part=b.parts[0];a.lifeCredits=(a.lifeCredits||0)+(b.lifeCredits||0);a.parts.push({...part,x:dx*c+dy*s,y:-dx*s+dy*c});a.heat+=2.5;a.vx*=part.type===2?.88:1.02;a.vy*=part.type===2?.88:1.02;if(part.type===1){a.vx*=1.07;a.vy*=1.07;}bits(b.x,b.y,colors[part.type],8);groups.splice(j,1);if(j<i)i--;tone(400+a.parts.length*25);}}
 for(let i=absorptions.length-1;i>=0;i--){absorptions[i].age+=dt;if(absorptions[i].age>=.7)absorptions.splice(i,1);}
 for(let i=shockwaves.length-1;i>=0;i--){shockwaves[i].age+=dt;if(shockwaves[i].age>=.8)shockwaves.splice(i,1);}
 for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.life-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.life<=0)particles.splice(i,1);}
 }
 function circle(x,y,r,color){ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fillStyle=color;ctx.fill();}
 function draw(){const bounds=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2),w=Math.round(bounds.width*dpr),h=Math.round(bounds.height*dpr);if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#060912';ctx.fillRect(0,0,w,h);const scale=Math.min(w/W,h/H);ctx.translate((w-W*scale)/2,(h-H*scale)/2);ctx.scale(scale,scale);ctx.save();if(shake)ctx.translate((Math.random()-.5)*shake,(Math.random()-.5)*shake);ctx.fillStyle='#0b1221';ctx.fillRect(0,0,W,H);ctx.strokeStyle='#162338';ctx.lineWidth=1;for(let x=20;x<W;x+=40){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke();}for(let y=20;y<H;y+=40){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();}ctx.strokeStyle='#3d516b';ctx.lineWidth=3;ctx.strokeRect(18,18,W-36,H-36);
 ctx.shadowBlur=20;ctx.shadowColor='#b9ff49';ctx.fillStyle='#b9ff49';ctx.fillRect(12,H/2-100,12,200);ctx.fillRect(W-24,H/2-100,12,200);ctx.shadowBlur=0;ctx.font='bold 12px system-ui';ctx.fillText('BANK 2+ PIECES',35,H/2-112);ctx.fillText('BANK 2+ PIECES',W-146,H/2-112);
 if(held){ctx.strokeStyle='#b9ff4999';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(core.x,core.y);ctx.lineTo(held.x,held.y);ctx.stroke();ctx.setLineDash([6,7]);ctx.strokeStyle='#ffffffaa';ctx.beginPath();ctx.moveTo(held.x,held.y);ctx.lineTo(held.x-Math.sin(angle)*160,held.y+Math.cos(angle)*160);ctx.stroke();ctx.setLineDash([]);}
 for(const g of groups){if(g.kind==='blackhole'&&g.lifeCredits){ctx.strokeStyle='#70ff6a';ctx.lineWidth=3;ctx.beginPath();ctx.arc(g.x,g.y,20,0,Math.PI*2);ctx.stroke();}if(g.kind){ctx.strokeStyle=g.kind==='blackhole'?'#e6aaff55':'#bd83ff33';ctx.lineWidth=2;ctx.setLineDash([5,9]);ctx.beginPath();ctx.arc(g.x,g.y,reach(g),0,Math.PI*2);ctx.stroke();ctx.setLineDash([]);}for(const p of g.parts){const v=world(g,p);if(p.x||p.y){ctx.strokeStyle='#59708f';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(g.x,g.y);ctx.lineTo(v.x,v.y);ctx.stroke();}ctx.shadowBlur=p.type===3?24:10;ctx.shadowColor=p.type===3?'#70ff6a':g.kind?'#d795ff':colors[p.type];circle(v.x,v.y,p.r,p.type===3?'#70ff6a':g.kind==='blackhole'?'#000':g.heat>75?'#ff5879':g.kind?'#c88aff':colors[p.type]);ctx.shadowBlur=0;ctx.strokeStyle=g.kind==='blackhole'?'#df9dff':'#ffffff88';ctx.lineWidth=2;ctx.beginPath();ctx.arc(v.x,v.y,p.r-4,0,Math.PI*2);ctx.stroke();if(p.type===3){ctx.fillStyle='#063d14';ctx.fillRect(v.x-6,v.y-2,12,4);ctx.fillRect(v.x-2,v.y-6,4,12);}if(p.type===2){ctx.fillStyle='#6d3b17';ctx.fillRect(v.x-4,v.y-4,8,8);}}
 if(g.thrown||g===held){const r=radius(g);ctx.fillStyle='#17263d';ctx.fillRect(g.x-23,g.y-r-14,46,4);ctx.fillStyle=g.heat>70?'#ff5879':'#b9ff49';ctx.fillRect(g.x-23,g.y-r-14,46*Math.min(1,g.heat/100),4);ctx.fillStyle='#fff';ctx.font='bold 12px system-ui';ctx.textAlign='center';ctx.fillText(value(g)+' ×'+mult(g)+(g.lifeCredits?'  +'+g.lifeCredits+' LIFE':''),g.x,g.y+r+18);ctx.textAlign='left';}}
 if(holding&&!held){ctx.strokeStyle='#b9ff4940';ctx.setLineDash([4,8]);ctx.beginPath();ctx.arc(core.x,core.y,180,0,Math.PI*2);ctx.stroke();ctx.setLineDash([]);}ctx.shadowColor='#fff';ctx.shadowBlur=20;circle(core.x,core.y,11,'#fff');ctx.shadowBlur=0;circle(core.x,core.y,4,'#0b1221');
 for(const p of particles){ctx.globalAlpha=Math.min(1,p.life*2);circle(p.x,p.y,3,p.c);}ctx.globalAlpha=1;
 for(const effect of absorptions){const t=Math.min(1,effect.age/.7),fade=1-t;ctx.globalAlpha=fade;for(const part of effect.parts){const dx=part.x-effect.target.x,dy=part.y-effect.target.y,angle=t*Math.PI*2,shrink=(1-t)*(1-t);const x=effect.target.x+(dx*Math.cos(angle)-dy*Math.sin(angle))*shrink,y=effect.target.y+(dx*Math.sin(angle)+dy*Math.cos(angle))*shrink;ctx.strokeStyle='#cd92ff';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(effect.target.x,effect.target.y);ctx.stroke();circle(x,y,Math.max(1,part.r*fade),part.c);}ctx.strokeStyle='#cd92ff';ctx.lineWidth=4*fade;ctx.beginPath();ctx.arc(effect.target.x,effect.target.y,18+(1-t)*100,0,Math.PI*2);ctx.stroke();ctx.globalAlpha=1;}for(const wave of shockwaves){const fade=Math.max(0,1-wave.age/.8);ctx.strokeStyle='rgba(255,88,121,'+fade+')';ctx.lineWidth=5*fade;ctx.beginPath();ctx.arc(wave.x,wave.y,20+wave.age*330,0,Math.PI*2);ctx.stroke();}ctx.textAlign='center';if(toastTime>0){ctx.fillStyle='#eff7ff';ctx.font='bold 20px system-ui';ctx.fillText(toast,W/2,48);}if(state==='paused'){ctx.fillStyle='#050914bb';ctx.fillRect(0,0,W,H);ctx.fillStyle='#b9ff49';ctx.font='bold 45px system-ui';ctx.fillText('PAUSED',W/2,H/2);ctx.font='18px system-ui';ctx.fillText('Press P or Resume',W/2,H/2+40);}ctx.textAlign='left';ctx.restore();$('stats').textContent=score.toLocaleString()+' pts · '+lives+' lives · '+goals+' goals';}
 function frame(now){if(dead)return;const delta=last?Math.min(.05,(now-last)/1000):0;last=now;if(state==='play'){acc+=delta;while(acc>=1/120&&state==='play'){tick(1/120);acc-=1/120;}}else acc=0;draw();raf=requestAnimationFrame(frame);}
 cleanupGame=()=>{if(closeGame)closeGame();};
 intro();raf=requestAnimationFrame(frame);
    }

    function solitaireGame() {
        shell('Klondike Solitaire', '<div class="status" id="game-status"></div><div id="sol-board"><aside class="sol-side"><div><div class="sol-label">Stock / Waste</div><div class="sol-row"><div id="sol-stock"></div><div id="sol-waste"></div></div></div><div><div class="sol-label">Foundations</div><div class="sol-row" id="sol-foundations"></div></div><button class="action" id="restart">New Deal</button></aside><div><div class="sol-label">Tableau</div><div class="sol-tableau" id="sol-tableau"></div></div></div>', 'Select a face-up card or sequence, then click its destination. Double-click a single card to send it home. Tableau descends in alternating colors; foundations rise by suit from Ace to King.');
        const suitData = [{ id: 'h', symbol: '♥', color: 'red' }, { id: 'd', symbol: '♦', color: 'red' }, { id: 'c', symbol: '♣', color: 'black' }, { id: 's', symbol: '♠', color: 'black' }];
        const names = { 1: 'A', 11: 'J', 12: 'Q', 13: 'K' };
        let tableau, stock, waste, foundations, selected, moves;
        const rank = n => names[n] || n;
        function newDeal() {
            const deck = suitData.flatMap(s => Array.from({ length: 13 }, (_, i) => ({ suit: s.id, symbol: s.symbol, color: s.color, rank: i + 1, up: false })));
            for (let i = deck.length - 1; i; i--) { const j = Math.floor(Math.random() * (i + 1)); [deck[i], deck[j]] = [deck[j], deck[i]]; }
            tableau = Array.from({ length: 7 }, () => []);
            for (let col = 0; col < 7; col++) { for (let n = 0; n <= col; n++) tableau[col].push(deck.pop()); tableau[col].at(-1).up = true; }
            stock = deck; waste = []; foundations = Object.fromEntries(suitData.map(s => [s.id, []])); selected = null; moves = 0; render('Draw a card or select a face-up card.');
        }
        function cardHTML(card, classes = '', chosen = false) { return `<span class="sol-card ${card.color === 'red' ? 'red' : ''} ${classes} ${chosen ? 'selected' : ''}"><span>${rank(card.rank)}</span><span class="sol-suit">${card.symbol}</span></span>`; }
        function chosen(kind, col, index, suit) { return selected && selected.kind === kind && selected.col === col && selected.index === index && selected.suit === suit; }
        function render(note = '') {
            root.getElementById('game-status').textContent = `${note} • ${moves} move${moves === 1 ? '' : 's'}`;
            const stockEl = root.getElementById('sol-stock'); stockEl.innerHTML = `<button class="sol-back" title="${stock.length ? `Draw (${stock.length})` : 'Recycle'}"></button>`; stockEl.firstElementChild.addEventListener('click', draw);
            const wasteEl = root.getElementById('sol-waste'); wasteEl.innerHTML = waste.length ? `<button style="all:unset">${cardHTML(waste.at(-1), '', chosen('waste'))}</button>` : '<div class="sol-empty">·</div>'; wasteEl.querySelector('button')?.addEventListener('click', () => select({ kind: 'waste' })); wasteEl.querySelector('button')?.addEventListener('dblclick', autoHome);
            const foundEl = root.getElementById('sol-foundations'); foundEl.innerHTML = suitData.map(s => `<button style="all:unset" data-suit="${s.id}">${foundations[s.id].length ? cardHTML(foundations[s.id].at(-1), '', chosen('foundation', undefined, undefined, s.id)) : `<span class="sol-empty">${s.symbol}</span>`}</button>`).join(''); foundEl.querySelectorAll('button').forEach(b => b.addEventListener('click', () => foundationClick(b.dataset.suit)));
            const tabEl = root.getElementById('sol-tableau'); tabEl.innerHTML = tableau.map((col, ci) => `<div class="sol-column" data-col="${ci}">${col.length ? col.map((c, i) => c.up ? `<button class="sol-card sol-stack ${c.color === 'red' ? 'red' : ''} ${chosen('tableau', ci, i) ? 'selected' : ''}" data-index="${i}"><span>${rank(c.rank)}</span><span class="sol-suit">${c.symbol}</span></button>` : '<div class="sol-back sol-stack down"></div>').join('') : '<button class="sol-empty">K</button>'}</div>`).join('');
            tabEl.querySelectorAll('.sol-column').forEach((column, col) => { column.addEventListener('click', e => { const card = e.target.closest('button.sol-card'); if (card) cardClick(col, Number(card.dataset.index)); else if (selected) moveTableau(col); }); column.querySelectorAll('button.sol-card').forEach(card => card.addEventListener('dblclick', e => { e.stopPropagation(); selected = { kind: 'tableau', col, index: Number(card.dataset.index) }; autoHome(); })); });
            if (suitData.every(s => foundations[s.id].length === 13)) { root.getElementById('game-status').textContent = `You won! • ${moves} moves`; recordBest('solitaire', moves, `${moves} moves`, true); }
        }
        function draw() { selected = null; if (stock.length) { const c = stock.pop(); c.up = true; waste.push(c); moves++; render('Drew one card.'); } else if (waste.length) { stock = waste.reverse(); stock.forEach(c => { c.up = false; }); waste = []; moves++; render('Recycled the waste.'); } }
        function select(next) { selected = selected && selected.kind === next.kind ? null : next; render(selected ? 'Selected. Choose a destination.' : 'Selection cleared.'); }
        function cardClick(col, index) { if (selected && !(selected.kind === 'tableau' && selected.col === col)) moveTableau(col); else select({ kind: 'tableau', col, index }); }
        function selectedCards() { if (!selected) return []; if (selected.kind === 'waste') return waste.length ? [waste.at(-1)] : []; if (selected.kind === 'foundation') return foundations[selected.suit].length ? [foundations[selected.suit].at(-1)] : []; return tableau[selected.col].slice(selected.index); }
        function removeSelected() { if (selected.kind === 'waste') return [waste.pop()]; if (selected.kind === 'foundation') return [foundations[selected.suit].pop()]; return tableau[selected.col].splice(selected.index); }
        function flip(col) { if (col?.length && !col.at(-1).up) col.at(-1).up = true; }
        function legal(card, col) { const top = col.at(-1); return top ? top.up && top.color !== card.color && top.rank === card.rank + 1 : card.rank === 13; }
        function moveTableau(to) { const cards = selectedCards(); if (!cards.length || (selected.kind === 'tableau' && selected.col === to)) { selected = null; render('Selection cleared.'); return; } if (!legal(cards[0], tableau[to])) { render(tableau[to].length ? 'Build downward in alternating colors.' : 'Only a King can enter an empty column.'); return; } const old = selected.kind === 'tableau' ? tableau[selected.col] : null; tableau[to].push(...removeSelected()); flip(old); selected = null; moves++; render('Moved to the tableau.'); }
        function foundationClick(suit) { if (!selected) { if (foundations[suit].length) select({ kind: 'foundation', suit }); return; } const cards = selectedCards(), card = cards[0]; if (cards.length !== 1 || card.suit !== suit || foundations[suit].length !== card.rank - 1) { render('Foundations rise by matching suit from Ace.'); return; } const old = selected.kind === 'tableau' ? tableau[selected.col] : null; foundations[suit].push(removeSelected()[0]); flip(old); selected = null; moves++; render(`${rank(card.rank)}${card.symbol} moved home.`); }
        function autoHome() { const cards = selectedCards(); if (cards.length === 1 && foundations[cards[0].suit].length === cards[0].rank - 1) foundationClick(cards[0].suit); else render('That card cannot move home yet.'); }
        root.getElementById('restart').addEventListener('click', newDeal); newDeal();
    }

    function tabletControls(down, up = () => {}, options = {}) {
        cleanupTouch();
        const container = root.querySelector('.game-shell');
        const controls = document.createElement('div'); controls.className = 'tablet-controls';
        const specs = options.specs || [['←','ArrowLeft'],['↑','ArrowUp'],['↓','ArrowDown'],['→','ArrowRight']];
        const held = new Map(), counts = new Map();
        const send = (fn,key) => fn({key,preventDefault(){},repeat:false});
        const release = id => { const key=held.get(id); if(!key)return;held.delete(id);const count=(counts.get(key)||1)-1;counts.set(key,count);if(!count)send(up,key); };
        for(const [label,key] of specs){
            const b=document.createElement('button');b.type='button';b.className='tablet-key';b.textContent=label;b.setAttribute('aria-label',label);
            b.onpointerdown=e=>{e.preventDefault();release(e.pointerId);held.set(e.pointerId,key);counts.set(key,(counts.get(key)||0)+1);b.setPointerCapture(e.pointerId);b.classList.add('active');send(down,key);};
            const end=e=>{release(e.pointerId);b.classList.remove('active');};b.onpointerup=b.onpointercancel=b.onlostpointercapture=end;
            controls.appendChild(b);
        }
        container.insertBefore(controls,container.querySelector('.help'));
        const canvas=options.surface||container.querySelector('canvas');let drag=null;
        const start=e=>{if(options.drag){canvas.setPointerCapture(e.pointerId);options.drag(e);e.preventDefault();}else{drag={id:e.pointerId,x:e.clientX,y:e.clientY};canvas.setPointerCapture(e.pointerId);e.preventDefault();}};
        const move=e=>{if(options.drag&&canvas.hasPointerCapture(e.pointerId)){options.drag(e);e.preventDefault();}};
        const clearGesture=()=>{drag=null;};
        const end=e=>{if(drag&&drag.id===e.pointerId){const dx=e.clientX-drag.x,dy=e.clientY-drag.y;drag=null;if(Math.max(Math.abs(dx),Math.abs(dy))>=20){const k=Math.abs(dx)>Math.abs(dy)?(dx>0?'ArrowRight':'ArrowLeft'):(dy>0?'ArrowDown':'ArrowUp');send(down,k);send(up,k);}}};
        if(canvas){canvas.style.touchAction='none';canvas.addEventListener('pointerdown',start);canvas.addEventListener('pointermove',move);canvas.addEventListener('pointerup',end);canvas.addEventListener('pointercancel',clearGesture);}
        const clear=()=>{for(const id of [...held.keys()])release(id);controls.querySelectorAll('.active').forEach(b=>b.classList.remove('active'));drag=null;};
        window.addEventListener('blur',clear);document.addEventListener('visibilitychange',clear);
        cleanupTouch=()=>{clear();controls.remove();window.removeEventListener('blur',clear);document.removeEventListener('visibilitychange',clear);if(canvas){canvas.removeEventListener('pointerdown',start);canvas.removeEventListener('pointermove',move);canvas.removeEventListener('pointerup',end);canvas.removeEventListener('pointercancel',clearGesture);}cleanupTouch=()=>{};};
        return controls;
    }

    function snakeGame() {
        shell('Snake', '<div class="status" id="game-status">Score: 0</div><canvas id="snake-canvas" width="500" height="400"></canvas><button class="action" id="restart">Restart</button>', 'Arrow keys or WASD to steer.');
        const canvas = root.getElementById('snake-canvas');
        const ctx = canvas.getContext('2d');
        let snake, food, direction, pending, score, timer, started, speed, gameOver;
        const placeFood = () => {
            do food = { x: Math.floor(Math.random() * 25), y: Math.floor(Math.random() * 20) };
            while (snake.some(p => p.x === food.x && p.y === food.y));
        };
        function reset() { snake = [{ x: 12, y: 10 }, { x: 11, y: 10 }]; direction = pending = { x: 1, y: 0 }; score = 0; speed = 230; started = false; gameOver = false; placeFood(); clearTimeout(timer); root.getElementById('game-status').textContent = 'Press an arrow key or WASD to begin'; draw(); }
        function tick() {
            direction = pending;
            const head = { x: snake[0].x + direction.x, y: snake[0].y + direction.y };
            if (head.x < 0 || head.x >= 25 || head.y < 0 || head.y >= 20 || snake.some(p => p.x === head.x && p.y === head.y)) { clearTimeout(timer); started = false; gameOver = true; recordBest('snake', score, `${score} points`); root.getElementById('game-status').textContent = `Game over • Score: ${score} • Press a direction to start over`; return; }
            snake.unshift(head);
            if (head.x === food.x && head.y === food.y) { score++; speed = Math.max(85, 230 - score * 9); placeFood(); } else snake.pop();
            root.getElementById('game-status').textContent = `Score: ${score} • Speed: ${Math.round((230 / speed) * 100)}%`; draw(); timer = setTimeout(tick, speed);
        }
        function draw() { ctx.fillStyle = '#050505'; ctx.fillRect(0, 0, 500, 400); ctx.fillStyle = '#e22'; ctx.fillRect(food.x * 20 + 3, food.y * 20 + 3, 14, 14); snake.forEach((p, i) => { ctx.fillStyle = i ? '#a51f1f' : '#ff3b3b'; ctx.fillRect(p.x * 20 + 1, p.y * 20 + 1, 18, 18); }); }
        const keyHandler = event => {
            const dirs = { ArrowUp: [0, -1], w: [0, -1], ArrowDown: [0, 1], s: [0, 1], ArrowLeft: [-1, 0], a: [-1, 0], ArrowRight: [1, 0], d: [1, 0] };
            const d = dirs[event.key]; if (!d) return; event.preventDefault();
            if (gameOver) reset();
            if (!started) pending = { x: d[0], y: d[1] };
            else if (d[0] !== -direction.x || d[1] !== -direction.y) pending = { x: d[0], y: d[1] };
            if (!started) { started = true; direction = pending; timer = setTimeout(tick, speed); }
        };
        window.addEventListener('keydown', keyHandler, true); root.getElementById('restart').addEventListener('click', reset);
        cleanupGame = () => { clearTimeout(timer); window.removeEventListener('keydown', keyHandler, true); }; reset(); tabletControls(keyHandler);
    }

    function minesGame() {
        shell('Minesweeper', '<div class="status" id="game-status">10 mines • Tap a square to open it</div><div id="mine-grid"></div><button class="action" id="flag-mode">Flag mode: off</button><button class="action" id="restart">New Board</button>', 'Open every safe square to win.');
        let board, ended, flagMode=false;
        root.getElementById('flag-mode').onclick=()=>{flagMode=!flagMode;root.getElementById('flag-mode').textContent='Flag mode: '+(flagMode?'on':'off');};
        function reset() {
            ended = false; board = Array.from({ length: 81 }, () => ({ mine: false, open: false, flag: false, n: 0 }));
            const places = new Set(); while (places.size < 10) places.add(Math.floor(Math.random() * 81)); places.forEach(i => { board[i].mine = true; });
            board.forEach((cell, i) => { const x = i % 9, y = Math.floor(i / 9); cell.n = neighbors(x, y).filter(n => board[n].mine).length; }); render();
        }
        function neighbors(x, y) { const out = []; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const nx = x + dx, ny = y + dy; if ((dx || dy) && nx >= 0 && nx < 9 && ny >= 0 && ny < 9) out.push(ny * 9 + nx); } return out; }
        function open(i) {
            if (ended || board[i].open || board[i].flag) return; board[i].open = true;
            if (board[i].mine) { ended = true; board.forEach(c => { if (c.mine) c.open = true; }); root.getElementById('game-status').textContent = 'Boom! You found a mine.'; render(); return; }
            if (!board[i].n) neighbors(i % 9, Math.floor(i / 9)).forEach(open);
            if (board.filter(c => c.open).length === 71) { ended = true; addWin('mines'); root.getElementById('game-status').textContent = 'You cleared the minefield!'; }
            render();
        }
        function render() {
            const grid = root.getElementById('mine-grid'); grid.innerHTML = board.map((c, i) => `<button class="mine-cell ${c.open ? 'open' : ''} ${c.open && c.mine ? 'mine' : ''} ${c.open && c.n ? `n${Math.min(c.n, 4)}` : ''}" data-i="${i}">${c.open ? (c.mine ? '●' : c.n || '') : c.flag ? '⚑' : ''}</button>`).join('');
            grid.querySelectorAll('button').forEach(b => { b.addEventListener('click', () => {const i=Number(b.dataset.i);if(flagMode){if(!ended&&!board[i].open){board[i].flag=!board[i].flag;render();}}else open(i);}); b.addEventListener('contextmenu', e => { e.preventDefault(); const c = board[Number(b.dataset.i)]; if (!ended && !c.open) { c.flag = !c.flag; render(); } }); });
        }
        root.getElementById('restart').addEventListener('click', reset); reset();
    }

    function game2048(chaotyk) {
        const size = chaotyk ? 5 : 4;
        shell(`2048 — ${chaotyk ? 'Chaotyk 5×5' : 'Original 4×4'}`, '<div class="status" id="game-status">Score: 0</div><div id="grid2048"></div><button class="action" id="restart">New Game</button>', 'HOW TO PLAY: Use arrows or WASD. Every move slides all tiles. Equal tiles combine. Your leaderboard result is the highest-numbered tile reached.');
        const grid = root.getElementById('grid2048');
        grid.style.setProperty('--grid-size', size);
        grid.style.setProperty('--tile-size', chaotyk ? 'clamp(46px,min(7cqw,10cqh),68px)' : 'clamp(52px,min(9cqw,12cqh),82px)');
        let board, score, ended;
        function addTile() { const empty = board.map((v, i) => v ? -1 : i).filter(i => i >= 0); if (empty.length) board[empty[Math.floor(Math.random() * empty.length)]] = Math.random() < .9 ? 2 : 4; }
        function reset() { board = Array(size * size).fill(0); score = 0; ended = false; addTile(); addTile(); render(); }
        function slide(line) { const vals = line.filter(Boolean); for (let i = 0; i < vals.length - 1; i++) if (vals[i] === vals[i + 1]) { vals[i] *= 2; score += vals[i]; vals.splice(i + 1, 1); } while (vals.length < size) vals.push(0); return vals; }
        function move(dir) {
            if (ended) return;
            const old = board.join(); const next = Array(size * size).fill(0);
            for (let a = 0; a < size; a++) { const indices = []; for (let b = 0; b < size; b++) indices.push(dir === 'left' ? a * size + b : dir === 'right' ? a * size + (size - 1 - b) : dir === 'up' ? b * size + a : (size - 1 - b) * size + a); const vals = slide(indices.map(i => board[i])); indices.forEach((i, n) => { next[i] = vals[n]; }); }
            board = next; if (board.join() !== old) { addTile(); render(); }
            if (!board.includes(0) && !canMove()) { ended = true; root.getElementById('game-status').textContent = `Game over • Highest tile: ${Math.max(...board)} • Score: ${score}`; }
        }
        function canMove() { return board.some((v, i) => (i % size < size - 1 && v === board[i + 1]) || (i < size * (size - 1) && v === board[i + size])); }
        function render() { const highest = Math.max(...board); recordBest(modeKey('2048'), highest, `Tile ${highest}`); grid.innerHTML = board.map(v => `<div class="tile2048 ${v ? `v${Math.min(v, 2048)}` : ''}">${v || ''}</div>`).join(''); root.getElementById('game-status').textContent = `Highest tile: ${highest} • Score: ${score}`; }
        const keyHandler = event => { const map = { ArrowLeft: 'left', a: 'left', ArrowRight: 'right', d: 'right', ArrowUp: 'up', w: 'up', ArrowDown: 'down', s: 'down' }; if (map[event.key]) { event.preventDefault(); move(map[event.key]); } };
        window.addEventListener('keydown', keyHandler, true); root.getElementById('restart').addEventListener('click', reset); cleanupGame = () => window.removeEventListener('keydown', keyHandler, true); reset(); tabletControls(keyHandler,()=>{},{surface:root.getElementById('grid2048')});
    }

    function chooseBreakoutMode() {
        shell('Breakout', '<div class="mode-grid"><button class="mode-card" data-mode="original"><strong>Original Mode</strong><span>The existing game, including all four power-ups.</span></button><button class="mode-card chaotyk" data-mode="chaotyk"><strong>Chaotyk Mode</strong><span>Custom paddle, selectable power-ups, and starting lives.</span></button></div>');
        root.querySelectorAll('[data-mode]').forEach(button => button.onclick = () => {
            currentMode = button.dataset.mode;
            if (currentMode === 'chaotyk') breakoutSetup(loadBreakoutSettings()); else breakoutGame();
        });
    }

    function validPaddle(points) {
        if (points.length < 3) return false;
        const cross = (a,b,c) => (b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
        const on = (a,b,c) => Math.abs(cross(a,b,c)) < 1e-8 && c.x >= Math.min(a.x,b.x) && c.x <= Math.max(a.x,b.x) && c.y >= Math.min(a.y,b.y) && c.y <= Math.max(a.y,b.y);
        const intersects = (a,b,c,d) => (cross(a,b,c)*cross(a,b,d)<0 && cross(c,d,a)*cross(c,d,b)<0) || on(a,b,c) || on(a,b,d) || on(c,d,a) || on(c,d,b);
        let area = 0;
        for (let i=0;i<points.length;i++) {
            const a=points[i],b=points[(i+1)%points.length];
            if (Math.hypot(b.x-a.x,b.y-a.y)<8) return false;
            area += a.x*b.y-b.x*a.y;
            for (let j=i+1;j<points.length;j++) {
                if (j===i+1 || (i===0 && j===points.length-1)) continue;
                if (intersects(a,b,points[j],points[(j+1)%points.length])) return false;
            }
        }
        return Math.abs(area)>600;
    }

    const breakoutPowers = [['split','Multiball'],['power','Power Ball'],['wide','Wide Paddle'],['life','Extra Life'],['slow','Slow Motion — 10 seconds'],['field','Force Field — 10 seconds']];
    const defaultPaddle = () => [{x:30,y:45},{x:240,y:45},{x:450,y:45},{x:450,y:135},{x:240,y:135},{x:30,y:135}];
    function loadBreakoutSettings() {
        const saved=GM_getValue('chaotykArcadeBreakoutSettingsV1',{}), points=saved?.points;
        return {points:Array.isArray(points)&&points.length===6&&points.every(p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.y)&&p.x>=10&&p.x<=470&&p.y>=10&&p.y<=170)&&validPaddle(points)?points:defaultPaddle(),
            powers:Array.isArray(saved?.powers)?breakoutPowers.map(p=>p[0]).filter(p=>saved.powers.includes(p)):breakoutPowers.map(p=>p[0]),
            lives:Number.isInteger(saved?.lives)?Math.max(1,Math.min(10,saved.lives)):3,
            multiplier:Number.isInteger(saved?.multiplier)?Math.max(1,Math.min(4,saved.multiplier)):1};
    }
    function breakoutSetup(settings) {
        shell('Breakout — Chaotyk Setup','<div class="status">Configure your next game</div><div style="display:flex;flex-direction:column;gap:12px;width:min(400px,95%)"><button class="action" id="shape-setting">Paddle Shape</button><button class="action" id="powers-setting">Customize Power-ups</button><button class="action" id="lives-setting">Starting Lives</button><button class="action" id="bricks-setting">Brick Multiplier</button><div class="status" id="setup-summary"></div><button class="action" id="setup-start">Start Game</button></div>');
        root.getElementById('setup-summary').textContent=settings.lives+' lives • '+settings.multiplier+'× bricks • '+settings.powers.length+' power-up types';
        const save=()=>GM_setValue('chaotykArcadeBreakoutSettingsV1',settings);
        root.getElementById('bricks-setting').onclick=()=>{
            shell('Brick Multiplier','<div class="status" id="brick-value"></div><input id="brick-slider" type="range" min="1" max="4" step="1" style="width:80%"><div class="row"><button class="action" id="save-bricks">Save</button><button class="action" id="cancel-bricks">Cancel</button></div>','More bricks and proportionally more enabled power-up blocks, in the same space.');
            const slider=root.getElementById('brick-slider');slider.value=settings.multiplier;
            slider.oninput=()=>root.getElementById('brick-value').textContent=slider.value+'× bricks and power-up blocks';slider.oninput();
            root.getElementById('save-bricks').onclick=()=>{settings.multiplier=Number(slider.value);save();breakoutSetup(settings);};
            root.getElementById('cancel-bricks').onclick=()=>breakoutSetup(settings);
        };
        root.getElementById('shape-setting').onclick=()=>designBreakoutPaddle(settings);
        root.getElementById('powers-setting').onclick=()=>{
            shell('Customize Power-ups','<div style="display:flex;flex-direction:column;gap:14px">'+breakoutPowers.map(([id,name])=>'<label><input type="checkbox" data-power="'+id+'" '+(settings.powers.includes(id)?'checked':'')+'> '+name+'</label>').join('')+'<button class="action" id="save-powers">Save</button><button class="action" id="cancel-powers">Cancel</button></div>','Unchecked types never appear. Uncheck all for no power-ups.');
            root.getElementById('save-powers').onclick=()=>{settings.powers=[...root.querySelectorAll('[data-power]:checked')].map(p=>p.dataset.power);save();breakoutSetup(settings);};
            root.getElementById('cancel-powers').onclick=()=>breakoutSetup(settings);
        };
        root.getElementById('lives-setting').onclick=()=>{
            shell('Starting Lives','<div class="status" id="life-value"></div><input id="life-slider" type="range" min="1" max="10" step="1" style="width:80%"><div class="row"><button class="action" id="save-lives">Save</button><button class="action" id="cancel-lives">Cancel</button></div>');
            const slider=root.getElementById('life-slider');slider.value=settings.lives;
            slider.oninput=()=>root.getElementById('life-value').textContent=slider.value+' '+(slider.value==='1'?'life':'lives');slider.oninput();
            root.getElementById('save-lives').onclick=()=>{settings.lives=Number(slider.value);save();breakoutSetup(settings);};
            root.getElementById('cancel-lives').onclick=()=>breakoutSetup(settings);
        };
        root.getElementById('setup-start').onclick=()=>{
            save();const points=settings.points,minX=Math.min(...points.map(p=>p.x)),minY=Math.min(...points.map(p=>p.y)),w=Math.max(...points.map(p=>p.x))-minX,h=Math.max(...points.map(p=>p.y))-minY;
            breakoutGame(points.map(p=>({x:(p.x-minX)/w,y:(p.y-minY)/h})),settings);
        };
    }
    function designBreakoutPaddle(settings) {
        shell('Build your paddle', '<div class="status" id="designer-status"></div><canvas id="paddle-designer" width="480" height="180" style="touch-action:none"></canvas><div class="row"><button class="action" id="reset-shape">Reset Shape</button><button class="action" id="save-shape">Save</button><button class="action" id="cancel-shape">Cancel</button></div>', 'Drag the six yellow corners. Sloped edges change the bounce. Crossed edges are prevented.');
        const canvas=root.getElementById('paddle-designer'),ctx=canvas.getContext('2d');
        let points=settings.points.map(p=>({...p})),dragging=null;
        function draw() {
            ctx.clearRect(0,0,480,180);ctx.fillStyle='#111';ctx.fillRect(0,0,480,180);
            ctx.strokeStyle='#292929';ctx.lineWidth=1;
            for(let x=0;x<480;x+=20){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,180);ctx.stroke();}
            for(let y=0;y<180;y+=20){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(480,y);ctx.stroke();}
            if(points.length){ctx.beginPath();ctx.moveTo(points[0].x,points[0].y);points.slice(1).forEach(p=>ctx.lineTo(p.x,p.y));if(points.length>=3)ctx.closePath();ctx.fillStyle='#a0202044';if(points.length>=3)ctx.fill();ctx.strokeStyle='#ff5555';ctx.lineWidth=3;ctx.stroke();}
            points.forEach((p,i)=>{ctx.beginPath();ctx.arc(p.x,p.y,5,0,Math.PI*2);ctx.fillStyle='#ffd42a';ctx.fill();ctx.font='14px Arial';ctx.fillText(i+1,p.x+8,p.y-8);});
            root.getElementById('designer-status').textContent='Grab a yellow corner and drag it';
        }
        const cursor=e=>{const r=canvas.getBoundingClientRect();return{x:Math.max(10,Math.min(470,(e.clientX-r.left)*480/r.width)),y:Math.max(10,Math.min(170,(e.clientY-r.top)*180/r.height))};};
        canvas.onpointerdown=e=>{const p=cursor(e),r=canvas.getBoundingClientRect(),limit=18*480/r.width;dragging=points.findIndex(q=>Math.hypot(q.x-p.x,q.y-p.y)<limit);if(dragging<0){dragging=null;return;}canvas.setPointerCapture(e.pointerId);e.preventDefault();};
        canvas.onpointermove=e=>{if(dragging===null)return;const next=points.map(p=>({...p}));next[dragging]=cursor(e);if(validPaddle(next))points=next;draw();};
        canvas.onpointerup=canvas.onpointercancel=()=>{dragging=null;};
        root.getElementById('reset-shape').onclick=()=>{points=defaultPaddle();draw();};
        root.getElementById('save-shape').onclick=()=>{settings.points=points;GM_setValue('chaotykArcadeBreakoutSettingsV1',settings);breakoutSetup(settings);};
        root.getElementById('cancel-shape').onclick=()=>breakoutSetup(settings);draw();
    }

    function reflectPaddleBall(ball, polygon, radius) {
        // Circle-versus-segment contact, including vertices. Approach-only
        // reflection prevents a resting contact from flipping repeatedly.
        let best=null;
        for(let i=0;i<polygon.length;i++){
            const a=polygon[i],b=polygon[(i+1)%polygon.length],ex=b.x-a.x,ey=b.y-a.y,len=ex*ex+ey*ey;
            const t=Math.max(0,Math.min(1,((ball.x-a.x)*ex+(ball.y-a.y)*ey)/len));
            const qx=a.x+t*ex,qy=a.y+t*ey,dx=ball.x-qx,dy=ball.y-qy,d=Math.hypot(dx,dy);
            if(d>radius || d<1e-8)continue;
            const nx=dx/d,ny=dy/d,dot=ball.dx*nx+ball.dy*ny;
            if(dot<0 && (!best || d<best.d))best={d,nx,ny,qx,qy,dot};
        }
        if(!best)return false;
        ball.x=best.qx+best.nx*(radius+.05);ball.y=best.qy+best.ny*(radius+.05);
        ball.dx-=2*best.dot*best.nx;ball.dy-=2*best.dot*best.ny;return true;
    }

    function breakoutGame(customShape = null, settings = null) {
        shell('Breakout', '<div class="status" id="game-status"></div><canvas id="breakout-canvas" width="600" height="400"></canvas><button class="action" id="restart">New Game</button>', '10 levels • 3 lives • Move with Left/Right or A/D • Space launches. Hidden bricks can grant multiball, power ball, a wide paddle, or an extra life.');
        const canvas = root.getElementById('breakout-canvas'), ctx = canvas.getContext('2d');
        let paddle, balls, bricks, score, level, lives, launched, gameOver, powerUntil, wideUntil, statusNote, raf, slowUntil = 0, fieldUntil = 0, left = false, right = false;
        function newGame() { paddle = 250; score = 0; level = 1; lives = settings ? settings.lives : 3; gameOver = false; slowUntil = fieldUntil = powerUntil = wideUntil = 0; statusNote = 'Press Space to launch'; makeLevel(true); cancelAnimationFrame(raf); loop(); }
        function newBall(offset = 0) { const speed = 3.05 + level * .17; return { x: paddle + 50 + offset, y: 345, dx: (offset >= 0 ? 1 : -1) * speed, dy: -speed }; }
        function makeLevel(resetBalls) {
            const rows = 4 + Math.min(2, Math.floor((level - 1) / 3));
            const multiplier=settings?settings.multiplier:1, columns=8*multiplier, spacing=69/multiplier;
            bricks = Array.from({ length: rows * columns }, (_, i) => ({ x: 28 + (i % columns) * spacing, y: 34 + Math.floor(i / columns) * 25, width:spacing-7/multiplier, alive: true, power: null }));
            const types=settings?settings.powers:['split','power','wide','life'];
            const picks = new Set(); while (picks.size < types.length*multiplier) picks.add(Math.floor(Math.random() * bricks.length));
            [...picks].forEach((index, i) => { bricks[index].power = types[i%types.length]; });
            if (resetBalls || !balls?.length) balls = [newBall()]; else balls = balls.map((_, i) => newBall((i - (balls.length - 1) / 2) * 12));
            launched = false;
        }
        function activate(type) {
            if (type === 'split') {
                const copies = balls.slice(0, 16).map(ball => ({ x: ball.x, y: ball.y, dx: -ball.dx + (Math.random() - .5), dy: ball.dy }));
                balls.push(...copies); statusNote = `MULTIBALL! ${balls.length} balls active`;
            } else if (type === 'power') { powerUntil = Math.max(powerUntil, performance.now()) + poweredDuration(5000); statusNote = 'POWER BALL! Punch-through active'; }
            else if (type === 'wide') { wideUntil = Math.max(wideUntil, performance.now()) + poweredDuration(6000); statusNote = 'WIDE PADDLE! Larger paddle active'; }
            else if (type === 'life') { lives++; statusNote = `EXTRA LIFE! ${lives} lives available`; }
            else if (type === 'slow') { slowUntil = performance.now() + 10000; statusNote = 'SLOW MOTION! 10 seconds'; }
            else if (type === 'field') { fieldUntil = performance.now() + 10000; statusNote = 'FORCE FIELD! 10 seconds'; }
        }
        function loseLastBall() {
            lives--;
            if (lives <= 0) { gameOver = true; launched = false; statusNote = `Game over on level ${level}`; return; }
            balls = [newBall()]; launched = false; slowUntil = fieldUntil = powerUntil = wideUntil = 0; statusNote = `Life lost • ${lives} ${lives === 1 ? 'life' : 'lives'} left • Space to launch`;
        }
        function nextLevel() {
            if (level >= 10) { gameOver = true; launched = false; statusNote = `YOU BEAT ALL 10 LEVELS! Final score: ${score}`; return; }
            level++; slowUntil = fieldUntil = powerUntil = wideUntil = 0; statusNote = `Level ${level} ready • ${balls.length} ball${balls.length === 1 ? '' : 's'} • Space to launch`; makeLevel(false);
        }
        function loop() {
            const paddleWidth = performance.now() < wideUntil ? 150 : 100;
            if (left) paddle = Math.max(0, paddle - 7); if (right) paddle = Math.min(600 - paddleWidth, paddle + 7);
            if(customShape) paddle = Math.max(0, Math.min(600 - paddleWidth, paddle));
            const polygon = customShape && customShape.map(p => ({x:paddle+p.x*paddleWidth,y:355+p.y*28}));
            const powered = performance.now() < powerUntil;
            if (!launched && !gameOver) balls.forEach((ball, i) => { ball.x = paddle + paddleWidth / 2 + (i - (balls.length - 1) / 2) * 10; ball.y = customShape ? 344 : 345; });
            if (launched && !gameOver) {
                balls.forEach(ball => {
                    // Small substeps keep fast balls from tunnelling through custom edges.
                    const steps = customShape ? Math.max(1,Math.ceil(Math.hypot(ball.dx,ball.dy)/3)) : 1;
                    for(let step=0;step<steps;step++){
                        const speedScale=performance.now()<slowUntil?.5:1;
                        const previousY=ball.y;
                        ball.x += ball.dx*speedScale/steps; ball.y += ball.dy*speedScale/steps;
                        if(polygon) reflectPaddleBall(ball,polygon,powered?8:7);
                        if(performance.now()<fieldUntil && ball.dy>0 && previousY<=383 && ball.y>=383){ball.y=383;ball.dy=-Math.abs(ball.dy);}
                    }
                    if (ball.x < 7) { ball.x = 7; ball.dx = Math.abs(ball.dx); } if (ball.x > 593) { ball.x = 593; ball.dx = -Math.abs(ball.dx); } if (ball.y < 7) { ball.y = 7; ball.dy = Math.abs(ball.dy); }
                    if (!customShape && ball.y > 355 && ball.y < 377 && ball.x > paddle && ball.x < paddle + paddleWidth && ball.dy > 0) { ball.dy = -Math.abs(ball.dy); ball.dx += ((ball.x - (paddle + paddleWidth / 2)) / (paddleWidth / 2)) * 1.2; }
                    let bounced = false;
                    bricks.forEach(brick => {
                        if (brick.alive && ball.x + 6 > brick.x && ball.x - 6 < brick.x + brick.width && ball.y + 6 > brick.y && ball.y - 6 < brick.y + 19) {
                            brick.alive = false; score += level; if (brick.power) activate(brick.power);
                            if (performance.now() >= powerUntil && !bounced) { ball.dy *= -1; bounced = true; }
                        }
                    });
                });
                balls = balls.filter(ball => ball.y <= 410);
                if (!balls.length) loseLastBall();
                else if (bricks.every(brick => !brick.alive)) nextLevel();
            }
            const seconds = Math.max(0, (powerUntil - performance.now()) / 1000), wideSeconds = Math.max(0, (wideUntil - performance.now()) / 1000);
            recordBest(settings ? 'breakout:chaotyk' : 'breakout', score, `Score ${score} • Level ${level}`);
            root.getElementById('game-status').textContent = `Level ${level}/10 • Lives: ${lives} • Score: ${score} • Balls: ${balls.length}${seconds > 0 ? ` • POWER ${Math.ceil(seconds)}s` : ''}${wideSeconds > 0 ? ` • WIDE ${Math.ceil(wideSeconds)}s` : ''} • ${statusNote}`;
            if(settings){const now=performance.now();root.getElementById('game-status').textContent+=(slowUntil>now?' • SLOW '+Math.ceil((slowUntil-now)/1000)+'s':'')+(fieldUntil>now?' • FORCE FIELD '+Math.ceil((fieldUntil-now)/1000)+'s':'');}
            ctx.fillStyle = '#050505'; ctx.fillRect(0, 0, 600, 400);
            const powerColors = { split: '#45c8ff', power: '#ffd21c', wide: '#58e878', life: '#ff67c8', slow:'#ba83ff', field:'#00e5ff' };
            bricks.forEach((brick, i) => { if (brick.alive) { const row=Math.floor(i/(8*(settings?settings.multiplier:1)));ctx.fillStyle = powerColors[brick.power] || `hsl(${350 + row * 9} 76% ${35 + row * 4}%)`; ctx.fillRect(brick.x, brick.y, brick.width, 19); } });
            ctx.fillStyle = wideSeconds > 0 ? '#58e878' : '#e33';
            if(polygon){ctx.beginPath();ctx.moveTo(polygon[0].x,polygon[0].y);polygon.slice(1).forEach(p=>ctx.lineTo(p.x,p.y));ctx.closePath();ctx.fill();ctx.strokeStyle='#ffd42a';ctx.lineWidth=1;ctx.stroke();}
            else ctx.fillRect(paddle, 365, paddleWidth, 12);
            if(performance.now()<fieldUntil){ctx.save();ctx.strokeStyle='#00e5ff';ctx.lineWidth=3;ctx.shadowColor='#00e5ff';ctx.shadowBlur=12;ctx.beginPath();ctx.moveTo(0,392);ctx.lineTo(600,392);ctx.stroke();ctx.restore();}
            balls.forEach(ball => { ctx.beginPath(); ctx.arc(ball.x, ball.y, powered ? 8 : 7, 0, Math.PI * 2); ctx.fillStyle = powered ? '#ffd21c' : '#fff'; ctx.shadowColor = powered ? '#ff0' : 'transparent'; ctx.shadowBlur = powered ? 14 : 0; ctx.fill(); ctx.shadowBlur = 0; });
            raf = requestAnimationFrame(loop);
        }
        const down = event => { if (['ArrowLeft', 'a', 'ArrowRight', 'd', ' '].includes(event.key)) event.preventDefault(); if (event.key === 'ArrowLeft' || event.key === 'a') left = true; if (event.key === 'ArrowRight' || event.key === 'd') right = true; if (event.key === ' ' && !gameOver) { launched = true; statusNote = ''; } };
        const up = event => { if (event.key === 'ArrowLeft' || event.key === 'a') left = false; if (event.key === 'ArrowRight' || event.key === 'd') right = false; };
        window.addEventListener('keydown', down, true); window.addEventListener('keyup', up, true); root.getElementById('restart').addEventListener('click', () => { if(settings){cleanupGame();cleanupGame=()=>{};breakoutSetup(loadBreakoutSettings());}else newGame(); }); cleanupGame = () => { cancelAnimationFrame(raf); window.removeEventListener('keydown', down, true); window.removeEventListener('keyup', up, true); }; newGame(); tabletControls(down,up,{specs:[['←','ArrowLeft'],['Launch',' '],['→','ArrowRight']],drag:e=>{const r=canvas.getBoundingClientRect();const w=performance.now()<wideUntil?150:100;paddle=Math.max(0,Math.min(600-w,(e.clientX-r.left)*600/r.width-w/2));}});
    }

    function asteroidsGame(chaotyk) {
        shell(`Asteroids — ${chaotyk ? 'Chaotyk' : 'Original'}`, '<div class="status" id="game-status"></div><canvas id="space-canvas" width="600" height="400"></canvas><button class="action" id="restart">New Run</button>', chaotyk ? 'Arrows/WASD steer • Space fires • Destroy glowing asteroids for shields, spread shots, or rapid fire.' : 'Arrows/WASD steer • Space fires • Clear each wave and protect your three lives.');
        const canvas=root.getElementById('space-canvas'),ctx=canvas.getContext('2d');let ship,rocks,shots,keysDown={},score,level,lives,over,raf,lastShot,power,powerUntil;
        const wrap=o=>{if(o.x<0)o.x+=600;if(o.x>600)o.x-=600;if(o.y<0)o.y+=400;if(o.y>400)o.y-=400;};
        function rock(r=34,x=Math.random()*600,y=Math.random()*400){const a=Math.random()*Math.PI*2,s=0.5+Math.random()*1.1+level*.05;return{x,y,dx:Math.cos(a)*s,dy:Math.sin(a)*s,r,power:chaotyk&&Math.random()<.16?['shield','spread','rapid'][Math.floor(Math.random()*3)]:null};}
        function wave(){rocks=[];for(let i=0;i<3+level;i++){let r;do r=rock();while(Math.hypot(r.x-ship.x,r.y-ship.y)<120);rocks.push(r);}}
        function reset(){ship={x:300,y:200,a:-Math.PI/2,dx:0,dy:0};shots=[];score=0;level=1;lives=3;over=false;lastShot=0;power=null;powerUntil=0;wave();cancelAnimationFrame(raf);loop();}
        function fire(){const now=performance.now(),rapid=power==='rapid'&&now<powerUntil;if(now-lastShot<(rapid?100:240)||over)return;lastShot=now;const angles=power==='spread'&&now<powerUntil?[-.22,0,.22]:[0];angles.forEach(off=>shots.push({x:ship.x,y:ship.y,dx:Math.cos(ship.a+off)*6+ship.dx,dy:Math.sin(ship.a+off)*6+ship.dy,life:75}));}
        function activate(kind){power=kind;powerUntil=performance.now()+poweredDuration(kind==='shield'?7000:6000);}
        function split(r){if(r.r>20){rocks.push(rock(r.r*.58,r.x,r.y),rock(r.r*.58,r.x,r.y));}}
        function hitShip(){if(power==='shield'&&performance.now()<powerUntil)return;const danger=rocks.find(r=>Math.hypot(r.x-ship.x,r.y-ship.y)<r.r+10);if(!danger)return;lives--;ship={x:300,y:200,a:-Math.PI/2,dx:0,dy:0};if(lives<=0)over=true;}
        function loop(){
            if(!over){if(keysDown.ArrowLeft||keysDown.a)ship.a-=.065;if(keysDown.ArrowRight||keysDown.d)ship.a+=.065;if(keysDown.ArrowUp||keysDown.w){ship.dx+=Math.cos(ship.a)*.09;ship.dy+=Math.sin(ship.a)*.09;}ship.dx*=.995;ship.dy*=.995;ship.x+=ship.dx;ship.y+=ship.dy;wrap(ship);if(keysDown[' '])fire();
                rocks.forEach(r=>{r.x+=r.dx;r.y+=r.dy;wrap(r);});shots.forEach(s=>{s.x+=s.dx;s.y+=s.dy;s.life--;wrap(s);});
                shots.forEach(s=>{if(s.life<=0)return;const i=rocks.findIndex(r=>Math.hypot(r.x-s.x,r.y-s.y)<r.r);if(i>=0){const r=rocks.splice(i,1)[0];s.life=0;score+=Math.round(50/r.r*10);if(r.power)activate(r.power);split(r);}});shots=shots.filter(s=>s.life>0);hitShip();if(!rocks.length){level++;wave();}
            }
            const remain=Math.max(0,(powerUntil-performance.now())/1000);recordBest(modeKey('asteroids'),score,`Score ${score} • Wave ${level}`);root.getElementById('game-status').textContent=over?`Game over • Score ${score}`:`Wave ${level} • Lives ${lives} • Score ${score}${remain?` • ${power.toUpperCase()} ${Math.ceil(remain)}s`:''}`;
            ctx.fillStyle='#030307';ctx.fillRect(0,0,600,400);ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.save();ctx.translate(ship.x,ship.y);ctx.rotate(ship.a);ctx.beginPath();ctx.moveTo(13,0);ctx.lineTo(-9,8);ctx.lineTo(-5,0);ctx.lineTo(-9,-8);ctx.closePath();ctx.stroke();ctx.restore();if(power==='shield'&&remain){ctx.beginPath();ctx.arc(ship.x,ship.y,18,0,Math.PI*2);ctx.strokeStyle='#4cf';ctx.stroke();}
            rocks.forEach(r=>{ctx.beginPath();for(let i=0;i<9;i++){const a=i/9*Math.PI*2,rr=r.r*(.82+(i%3)*.08);const x=r.x+Math.cos(a)*rr,y=r.y+Math.sin(a)*rr;i?ctx.lineTo(x,y):ctx.moveTo(x,y);}ctx.closePath();ctx.strokeStyle=r.power?'#ff3':'#aaa';ctx.stroke();});shots.forEach(s=>{ctx.fillStyle='#f44';ctx.fillRect(s.x-2,s.y-2,4,4);});raf=requestAnimationFrame(loop);
        }
        const down=e=>{if(['ArrowLeft','ArrowRight','ArrowUp','a','d','w',' '].includes(e.key)){e.preventDefault();keysDown[e.key]=true;}};const up=e=>{keysDown[e.key]=false;};window.addEventListener('keydown',down,true);window.addEventListener('keyup',up,true);root.getElementById('restart').onclick=reset;cleanupGame=()=>{cancelAnimationFrame(raf);window.removeEventListener('keydown',down,true);window.removeEventListener('keyup',up,true);};reset();tabletControls(down,up,{specs:[['↶','ArrowLeft'],['↷','ArrowRight'],['Thrust','ArrowUp'],['Fire',' ']]});
    }

    function invadersGame(chaotyk) {
        shell(`Space Invaders — ${chaotyk ? 'Chaotyk' : 'Original'}`, '<div class="status" id="game-status"></div><canvas id="invader-canvas" width="600" height="400"></canvas><button class="action" id="restart">New Defense</button>', chaotyk ? 'Left/Right or A/D moves • Space fires • Glowing invaders grant multishot, shields, or rapid fire.' : 'Left/Right or A/D moves • Space fires • Survive increasingly fast formations.');
        const canvas=root.getElementById('invader-canvas'),ctx=canvas.getContext('2d');let player,enemies,shots,enemyShots,barriers,dir,waveNo,lives,score,over,keysDown={},raf,lastShot,powers;
        function newWave(){enemies=[];for(let y=0;y<5;y++)for(let x=0;x<10;x++)enemies.push({x:65+x*48,y:38+y*30,alive:true,power:chaotyk&&Math.random()<.035?['multi','shield','rapid'][Math.floor(Math.random()*3)]:null});dir=1;}
        function reset(){player={x:285};shots=[];enemyShots=[];barriers=[110,250,390].map(x=>({x,y:330,hp:12}));waveNo=1;lives=3;score=0;over=false;lastShot=0;powers={multi:0,shield:0,rapid:0};newWave();cancelAnimationFrame(raf);loop();}
        function active(kind,now=performance.now()){return powers[kind]>now;}
        function activate(kind){powers[kind]=Math.max(powers[kind],performance.now())+poweredDuration(6000);}
        function fire(){const now=performance.now();if(now-lastShot<(active('rapid',now)?90:260)||over)return;lastShot=now;const offsets=active('multi',now)?[-12,0,12]:[0];offsets.forEach(dx=>shots.push({x:player.x+15+dx,y:360,dy:-6}));}
        function loop(){
            if(!over){if(keysDown.ArrowLeft||keysDown.a)player.x=Math.max(5,player.x-5);if(keysDown.ArrowRight||keysDown.d)player.x=Math.min(565,player.x+5);if(keysDown[' '])fire();
                const alive=enemies.filter(e=>e.alive),speed=.22+waveNo*.045+(50-alive.length)*.008;let edge=false;alive.forEach(e=>{e.x+=dir*speed;if(e.x<12||e.x>570)edge=true;});if(edge){dir*=-1;alive.forEach(e=>e.y+=9);}if(Math.random()<.012+waveNo*.002&&alive.length){const e=alive[Math.floor(Math.random()*alive.length)];enemyShots.push({x:e.x+10,y:e.y+10,dy:3+waveNo*.08});}
                shots.forEach(s=>{s.y+=s.dy;});enemyShots.forEach(s=>{s.y+=s.dy;});shots.forEach(s=>{const e=alive.find(e=>e.alive&&s.x>e.x&&s.x<e.x+22&&s.y>e.y&&s.y<e.y+16);if(e){e.alive=false;s.y=-20;score+=10;if(e.power)activate(e.power);}});
                enemyShots.forEach(s=>{const b=barriers.find(b=>b.hp>0&&s.x>b.x&&s.x<b.x+70&&s.y>b.y&&s.y<b.y+18);if(b){b.hp--;s.y=420;}else if(s.y>354&&s.x>player.x&&s.x<player.x+30){s.y=420;if(!active('shield')){lives--;if(lives<=0)over=true;}}});shots=shots.filter(s=>s.y>-10);enemyShots=enemyShots.filter(s=>s.y<410);if(enemies.some(e=>e.alive&&e.y>340))over=true;if(!enemies.some(e=>e.alive)){waveNo++;newWave();}
            }
            const now=performance.now(),activePowers=Object.entries(powers).filter(([,until])=>until>now),powerText=activePowers.map(([kind,until])=>`${kind.toUpperCase()} ${Math.ceil((until-now)/1000)}s`).join(' • ');recordBest(modeKey('invaders'),score,`Score ${score} • Wave ${waveNo}`);root.getElementById('game-status').textContent=over?`Earth fell • Score ${score}`:`Wave ${waveNo} • Lives ${lives} • Score ${score}${powerText?` • ${powerText}`:''}`;ctx.fillStyle='#020207';ctx.fillRect(0,0,600,400);enemies.forEach(e=>{if(e.alive){ctx.fillStyle=e.power?'#ff4':'#f44';ctx.fillRect(e.x,e.y,22,14);ctx.fillRect(e.x+4,e.y-4,4,4);ctx.fillRect(e.x+14,e.y-4,4,4);}});barriers.forEach(b=>{if(b.hp){ctx.fillStyle=`rgb(${120-b.hp*4},${80+b.hp*9},80)`;ctx.fillRect(b.x,b.y,70,18);}});ctx.fillStyle='#ddd';ctx.fillRect(player.x,366,30,10);ctx.fillRect(player.x+12,360,6,6);if(active('shield',now)){ctx.strokeStyle='#4cf';ctx.strokeRect(player.x-5,355,40,25);}ctx.fillStyle='#fff';shots.forEach(s=>ctx.fillRect(s.x,s.y,2,8));ctx.fillStyle='#f33';enemyShots.forEach(s=>ctx.fillRect(s.x,s.y,3,8));raf=requestAnimationFrame(loop);
        }
        const down=e=>{if(['ArrowLeft','ArrowRight','a','d',' '].includes(e.key)){e.preventDefault();keysDown[e.key]=true;}};const up=e=>{keysDown[e.key]=false;};window.addEventListener('keydown',down,true);window.addEventListener('keyup',up,true);root.getElementById('restart').onclick=reset;cleanupGame=()=>{cancelAnimationFrame(raf);window.removeEventListener('keydown',down,true);window.removeEventListener('keyup',up,true);};reset();tabletControls(down,up,{specs:[['←','ArrowLeft'],['Fire',' '],['→','ArrowRight']],drag:e=>{const r=canvas.getBoundingClientRect();player.x=Math.max(5,Math.min(565,(e.clientX-r.left)*600/r.width-15));}});
    }

    function battleshipGame(chaotyk) {
        shell(`Battleship — ${chaotyk ? 'Chaotyk' : 'Original'}`, `<div class="status" id="game-status"></div>${chaotyk ? '<div class="ability-bar"><button class="ability" id="sonar">Sonar Scan (1)</button><button class="ability" id="airstrike">Airstrike (1)</button></div>' : ''}<div class="board-pair"><div class="board-wrap"><div class="board-name">YOUR FLEET</div><div class="cell-board battle-board" id="player-sea"></div></div><div class="board-wrap"><div class="board-name">ENEMY WATERS</div><div class="cell-board battle-board" id="enemy-sea"></div></div></div><button class="action" id="restart">New Battle</button>`, chaotyk ? 'Sonar briefly marks a 3×3 region containing enemy metal. Airstrike attacks a five-cell cross.' : 'Sink the enemy fleet before it sinks yours. Fleets are placed automatically.');
        const lengths = [5, 4, 3, 3, 2];
        let player, enemy, over, sonarUsed, airUsed, airMode, sonarMarks = new Set(), sonarTimer;
        function fleet() {
            const board = Array.from({ length: 100 }, () => ({ ship: -1, hit: false }));
            lengths.forEach((length, ship) => { let cells; do { const vertical = Math.random() < .5, x = Math.floor(Math.random() * (vertical ? 10 : 11 - length)), y = Math.floor(Math.random() * (vertical ? 11 - length : 10)); cells = Array.from({ length }, (_, i) => (y + (vertical ? i : 0)) * 10 + x + (vertical ? 0 : i)); } while (cells.some(i => board[i].ship >= 0)); cells.forEach(i => { board[i].ship = ship; }); });
            return board;
        }
        function reset() { clearTimeout(sonarTimer); player = fleet(); enemy = fleet(); over = false; sonarUsed = airUsed = airMode = false; sonarMarks = new Set(); render('Your turn. Fire on enemy waters.'); }
        function sunk(board, ship) { return board.filter(c => c.ship === ship).every(c => c.hit); }
        function allSunk(board) { return board.filter(c => c.ship >= 0).every(c => c.hit); }
        function shoot(board, i) { if (board[i].hit) return null; board[i].hit = true; return board[i].ship >= 0 ? (sunk(board, board[i].ship) ? 'sunk' : 'hit') : 'miss'; }
        function enemyTurn(note) {
            if (allSunk(enemy)) { over = true; addWin(modeKey('battleship')); render(`${note} You sank the entire enemy fleet!`); return; }
            const choices = player.map((c, i) => c.hit ? -1 : i).filter(i => i >= 0), target = choices[Math.floor(Math.random() * choices.length)], result = shoot(player, target);
            if (allSunk(player)) { over = true; render('The enemy sank your fleet.'); } else render(`${note} Enemy fires: ${result}. Your turn.`);
        }
        function fire(i) {
            if (over || enemy[i].hit) return;
            if (airMode) {
                airMode = false; airUsed = true; const x = i % 10, y = Math.floor(i / 10), targets = [[x,y],[x-1,y],[x+1,y],[x,y-1],[x,y+1]].filter(([a,b]) => a>=0&&a<10&&b>=0&&b<10).map(([a,b]) => b*10+a); let hits = 0; targets.forEach(t => { const r = shoot(enemy, t); if (r === 'hit' || r === 'sunk') hits++; }); enemyTurn(`Airstrike complete: ${hits} hit${hits === 1 ? '' : 's'}.`); return;
            }
            const result = shoot(enemy, i); enemyTurn(`Your shot: ${result}.`);
        }
        function sonar(i) { sonarUsed = true; const x = i % 10, y = Math.floor(i / 10); sonarMarks = new Set(); for (let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++){const nx=x+dx,ny=y+dy;if(nx>=0&&nx<10&&ny>=0&&ny<10&&enemy[ny*10+nx].ship>=0)sonarMarks.add(ny*10+nx);} render(`Sonar detects ${sonarMarks.size} occupied coordinate${sonarMarks.size===1?'':'s'} nearby.`); sonarTimer=setTimeout(()=>{sonarMarks.clear();render('Sonar faded. Fire when ready.');},poweredDuration(1800)); }
        function render(note) {
            root.getElementById('game-status').textContent = note;
            const draw = (id, board, reveal) => { const el=root.getElementById(id); el.innerHTML=board.map((c,i)=>`<button class="battle-cell ${reveal&&c.ship>=0?'ship':''} ${c.hit?(c.ship>=0?'hit':'miss'):''} ${!reveal&&sonarMarks.has(i)?'sonar':''}" data-i="${i}">${c.hit?(c.ship>=0?'×':'•'):''}</button>`).join(''); return el; };
            draw('player-sea',player,true); const enemyEl=draw('enemy-sea',enemy,false); enemyEl.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{const i=Number(b.dataset.i);if(chaotyk&&!sonarUsed&&root.getElementById('sonar')?.classList.contains('active')){root.getElementById('sonar').classList.remove('active');sonar(i);}else fire(i);}));
            if(chaotyk){const s=root.getElementById('sonar'),a=root.getElementById('airstrike');s.disabled=sonarUsed;s.textContent=sonarUsed?'Sonar Used':'Sonar Scan (1)';s.onclick=()=>{airMode=false;s.classList.toggle('active');root.getElementById('game-status').textContent='Click enemy waters to center the sonar scan.';};a.disabled=airUsed;a.textContent=airUsed?'Airstrike Used':'Airstrike (1)';a.onclick=()=>{s.classList.remove('active');airMode=true;root.getElementById('game-status').textContent='Click enemy waters to center the airstrike.';};}
        }
        root.getElementById('restart').addEventListener('click',reset); cleanupGame=()=>clearTimeout(sonarTimer); reset();
    }

    function reversiGame(chaotyk) {
        shell(`Reversi — ${chaotyk ? 'Chaotyk' : 'Original'}`, `<div class="status" id="game-status"></div>${chaotyk?'<div class="ability-bar"><button class="ability" id="corner-pulse">Corner Pulse (1)</button></div>':''}<div class="cell-board reversi-board" id="reversi"></div><button class="action" id="restart">New Match</button>`, chaotyk ? 'You are black. Corner Pulse captures a free corner and adjacent enemy discs once per game.' : 'You are black. Place a disc to trap and flip white discs in any direction.');
        let board,turn,over,pulseUsed,aiTimer;
        const dirs=[-1,1,-8,8,-9,-7,7,9];
        function flips(i,mark){if(board[i])return[];const out=[];for(const d of dirs){const line=[];let n=i+d;while(n>=0&&n<64&&Math.abs((n%8)-((n-d)%8))<=1&&board[n]===-mark){line.push(n);n+=d;}if(line.length&&n>=0&&n<64&&Math.abs((n%8)-((n-d)%8))<=1&&board[n]===mark)out.push(...line);}return out;}
        function legal(mark){return board.map((_,i)=>flips(i,mark).length?i:-1).filter(i=>i>=0);}
        function reset(){clearTimeout(aiTimer);board=Array(64).fill(0);board[27]=board[36]=1;board[28]=board[35]=-1;turn=1;over=false;pulseUsed=false;render('Your turn • Black');}
        function play(i,mark){const captured=flips(i,mark);if(!captured.length)return false;board[i]=mark;captured.forEach(n=>{board[n]=mark;});return true;}
        function afterPlayer(){if(!legal(-1).length){if(!legal(1).length)return finish();render('Computer passes. Your turn.');return;}turn=-1;render('Computer thinking…');aiTimer=setTimeout(aiMove,350);}
        function playerMove(i){if(over||turn!==1||!play(i,1))return;afterPlayer();}
        function aiMove(){const options=legal(-1);if(!options.length){turn=1;if(!legal(1).length)finish();else render('Computer passes. Your turn.');return;}const corners=options.filter(i=>[0,7,56,63].includes(i));const choice=(corners.length?corners:options.sort((a,b)=>flips(b,-1).length-flips(a,-1).length))[0];play(choice,-1);turn=1;if(!legal(1).length){if(!legal(-1).length)return finish();turn=-1;render('No legal move—you pass.');aiTimer=setTimeout(aiMove,500);}else render('Your turn • Black');}
        function pulse(){if(pulseUsed||over||turn!==1)return;const corner=[0,7,56,63].find(i=>!board[i]);if(corner===undefined){render('Every corner is occupied.');return;}pulseUsed=true;board[corner]=1;const x=corner%8,y=Math.floor(corner/8);for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const nx=x+dx,ny=y+dy;if(nx>=0&&nx<8&&ny>=0&&ny<8&&board[ny*8+nx]===-1)board[ny*8+nx]=1;}afterPlayer();}
        function finish(){over=true;const black=board.filter(v=>v===1).length,white=board.filter(v=>v===-1).length;if(black>white)recordBest(modeKey('reversi'),black-white,`Winning margin +${black-white}`);render(black===white?`Draw: ${black}–${white}`:black>white?`You win ${black}–${white}!`:`Computer wins ${white}–${black}.`);}
        function render(note){root.getElementById('game-status').textContent=`${note} • Black ${board.filter(v=>v===1).length} / White ${board.filter(v=>v===-1).length}`;const moves=turn===1&&!over?new Set(legal(1)):new Set();const el=root.getElementById('reversi');el.innerHTML=board.map((v,i)=>`<button class="rev-cell ${moves.has(i)?'legal':''}" data-i="${i}">${v?`<span class="disc ${v===1?'black':'white'}"></span>`:''}</button>`).join('');el.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>playerMove(Number(b.dataset.i))));if(chaotyk){const p=root.getElementById('corner-pulse');p.disabled=pulseUsed;p.onclick=pulse;}}
        root.getElementById('restart').addEventListener('click',reset);cleanupGame=()=>clearTimeout(aiTimer);reset();
    }

    function blackjackGame(chaotyk) {
        shell(`Blackjack — ${chaotyk ? 'Chaotyk' : 'Original'}`, `<div class="status" id="game-status"></div>${chaotyk?'<div class="ability-bar"><button class="ability" id="lucky">Lucky Draw (1)</button><button class="ability" id="shield">Bust Shield (1)</button></div>':''}<div class="hand-area"><div class="hand-label">DEALER</div><div class="playing-cards" id="dealer-hand"></div></div><div class="hand-area"><div class="hand-label">YOUR HAND</div><div class="playing-cards" id="player-hand"></div></div><div class="row"><button class="action" id="hit">Hit</button><button class="action" id="stand">Stand</button><button class="action" id="double">Double</button><button class="action" id="deal">New Hand</button></div>`, chaotyk?'Lucky Draw searches for a safer next card. Bust Shield removes the card that would bust you. Both recharge each hand.':'Dealer stands on 17. Blackjack pays 3:2. Double is available on the first decision.');
        const suits=['♥','♦','♣','♠'],names={1:'A',11:'J',12:'Q',13:'K'};let deck,player,dealer,bank=500,bet=25,ended,lucky,shield,shieldArmed;
        const makeDeck=()=>{const d=suits.flatMap(s=>Array.from({length:13},(_,i)=>({suit:s,rank:i+1})));for(let i=d.length-1;i;i--){const j=Math.floor(Math.random()*(i+1));[d[i],d[j]]=[d[j],d[i]];}return d;};
        const value=hand=>{let total=hand.reduce((n,c)=>n+(c.rank===1?11:Math.min(c.rank,10)),0),aces=hand.filter(c=>c.rank===1).length;while(total>21&&aces--)total-=10;return total;};
        const cardHTML=c=>`<div class="playing-card ${['♥','♦'].includes(c.suit)?'red':''}"><span>${names[c.rank]||c.rank}</span><span>${c.suit}</span></div>`;
        function draw(luckyDraw=false){if(deck.length<12)deck=makeDeck();if(luckyDraw){const room=21-value(player);const i=deck.findIndex(c=>(c.rank===1?1:Math.min(c.rank,10))<=room);if(i>=0)return deck.splice(i,1)[0];}return deck.pop();}
        function deal(){if(bank<bet)bank=500;if(!deck||deck.length<15)deck=makeDeck();bank-=bet;player=[draw(),draw()];dealer=[draw(),draw()];ended=false;lucky=false;shield=false;shieldArmed=false;const p=value(player),d=value(dealer);if(p===21&&d===21){bank+=bet;finish('Both have blackjack—push.');}else if(p===21){bank+=Math.floor(bet*2.5);finish('Blackjack!');}else if(d===21)finish('Dealer blackjack.');else render('Your move.');}
        function hit(){if(ended)return;player.push(draw(lucky));lucky=false;if(value(player)>21){if(chaotyk&&shieldArmed){player.pop();shield=true;shieldArmed=false;render('Bust Shield saved you. Choose again.');}else finish('Bust—you lose.');}else render('Hit or stand?');}
        function stand(){if(ended)return;while(value(dealer)<17)dealer.push(draw());const p=value(player),d=value(dealer);if(d>21||p>d){const blackjack=player.length===2&&p===21;bank+=blackjack?Math.floor(bet*2.5):bet*2;finish(blackjack?'Blackjack!':'You win!');}else if(p===d){bank+=bet;finish('Push.');}else finish('Dealer wins.');}
        function finish(note){ended=true;recordBest(modeKey('blackjack'),bank,`Bank $${bank}`);render(note);}
        function render(note){root.getElementById('game-status').textContent=`${note} • Bank: $${bank} • Bet: $${bet} • Your total: ${value(player)}`;root.getElementById('player-hand').innerHTML=player.map(cardHTML).join('');root.getElementById('dealer-hand').innerHTML=dealer.map((c,i)=>!ended&&i===1?'<div class="playing-card back"></div>':cardHTML(c)).join('');['hit','stand','double'].forEach(id=>{root.getElementById(id).disabled=ended;});root.getElementById('double').disabled=ended||player.length!==2||bank<bet;if(chaotyk){const l=root.getElementById('lucky'),s=root.getElementById('shield');l.disabled=lucky||ended;l.onclick=()=>{lucky=true;render('Lucky Draw armed for your next hit.');};s.disabled=shield||shieldArmed||ended;s.onclick=()=>{shieldArmed=true;render('Bust Shield armed.');};}}
        root.getElementById('hit').onclick=hit;root.getElementById('stand').onclick=stand;root.getElementById('double').onclick=()=>{if(player.length===2&&bank>=bet){bank-=bet;bet*=2;hit();if(!ended)stand();bet=25;}};root.getElementById('deal').onclick=()=>{bet=25;deal();};deal();
    }

    function rummyGame(chaotyk) {
        shell(`Gin Rummy — ${chaotyk ? 'Chaotyk' : 'Original'}`, `<div class="status" id="game-status"></div>${chaotyk?'<div class="ability-bar"><button class="ability" id="wild-token">Wild Token (1)</button><button class="ability" id="chaos-swap">Chaos Swap (1)</button></div>':''}<div class="hand-area"><div class="hand-label">COMPUTER HAND</div><div class="playing-cards" id="cpu-hand"></div></div><div class="row"><div><div class="hand-label">STOCK</div><button class="playing-card back selectable" id="rummy-stock"></button></div><div><div class="hand-label">DISCARD</div><div id="rummy-discard"></div></div></div><div class="hand-area"><div class="hand-label">YOUR HAND</div><div class="playing-cards" id="rummy-hand"></div></div><div class="row"><button class="action" id="take-discard">Take Discard</button><button class="action" id="discard-card">Discard Selected</button><button class="action" id="knock">Knock</button><button class="action" id="restart">New Round</button></div>`, chaotyk?'Wild Token cancels your highest deadwood card for the round. Chaos Swap trades one random card with the opponent.':'Make sets of equal ranks or same-suit runs of three or more. Draw, discard, then knock at 10 deadwood or less. Gin is zero deadwood.');
        const suits=['♥','♦','♣','♠'],names={1:'A',11:'J',12:'Q',13:'K'};let deck,player,cpu,discard,phase,selected,over,wildUsed,wildActive,swapUsed,roundTimer;
        const makeDeck=()=>{const d=suits.flatMap(s=>Array.from({length:13},(_,i)=>({suit:s,rank:i+1,id:`${s}${i+1}`})));for(let i=d.length-1;i;i--){const j=Math.floor(Math.random()*(i+1));[d[i],d[j]]=[d[j],d[i]];}return d;};
        const points=c=>Math.min(c.rank,10);
        function meldMasks(hand){const masks=[];for(let rank=1;rank<=13;rank++){const ids=hand.map((c,i)=>c.rank===rank?i:-1).filter(i=>i>=0);if(ids.length>=3){for(let a=0;a<ids.length;a++)for(let b=a+1;b<ids.length;b++)for(let c=b+1;c<ids.length;c++)masks.push((1<<ids[a])|(1<<ids[b])|(1<<ids[c]));if(ids.length===4)masks.push(ids.reduce((m,i)=>m|(1<<i),0));}}for(const suit of suits){const ids=hand.map((c,i)=>c.suit===suit?i:-1).filter(i=>i>=0).sort((a,b)=>hand[a].rank-hand[b].rank);for(let a=0;a<ids.length;a++){let mask=1<<ids[a];for(let b=a+1;b<ids.length&&hand[ids[b]].rank===hand[ids[b-1]].rank+1;b++){mask|=1<<ids[b];if(b-a+1>=3)masks.push(mask);}}}return masks;}
        function deadwood(hand){const total=hand.reduce((n,c)=>n+points(c),0),masks=meldMasks(hand);let best=0;function search(start,used,value){best=Math.max(best,value);for(let i=start;i<masks.length;i++)if(!(used&masks[i])){let gain=0;for(let n=0;n<hand.length;n++)if(masks[i]&(1<<n))gain+=points(hand[n]);search(i+1,used|masks[i],value+gain);}}search(0,0,0);return total-best;}
        function playerDeadwood(){const base=deadwood(player);return wildActive?Math.max(0,base-Math.max(...player.map(points))):base;}
        const cardHTML=(c,i,selectable=false)=>`<button class="playing-card ${['♥','♦'].includes(c.suit)?'red':''} ${selectable?'selectable':''} ${selected===i?'selected':''}" ${selectable?`data-i="${i}"`:''}><span>${names[c.rank]||c.rank}</span><span>${c.suit}</span></button>`;
        function reset(){clearTimeout(roundTimer);deck=makeDeck();player=deck.splice(-10);cpu=deck.splice(-10);discard=[deck.pop()];phase='draw';selected=null;over=false;wildUsed=wildActive=swapUsed=false;render('Your turn: draw from the stock or take the discard.');}
        function drawStock(){if(over||phase!=='draw')return;if(!deck.length)recycle();if(!deck.length)return finishRound('The stock is exhausted.');player.push(deck.pop());phase='discard';selected=null;render('Select one card to discard.');}
        function takeDiscard(){if(over||phase!=='draw'||!discard.length)return;player.push(discard.pop());phase='discard';selected=null;render('Select one card to discard.');}
        function recycle(){const top=discard.pop();deck=discard.reverse();discard=top?[top]:[];}
        function discardSelected(){if(over||phase!=='discard'||selected===null)return;discard.push(player.splice(selected,1)[0]);selected=null;phase='computer';render('Computer is taking its turn…');roundTimer=setTimeout(cpuTurn,450);}
        function cpuTurn(){if(over)return;const top=discard.at(-1),before=deadwood(cpu),withDiscard=top?deadwood([...cpu,top]):999;if(top&&withDiscard<before){cpu.push(discard.pop());}else{if(!deck.length)recycle();if(deck.length)cpu.push(deck.pop());}let bestIndex=0,best=Infinity;cpu.forEach((_,i)=>{const score=deadwood(cpu.filter((__,n)=>n!==i));if(score<best){best=score;bestIndex=i;}});discard.push(cpu.splice(bestIndex,1)[0]);if(best<=7)return finishRound('The computer knocks.');phase='draw';render('Your turn: draw a card.');}
        function knock(){if(over||phase!=='draw')return;const mine=playerDeadwood();if(mine>10){render(`You need 10 deadwood or less to knock. You have ${mine}.`);return;}finishRound(mine===0?'GIN!':'You knock.');}
        function finishRound(note){over=true;const mine=playerDeadwood(),theirs=deadwood(cpu);let result,points=0;if(mine===0){points=25+theirs;result=`Gin! You win ${points} points.`;}else if(mine<theirs){points=theirs-mine;result=`You win ${points} points.`;}else if(mine===theirs)result='The round is tied.';else result=`Computer wins ${mine-theirs+25} points by undercut.`;if(points)recordBest(modeKey('rummy'),points,`${points} points in one round`);render(`${note} ${result}`);}
        function render(note){root.getElementById('game-status').textContent=`${note} • Your deadwood: ${playerDeadwood()} • Stock: ${deck.length}`;root.getElementById('cpu-hand').innerHTML=over?cpu.map(c=>cardHTML(c)).join(''):cpu.map(()=>'<div class="playing-card back"></div>').join('');root.getElementById('rummy-hand').innerHTML=player.sort((a,b)=>a.suit.localeCompare(b.suit)||a.rank-b.rank).map((c,i)=>cardHTML(c,i,true)).join('');root.querySelectorAll('#rummy-hand button').forEach(b=>b.onclick=()=>{selected=Number(b.dataset.i);render('Card selected.');});root.getElementById('rummy-discard').innerHTML=discard.length?cardHTML(discard.at(-1)):'<div class="playing-card"></div>';root.getElementById('take-discard').disabled=over||phase!=='draw';root.getElementById('discard-card').disabled=over||phase!=='discard'||selected===null;root.getElementById('knock').disabled=over||phase!=='draw';if(chaotyk){const w=root.getElementById('wild-token'),s=root.getElementById('chaos-swap');w.disabled=wildUsed||over;w.onclick=()=>{wildUsed=wildActive=true;render('Wild Token activated: your highest deadwood card is ignored.');};s.disabled=swapUsed||over||phase!=='draw';s.onclick=()=>{swapUsed=true;const a=Math.floor(Math.random()*player.length),b=Math.floor(Math.random()*cpu.length);[player[a],cpu[b]]=[cpu[b],player[a]];render('Chaos Swap traded one hidden card with the computer.');};}}
        root.getElementById('rummy-stock').onclick=drawStock;root.getElementById('take-discard').onclick=takeDiscard;root.getElementById('discard-card').onclick=discardSelected;root.getElementById('knock').onclick=knock;root.getElementById('restart').onclick=reset;cleanupGame=()=>clearTimeout(roundTimer);reset();
    }

    function chessGame() {
        shell('Chess', '<div class="status" id="game-status"></div><div class="row" id="chess-side"><button class="action" data-side="w">Play White</button><button class="action" data-side="b">Play Black</button></div><div id="chess-board" hidden></div><div class="row" id="promotion-choice" hidden><span>Promote to:</span><button class="action" data-piece="q">Queen</button><button class="action" data-piece="r">Rook</button><button class="action" data-piece="b">Bishop</button><button class="action" data-piece="n">Knight</button></div><button class="action" id="restart">New Game</button>', 'Choose White or Black. Full legal movement includes castling, en passant, king-safety checks, and choice of Queen, Rook, Bishop, or Knight on promotion.');
        const glyph={K:'♔',Q:'♕',R:'♖',B:'♗',N:'♘',P:'♙',k:'♚',q:'♛',r:'♜',b:'♝',n:'♞',p:'♟'}, values={p:1,n:3,b:3,r:5,q:9,k:100};
        let board,selected,turn,over,aiTimer,moveCount,playerSide=null,computerSide=null,pendingPromotion=null,castleRights,enPassant;
        const white=p=>p&&p===p.toUpperCase(), color=p=>white(p)?'w':p?'b':null, xy=i=>[i%8,Math.floor(i/8)], at=(x,y)=>x>=0&&x<8&&y>=0&&y<8?y*8+x:-1;
        function freshRights(){return{wK:true,wQ:true,bK:true,bQ:true};}
        const freshBoard=()=>[...'rnbqkbnrpppppppp................................PPPPPPPPRNBQKBNR'].map(piece=>piece==='.'?'':piece);
        function chooseSide(){clearTimeout(aiTimer);playerSide=computerSide=null;pendingPromotion=null;castleRights=freshRights();enPassant=null;board=freshBoard();selected=null;turn='w';over=false;moveCount=0;root.getElementById('chess-side').hidden=false;root.getElementById('chess-board').hidden=true;root.getElementById('promotion-choice').hidden=true;root.getElementById('game-status').textContent='Choose which side to play.';}
        function start(side){playerSide=side;computerSide=side==='w'?'b':'w';castleRights=freshRights();enPassant=null;board=freshBoard();selected=null;turn='w';over=false;moveCount=0;pendingPromotion=null;root.getElementById('chess-side').hidden=true;root.getElementById('chess-board').hidden=false;root.getElementById('promotion-choice').hidden=true;if(playerSide==='w')render('Your move • White');else{render('Computer opening as White…');aiTimer=setTimeout(computerMove,450);}}
        function pseudo(i,b=board,attacks=false){const p=b[i];if(!p)return[];const [x,y]=xy(i),side=color(p),out=[],add=(nx,ny,slide=false)=>{const n=at(nx,ny);if(n<0)return false;if(!b[n]){out.push(n);return slide;}if(color(b[n])!==side)out.push(n);return false;};
            if(p.toLowerCase()==='p'){const d=side==='w'?-1:1,start=side==='w'?6:1;if(attacks){[-1,1].forEach(dx=>{const n=at(x+dx,y+d);if(n>=0)out.push(n);});}else{const one=at(x,y+d);if(one>=0&&!b[one]){out.push(one);const two=at(x,y+2*d);if(y===start&&two>=0&&!b[two])out.push(two);}[-1,1].forEach(dx=>{const n=at(x+dx,y+d);if(n>=0&&((b[n]&&color(b[n])!==side)||(b===board&&n===enPassant)))out.push(n);});}}
            else if(p.toLowerCase()==='n')[[1,2],[2,1],[-1,2],[-2,1],[1,-2],[2,-1],[-1,-2],[-2,-1]].forEach(([dx,dy])=>add(x+dx,y+dy));
            else if(p.toLowerCase()==='k'){for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++)if(dx||dy)add(x+dx,y+dy);}
            else{const dirs=p.toLowerCase()==='b'?[[1,1],[-1,1],[1,-1],[-1,-1]]:p.toLowerCase()==='r'?[[1,0],[-1,0],[0,1],[0,-1]]:[[1,1],[-1,1],[1,-1],[-1,-1],[1,0],[-1,0],[0,1],[0,-1]];dirs.forEach(([dx,dy])=>{let n=1;while(add(x+dx*n,y+dy*n,true))n++;});}return out;}
        function attacked(square,by,b=board){return b.some((p,i)=>p&&color(p)===by&&pseudo(i,b,true).includes(square));}
        function inCheck(side,b=board){const king=b.findIndex(p=>p===(side==='w'?'K':'k'));return king<0||attacked(king,side==='w'?'b':'w',b);}
        function castleMoves(i){const p=board[i],side=color(p),enemy=side==='w'?'b':'w',home=side==='w'?60:4;if(p?.toLowerCase()!=='k'||i!==home||inCheck(side))return[];const out=[];
            if(castleRights[side+'K']&&board[home+3]===(side==='w'?'R':'r')&&!board[home+1]&&!board[home+2]&&!attacked(home+1,enemy)&&!attacked(home+2,enemy))out.push(home+2);
            if(castleRights[side+'Q']&&board[home-4]===(side==='w'?'R':'r')&&!board[home-1]&&!board[home-2]&&!board[home-3]&&!attacked(home-1,enemy)&&!attacked(home-2,enemy))out.push(home-2);
            return out;}
        function simulate(b,from,to,promote=true,ep=b===board?enPassant:null){const copy=b.slice(),piece=copy[from];if(piece?.toLowerCase()==='p'&&to===ep&&!copy[to]&&Math.abs(to-from)%8!==0)copy[to+(piece==='P'?8:-8)]='';copy[to]=piece;copy[from]='';if(piece?.toLowerCase()==='k'&&Math.abs(to-from)===2){if(to>from){copy[from+1]=copy[from+3];copy[from+3]='';}else{copy[from-1]=copy[from-4];copy[from-4]='';}}if(promote&&copy[to]==='P'&&to<8)copy[to]='Q';if(promote&&copy[to]==='p'&&to>=56)copy[to]='q';return copy;}
        function legal(i,b=board){const side=color(b[i]),moves=pseudo(i,b);if(b===board)moves.push(...castleMoves(i));return moves.filter(to=>!inCheck(side,simulate(b,i,to)));}
        function allMoves(side){const moves=[];board.forEach((p,i)=>{if(color(p)===side)legal(i).forEach(to=>moves.push([i,to]));});return moves;}
        function move(from,to,autoQueen=false){const piece=board[from],captured=board[to],nextEnPassant=piece?.toLowerCase()==='p'&&Math.abs(to-from)===16?(from+to)/2:null;if(piece==='K'){castleRights.wK=castleRights.wQ=false;}if(piece==='k'){castleRights.bK=castleRights.bQ=false;}if(from===63||(to===63&&captured==='R'))castleRights.wK=false;if(from===56||(to===56&&captured==='R'))castleRights.wQ=false;if(from===7||(to===7&&captured==='r'))castleRights.bK=false;if(from===0||(to===0&&captured==='r'))castleRights.bQ=false;board=simulate(board,from,to,autoQueen);enPassant=nextEnPassant;selected=null;}
        function finishState(side){const moves=allMoves(side);if(moves.length)return false;over=true;if(inCheck(side)){if(side===computerSide){recordBest('chess',moveCount,`Checkmate in ${moveCount} move${moveCount===1?'':'s'} as ${playerSide==='w'?'White':'Black'}`,true);render(`Checkmate! You win in ${moveCount} moves.`);}else render('Checkmate • Computer wins.');}else render('Stalemate • Draw.');return true;}
        function finishPlayerMove(){pendingPromotion=null;root.getElementById('promotion-choice').hidden=true;turn=computerSide;render(inCheck(computerSide)?'Check • Computer thinking…':'Computer thinking…');if(!finishState(computerSide))aiTimer=setTimeout(computerMove,450);}
        function click(i){if(over||turn!==playerSide||pendingPromotion!==null)return;if(selected!==null&&legal(selected).includes(i)){const piece=board[selected];move(selected,i);moveCount++;const promotes=(piece==='P'&&i<8)||(piece==='p'&&i>=56);if(promotes){pendingPromotion=i;root.getElementById('promotion-choice').hidden=false;render('Choose a promotion piece.');}else finishPlayerMove();return;}selected=board[i]&&color(board[i])===playerSide?i:null;render(`Your move • ${playerSide==='w'?'White':'Black'}`);}
        function promote(piece){if(pendingPromotion===null)return;board[pendingPromotion]=playerSide==='w'?piece.toUpperCase():piece;finishPlayerMove();}
        function computerMove(){if(over)return;const moves=allMoves(computerSide);if(!moves.length)return finishState(computerSide);let best=-Infinity,choices=[];moves.forEach(m=>{const target=board[m[1]],copy=simulate(board,m[0],m[1]);let score=(target?values[target.toLowerCase()]*10:0)+Math.random()*3;if(board[m[0]]?.toLowerCase()==='k'&&Math.abs(m[1]-m[0])===2)score+=3;if(inCheck(playerSide,copy))score+=2;if(score>best){best=score;choices=[m];}else if(score===best)choices.push(m);});move(...choices[Math.floor(Math.random()*choices.length)],true);turn=playerSide;if(!finishState(playerSide))render(inCheck(playerSide)?`Check! Your move • ${playerSide==='w'?'White':'Black'}`:`Your move • ${playerSide==='w'?'White':'Black'}`);}
        function render(note){root.getElementById('game-status').textContent=note;if(!playerSide)return;const moves=selected===null?[]:legal(selected),el=root.getElementById('chess-board'),order=playerSide==='w'?[...Array(64).keys()]:[...Array(64).keys()].reverse();el.innerHTML=order.map(i=>{const p=board[i];return `<button class="chess-cell ${(Math.floor(i/8)+i%8)%2?'dark':'light'} ${selected===i?'selected':''} ${moves.includes(i)?(p?'capture':'legal'):''}" data-i="${i}" ${turn!==playerSide||over||pendingPromotion!==null?'disabled':''}>${glyph[p]||''}</button>`;}).join('');el.querySelectorAll('button').forEach(b=>b.onclick=()=>click(Number(b.dataset.i)));}
        root.querySelectorAll('#chess-side button').forEach(b=>b.onclick=()=>start(b.dataset.side));root.querySelectorAll('#promotion-choice button').forEach(b=>b.onclick=()=>promote(b.dataset.piece));root.getElementById('restart').onclick=chooseSide;cleanupGame=()=>clearTimeout(aiTimer);chooseSide();
    }

    function videoPokerGame() {
        shell('Classic Video Poker', '<div class="status" id="game-status"></div><div class="poker-paytable" id="poker-paytable"></div><div class="playing-cards" id="poker-hand"></div><div class="row poker-controls"><button class="action" id="poker-deal">Deal</button><button class="action" id="poker-draw">First Draw</button></div>', 'Jacks or Better • Bet 5 credits each hand. Hold cards before each of two draw rounds. The hand pays after the final draw. Royal Flush pays 4,000 credits.');
        const suits=['♠','♥','♦','♣'],names={11:'J',12:'Q',13:'K',14:'A'},payouts=[['Royal Flush',800],['Straight Flush',50],['Four of a Kind',25],['Full House',9],['Flush',6],['Straight',4],['Three of a Kind',3],['Two Pair',2],['Jacks or Better',1]],bet=5;
        let credits=100,deck,hand=[],held=new Set(),phase='deal',lastRank='';
        function makeDeck(){const d=suits.flatMap(s=>Array.from({length:13},(_,i)=>({s,rank:i+2})));for(let i=d.length-1;i;i--){const j=Math.floor(Math.random()*(i+1));[d[i],d[j]]=[d[j],d[i]];}return d;}
        function evaluate(cards){const ranks=cards.map(c=>c.rank).sort((a,b)=>a-b),counts={};ranks.forEach(r=>counts[r]=(counts[r]||0)+1);const groups=Object.values(counts).sort((a,b)=>b-a),flush=cards.every(c=>c.s===cards[0].s),unique=[...new Set(ranks)],straight=unique.length===5&&(unique[4]-unique[0]===4||unique.join(',')==='2,3,4,5,14'),royal=flush&&ranks.join(',')==='10,11,12,13,14';if(royal)return payouts[0];if(flush&&straight)return payouts[1];if(groups[0]===4)return payouts[2];if(groups[0]===3&&groups[1]===2)return payouts[3];if(flush)return payouts[4];if(straight)return payouts[5];if(groups[0]===3)return payouts[6];if(groups[0]===2&&groups[1]===2)return payouts[7];const pair=Object.keys(counts).find(r=>counts[r]===2&&Number(r)>=11);return pair?payouts[8]:['No Win',0];}
        function deal(){if(phase!=='deal')return;if(credits<bet)credits=100;credits-=bet;deck=makeDeck();hand=deck.splice(-5);held.clear();phase='draw1';lastRank='';render('First draw: choose cards to hold.');}
        function draw(){if(!phase.startsWith('draw'))return;hand=hand.map((c,i)=>held.has(i)?c:deck.pop());if(phase==='draw1'){held.clear();phase='draw2';render('Second draw: choose cards to hold again, then press Final Draw.');return;}const [rank,mult]=evaluate(hand),won=mult*bet;credits+=won;lastRank=rank;held.clear();phase='deal';recordBest('poker',credits,`Bank ${credits} credits${won?` • ${rank}`:''}`);render(won?`${rank}! You won ${won} credits.`:'No winning hand.');}
        function toggle(i){if(!phase.startsWith('draw'))return;held.has(i)?held.delete(i):held.add(i);render(phase==='draw1'?'First draw: choose cards to hold.':'Second draw: choose cards to hold, then press Final Draw.');}
        function render(note){root.getElementById('game-status').textContent=`${note} • Credits: ${credits} • Bet: ${bet}`;root.getElementById('poker-paytable').innerHTML=payouts.map(([name,m])=>`<span class="${name===lastRank?'active':''}">${name}</span><span class="${name===lastRank?'active':''}">${m*bet}</span>`).join('');root.getElementById('poker-hand').innerHTML=hand.map((c,i)=>`<button class="playing-card selectable poker-card ${['♥','♦'].includes(c.s)?'red':''} ${held.has(i)?'selected':''}" data-i="${i}"><span>${names[c.rank]||c.rank}</span><span>${c.s}</span>${held.has(i)?'<span class="hold-tag">HOLD</span>':''}</button>`).join('');root.querySelectorAll('#poker-hand button').forEach(b=>b.onclick=()=>toggle(Number(b.dataset.i)));root.getElementById('poker-deal').disabled=phase!=='deal';const drawButton=root.getElementById('poker-draw');drawButton.disabled=!phase.startsWith('draw');drawButton.textContent=phase==='draw2'?'Final Draw':'First Draw';}
        root.getElementById('poker-deal').onclick=deal;root.getElementById('poker-draw').onclick=draw;recordBest('poker',credits,`Bank ${credits} credits`);render('Press Deal to begin.');
    }

    function yahtzeeGame(chaotyk) {
        const categories=[['ones','Ones'],['twos','Twos'],['threes','Threes'],['fours','Fours'],['fives','Fives'],['sixes','Sixes'],['threeKind','Three of a Kind'],['fourKind','Four of a Kind'],['fullHouse','Full House'],['smallStraight','Small Straight'],['largeStraight','Large Straight'],['yahtzee','Yahtzee'],['chance','Chance']];
        shell(`Yahtzee — ${chaotyk?'Chaotyk':'Original'}`,`<div class="status" id="game-status"></div>${chaotyk?'<div class="ability-bar"><button class="ability" id="extra-roll">Extra Roll (1)</button><button class="ability" id="wild-six">Wild Six (1)</button></div>':''}<div class="yahtzee-layout"><div class="dice-area"><div class="dice-row" id="dice-row"></div><button class="action" id="roll-dice">Roll Dice</button><button class="action" id="new-yahtzee">New Game</button></div><div class="yahtzee-card" id="yahtzee-card"></div></div>`,chaotyk?'Up to three rolls each turn. Extra Roll grants a fourth roll once; Wild Six changes one selected die to a six.':'Up to three rolls each turn. Click dice to hold them, then choose one scorecard category.');
        let dice,held,rolls,scores,turn,over,extraUsed,wildUsed,extraActive;
        const counts=()=>Array.from({length:7},(_,n)=>dice.filter(v=>v===n).length),sum=()=>dice.reduce((a,b)=>a+b,0);
        function value(key){const c=counts(),unique=[...new Set(dice)].sort(),serial=unique.join('');if(['ones','twos','threes','fours','fives','sixes'].includes(key)){const n=['ones','twos','threes','fours','fives','sixes'].indexOf(key)+1;return c[n]*n;}if(key==='threeKind')return Math.max(...c)>=3?sum():0;if(key==='fourKind')return Math.max(...c)>=4?sum():0;if(key==='fullHouse')return c.includes(3)&&c.includes(2)?25:0;if(key==='smallStraight')return ['1234','2345','3456'].some(s=>[...s].every(n=>unique.includes(Number(n))))?30:0;if(key==='largeStraight')return serial==='12345'||serial==='23456'?40:0;if(key==='yahtzee')return Math.max(...c)===5?50:0;return sum();}
        function total(){const upper=categories.slice(0,6).reduce((n,[k])=>n+(scores[k]??0),0),base=Object.values(scores).reduce((a,b)=>a+b,0);return{upper,bonus:upper>=63?35:0,total:base+(upper>=63?35:0)};}
        function reset(){dice=[1,1,1,1,1];held=new Set();rolls=0;scores={};turn=1;over=false;extraUsed=wildUsed=extraActive=false;render('Press Roll Dice to begin.');}
        function roll(){if(over)return;const limit=extraActive?4:3;if(rolls>=limit)return;dice=dice.map((v,i)=>held.has(i)?v:1+Math.floor(Math.random()*6));rolls++;render(`Roll ${rolls} of ${limit}. Hold dice or choose a category.`);}
        function toggle(i){if(!rolls||over)return;held.has(i)?held.delete(i):held.add(i);render('Holds updated. Roll again or score this turn.');}
        function score(key){if(over||!rolls||scores[key]!==undefined)return;scores[key]=value(key);turn++;rolls=0;held.clear();extraActive=false;if(Object.keys(scores).length===categories.length){over=true;const t=total().total;recordBest(modeKey('yahtzee'),t,`Score ${t}`);render(`Game complete! Final score: ${t}.`);}else render(`Category scored. Turn ${turn} of 13 — roll when ready.`);}
        function render(note){const t=total();root.getElementById('game-status').textContent=`${note} • Total: ${t.total}`;root.getElementById('dice-row').innerHTML=dice.map((v,i)=>`<button class="die ${held.has(i)?'held':''}" data-i="${i}">${v}</button>`).join('');root.querySelectorAll('.die').forEach(b=>b.onclick=()=>toggle(Number(b.dataset.i)));root.getElementById('roll-dice').disabled=over||rolls>=(extraActive?4:3);root.getElementById('yahtzee-card').innerHTML=categories.map(([k,label])=>`<div class="score-choice"><button data-key="${k}" ${scores[k]!==undefined||!rolls?'disabled':''}><span>${label}</span><strong>${scores[k]??(rolls?value(k):'—')}</strong></button></div>`).join('')+`<div class="score-total"><span>Upper Bonus</span><span>${t.bonus}</span></div><div class="score-total"><span>Total</span><span>${t.total}</span></div>`;root.querySelectorAll('.score-choice button').forEach(b=>b.onclick=()=>score(b.dataset.key));if(chaotyk){const e=root.getElementById('extra-roll'),w=root.getElementById('wild-six');e.disabled=extraUsed||over||rolls===0;e.onclick=()=>{extraUsed=extraActive=true;render('Extra Roll activated — this turn allows four rolls.');};w.disabled=wildUsed||over||held.size!==1;w.onclick=()=>{const i=[...held][0];dice[i]=6;wildUsed=true;render('Wild Six changed the selected die to six.');};}}
        root.getElementById('roll-dice').onclick=roll;root.getElementById('new-yahtzee').onclick=reset;reset();
    }

    function match3Game(chaotyk) {
        const icons=['◆','●','▲','★','⬟','✦'],size=8;
        shell(`GigaGems — ${chaotyk?'Chaotyk':'Original'}`,`<div class="status" id="game-status"></div><div class="match3-layout"><div class="match3-board" id="match3-board"></div><div class="match3-side">${chaotyk?'<button class="ability" id="gem-shuffle">Shuffle (1)</button><button class="ability" id="gem-blast">Detonate (1)</button>':''}<button class="action" id="new-gems">New Game</button></div></div>`,chaotyk?'35 moves. Matches of four create line gems; five create blast gems. Shuffle or detonate once per game.':'30 moves. Swap adjacent gems to make matches of three or more. Cascades multiply the score.');
        let board,selected,score,moves,over,shuffleUsed,blastUsed,busy;
        const gem=()=>({color:Math.floor(Math.random()*icons.length),special:''}),swap=(a,b)=>{[board[a],board[b]]=[board[b],board[a]];};
        function matches(){const out=new Set(),runs=[];for(let y=0;y<size;y++){let start=0;for(let x=1;x<=size;x++)if(x===size||board[y*size+x]?.color!==board[y*size+start]?.color){if(x-start>=3){const run=Array.from({length:x-start},(_,n)=>y*size+start+n);run.forEach(i=>out.add(i));runs.push(run);}start=x;}}for(let x=0;x<size;x++){let start=0;for(let y=1;y<=size;y++)if(y===size||board[y*size+x]?.color!==board[start*size+x]?.color){if(y-start>=3){const run=Array.from({length:y-start},(_,n)=>(start+n)*size+x);run.forEach(i=>out.add(i));runs.push(run);}start=y;}}return{out,runs};}
        function cleanStart(){do{board=Array.from({length:64},gem);}while(matches().out.size);}
        function expandSpecials(clear){const expanded=new Set(clear);[...clear].forEach(i=>{const s=board[i]?.special;if(s==='row')for(let x=0;x<8;x++)expanded.add(Math.floor(i/8)*8+x);if(s==='col')for(let y=0;y<8;y++)expanded.add(y*8+i%8);if(s==='blast'){const x=i%8,y=Math.floor(i/8);for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++)if(x+dx>=0&&x+dx<8&&y+dy>=0&&y+dy<8)expanded.add((y+dy)*8+x+dx);}});return expanded;}
        function collapse(){for(let x=0;x<8;x++){const col=[];for(let y=7;y>=0;y--)if(board[y*8+x])col.push(board[y*8+x]);while(col.length<8)col.push(gem());for(let y=7;y>=0;y--)board[y*8+x]=col[7-y];}}
        function resolve(seed=null){let chain=0;while(true){const found=matches();if(!found.out.size)break;chain++;let clear=expandSpecials(found.out),created=null;if(chaotyk&&seed!==null&&clear.has(seed)){const longest=found.runs.filter(r=>r.includes(seed)).sort((a,b)=>b.length-a.length)[0];if(longest?.length>=4)created={index:seed,gem:{color:board[seed].color,special:longest.length>=5?'blast':(Math.floor(longest[0]/8)===Math.floor(longest[1]/8)?'row':'col')}};}score+=clear.size*10*chain;clear.forEach(i=>board[i]=null);if(created)board[created.index]=created.gem;collapse();seed=null;}recordBest(modeKey('match3'),score,`Score ${score}`);}
        function hasMove(){for(let i=0;i<64;i++)for(const j of [i+1,i+8])if(j<64&&(j===i+8||i%8<7)){swap(i,j);const ok=matches().out.size>0;swap(i,j);if(ok)return true;}return false;}
        function mix(){do{for(let i=63;i;i--){const j=Math.floor(Math.random()*(i+1));swap(i,j);}}while(matches().out.size||!hasMove());}
        function reset(){cleanStart();selected=null;score=0;moves=chaotyk?35:30;over=false;shuffleUsed=blastUsed=busy=false;render('Select a gem, then an adjacent gem to swap.');}
        function click(i){if(over||busy)return;if(selected===null){selected=i;render('Now select an adjacent gem.');return;}const a=selected;selected=null;if(a===i){render('Selection cleared.');return;}if(Math.abs(a-i)!==8&&!(Math.abs(a-i)===1&&Math.floor(a/8)===Math.floor(i/8))){selected=i;render('Gems must be adjacent.');return;}swap(a,i);if(!matches().out.size){swap(a,i);render('That swap does not create a match.');return;}moves--;resolve(i);if(!hasMove())mix();if(moves<=0){over=true;recordBest(modeKey('match3'),score,`Score ${score}`);render(`Game over — final score ${score}.`);}else render('Cascade complete. Make another match.');}
        function render(note){root.getElementById('game-status').textContent=`${note} • Score: ${score} • Moves: ${moves}`;root.getElementById('match3-board').innerHTML=board.map((g,i)=>`<button class="gem g${g.color} ${g.special?'special':''} ${selected===i?'selected':''}" data-i="${i}">${icons[g.color]}${g.special==='row'?'↔':g.special==='col'?'↕':g.special==='blast'?'✹':''}</button>`).join('');root.querySelectorAll('.gem').forEach(b=>b.onclick=()=>click(Number(b.dataset.i)));if(chaotyk){const s=root.getElementById('gem-shuffle'),d=root.getElementById('gem-blast');s.disabled=shuffleUsed||over;s.onclick=()=>{shuffleUsed=true;selected=null;mix();render('Board shuffled.');};d.disabled=blastUsed||over||selected===null;d.onclick=()=>{blastUsed=true;const center=selected,x=center%8,y=Math.floor(center/8);for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++)if(x+dx>=0&&x+dx<8&&y+dy>=0&&y+dy<8)board[(y+dy)*8+x+dx]=null;score+=90;selected=null;collapse();resolve();render('Detonation cleared a 3×3 area.');};}}
        root.getElementById('new-gems').onclick=reset;reset();
    }

    function tttGame() {
        shell('Tic-Tac-Toe', '<div class="status" id="game-status">You are X</div><div id="ttt-board"></div><button class="action" id="restart">New Round</button>', 'Who starts alternates each round. The computer plays smart, but not perfectly.');
        let board, ended, playerTurn, round = 0, aiTimer;
        const wins = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
        const winner = mark => wins.some(line => line.every(i => board[i] === mark));
        function reset() { clearTimeout(aiTimer); board = Array(9).fill(''); ended = false; round++; playerTurn = round % 2 === 1; render(); if (!playerTurn) { root.getElementById('game-status').textContent = 'Computer starts this round…'; aiTimer = setTimeout(computerMove, 350); } else root.getElementById('game-status').textContent = 'Your turn • You are X'; }
        function play(i) {
            if (ended || !playerTurn || board[i]) return; board[i] = 'X'; playerTurn = false;
            if (finish('X')) return; render(); root.getElementById('game-status').textContent = 'Computer thinking…'; aiTimer = setTimeout(computerMove, 300);
        }
        function computerMove() {
            if (ended) return; const empty = board.map((v, n) => v ? -1 : n).filter(n => n >= 0); if (!empty.length) return finish();
            let choice;
            if (Math.random() < .68) {
                choice = empty.find(n => { board[n] = 'O'; const win = winner('O'); board[n] = ''; return win; });
                if (choice === undefined) choice = empty.find(n => { board[n] = 'X'; const block = winner('X'); board[n] = ''; return block; });
                if (choice === undefined && empty.includes(4)) choice = 4;
            }
            if (choice === undefined) choice = empty[Math.floor(Math.random() * empty.length)];
            board[choice] = 'O'; playerTurn = true; if (!finish('O')) root.getElementById('game-status').textContent = 'Your turn • You are X'; render();
        }
        function finish(mark) { if (mark && winner(mark)) { ended = true; if (mark === 'X') addWin('ttt'); root.getElementById('game-status').textContent = mark === 'X' ? 'You win!' : 'Computer wins.'; render(); return true; } if (board.every(Boolean)) { ended = true; root.getElementById('game-status').textContent = 'Draw game.'; render(); return true; } return false; }
        function render() { const el = root.getElementById('ttt-board'); el.innerHTML = board.map((v, i) => `<button class="ttt-cell" data-i="${i}">${v}</button>`).join(''); el.querySelectorAll('button').forEach(b => b.addEventListener('click', () => play(Number(b.dataset.i)))); }
        root.getElementById('restart').addEventListener('click', reset); cleanupGame = () => clearTimeout(aiTimer); reset();
    }
window.arcadeImport=text=>{try{const parsed=JSON.parse(text),input=parsed?.results||parsed;if(!input||typeof input!=='object'||Array.isArray(input))throw Error('Invalid leaderboard');const result={};for(const [key] of resultRows){const v=input[key];if(v&&Number.isFinite(v.value)&&typeof v.label==='string')result[key]={value:v.value,label:v.label.slice(0,500),updated:typeof v.updated==='string'?v.updated.slice(0,100):new Date().toISOString()};}saveLeaderboard(result);showLeaderboard();}catch(e){alert('Could not import leaderboard: '+e.message);}};
    window.arcadeBack=()=>{if(currentGame||!root.getElementById('menu'))showMenu();else window.ArcadeNative?.exit();};
    window.arcadeMenu=showMenu;
    openArcade();
}());
