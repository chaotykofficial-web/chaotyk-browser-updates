#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_SDK_ROOT:?Set ANDROID_SDK_ROOT}"
BT="$ANDROID_SDK_ROOT/build-tools/35.0.0"
ANDROID="$ANDROID_SDK_ROOT/platforms/android-35/android.jar"
: "${ARCADE_KEYSTORE_PASSWORD:?Set ARCADE_KEYSTORE_PASSWORD to the private signing password}"
mkdir -p build/{generated,classes,resources,dex}
"$BT/aapt2" compile --dir app/src/main/res -o build/resources/
"$BT/aapt2" link -o build/resources.apk -I "$ANDROID" --manifest app/src/main/AndroidManifest.xml --version-code 2 --version-name 1.0.1 --auto-add-overlay --java build/generated -A app/src/main/assets build/resources/*.flat
javac -source 8 -target 8 -cp "$ANDROID" -d build/classes app/src/main/java/com/chaotyk/arcade/*.java build/generated/com/chaotyk/arcade/R.java
jar cf build/app.jar -C build/classes .
"$BT/d8" --min-api 26 --lib "$ANDROID" --output build/dex build/app.jar
cp build/resources.apk build/unsigned.apk
(cd build/dex && zip -q ../unsigned.apk classes*.dex)
"$BT/zipalign" -f 4 build/unsigned.apk build/aligned.apk
"$BT/apksigner" sign --ks signing/chaotyk-arcade.jks --ks-pass env:ARCADE_KEYSTORE_PASSWORD --key-pass env:ARCADE_KEYSTORE_PASSWORD --out Chaotyk-Arcade-1.0.1.apk build/aligned.apk
"$BT/apksigner" verify --verbose Chaotyk-Arcade-1.0.1.apk
