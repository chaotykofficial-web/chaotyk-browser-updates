window.GM_getValue=(key,fallback)=>{try{const value=localStorage.getItem(key);return value===null?fallback:JSON.parse(value);}catch(e){return fallback;}};
window.GM_setValue=(key,value)=>{localStorage.setItem(key,JSON.stringify(value));};
(()=>{const realNow=performance.now.bind(performance),realDate=Date.now;let offset=0,pausedAt=null;Object.defineProperty(performance,'now',{value:()=> (pausedAt===null?realNow():pausedAt)-offset});Date.now=()=>realDate()-offset;
window.arcadeSuspend=()=>{if(pausedAt===null)pausedAt=realNow();window.dispatchEvent(new Event('blur'));document.getElementById('resume').style.display='flex';};
window.arcadeResume=()=>{if(pausedAt!==null){offset+=realNow()-pausedAt;pausedAt=null;}document.getElementById('resume').style.display='none';window.ArcadeNative?.resumeGame();};
addEventListener('DOMContentLoaded',()=>document.getElementById('resume-button').onclick=window.arcadeResume);
})();