package com.chaotyk.arcade;
import org.json.*;
import java.io.*;
import java.net.*;
import java.math.BigInteger;
import java.util.*;

final class ScriptUpdateClient {
  static void requireHttps(String value)throws Exception{URL url=new URL(value);if(!"https".equalsIgnoreCase(url.getProtocol())||url.getUserInfo()!=null||url.getHost().isEmpty())throw new IOException("Updates require an HTTPS URL without embedded credentials.");}
  static int compareVersions(String a,String b)throws Exception{
    if(!a.matches("[0-9]+(?:\\.[0-9]+)*(?:-[A-Za-z0-9.-]+)?(?:\\+[A-Za-z0-9.-]+)?")||!b.matches("[0-9]+(?:\\.[0-9]+)*(?:-[A-Za-z0-9.-]+)?(?:\\+[A-Za-z0-9.-]+)?"))throw new IOException("Cannot compare app versions: use numeric versions such as 1.2.3.");
    String[] aa=a.split("\\+",2)[0].split("-",2),bb=b.split("\\+",2)[0].split("-",2),ac=aa[0].split("\\."),bc=bb[0].split("\\.");
    for(int i=0;i<Math.max(ac.length,bc.length);i++){int n=new BigInteger(i<ac.length?ac[i]:"0").compareTo(new BigInteger(i<bc.length?bc[i]:"0"));if(n!=0)return n;}
    if(aa.length!=bb.length)return aa.length==1?1:-1;if(aa.length==1)return 0;
    String[] ap=aa[1].split("\\."),bp=bb[1].split("\\.");
    for(int i=0;i<Math.min(ap.length,bp.length);i++){if(ap[i].equals(bp[i]))continue;boolean an=ap[i].matches("[0-9]+"),bn=bp[i].matches("[0-9]+");if(an&&bn)return new BigInteger(ap[i]).compareTo(new BigInteger(bp[i]));if(an!=bn)return an?-1:1;return ap[i].compareTo(bp[i]);}return Integer.compare(ap.length,bp.length);
  }
  interface Cookies {String get(String url);}
  static String fetch(String initial,Cookies cookies)throws Exception{
    String url=initial;
    for(int redirects=0;redirects<6;redirects++){
      requireHttps(url);HttpURLConnection connection=(HttpURLConnection)new URL(url).openConnection();connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(15000);connection.setReadTimeout(15000);connection.setRequestProperty("Cache-Control","no-cache");connection.setRequestProperty("Accept","text/plain, application/javascript, */*");String cookie=cookies.get(url);if(cookie!=null&&!cookie.isEmpty())connection.setRequestProperty("Cookie",cookie);
      try{int status=connection.getResponseCode();if(Arrays.asList(301,302,303,307,308).contains(status)){String next=connection.getHeaderField("Location");if(next==null)throw new IOException("Update redirect has no destination.");url=new URL(new URL(url),next).toString();continue;}if(status!=200)throw new IOException("Update server returned HTTP "+status+".");try(InputStream in=connection.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] bytes=new byte[8192];int n;while((n=in.read(bytes))!=-1){out.write(bytes,0,n);if(out.size()>2_000_000)throw new IOException("Update exceeds 2 MB.");}return out.toString("UTF-8");}}finally{connection.disconnect();}
    }
    throw new IOException("Too many update redirects.");
  }
}
