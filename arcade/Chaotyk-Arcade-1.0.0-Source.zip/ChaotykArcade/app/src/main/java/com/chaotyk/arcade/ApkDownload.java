package com.chaotyk.arcade;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

/** Public HTTPS APK downloads, including Google Drive share links/confirmation forms. */
final class ApkDownload {
  static final long MAX_BYTES=150_000_000L;
  interface Progress {void update(long received,long expected)throws IOException;}
  static Map<String,String> query(String raw)throws Exception{Map<String,String> result=new LinkedHashMap<>();if(raw!=null)for(String pair:raw.split("&")){String[] kv=pair.split("=",2);result.put(URLDecoder.decode(kv[0],"UTF-8"),kv.length==1?"":URLDecoder.decode(kv[1],"UTF-8"));}return result;}
  static String enc(String value)throws Exception{return URLEncoder.encode(value,"UTF-8");}
  static String normalize(String value)throws Exception{
    ScriptUpdateClient.requireHttps(value);URL u=new URL(value);
    if(!u.getHost().equalsIgnoreCase("drive.google.com"))return value;
    Map<String,String> parameters=query(u.getQuery());String id=parameters.get("id");Matcher path=Pattern.compile("^/file/d/([A-Za-z0-9_-]+)(?:/.*)?$").matcher(u.getPath());if(path.matches())id=path.group(1);
    if(id==null||!id.matches("[A-Za-z0-9_-]+"))throw new IOException("Drive link does not contain a file ID.");
    return "https://drive.usercontent.google.com/download?id="+enc(id)+"&export=download&confirm=t"+(parameters.containsKey("resourcekey")?"&resourcekey="+enc(parameters.get("resourcekey")):"");
  }
  static String unescape(String value){return value.replace("&amp;","&").replace("&#38;","&").replace("&quot;","\"").replace("&#39;","'").replace("&lt;","<").replace("&gt;",">");}
  static Map<String,String> attributes(String tag){Map<String,String> attributes=new HashMap<>();Matcher m=Pattern.compile("([A-Za-z0-9_-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))").matcher(tag);while(m.find())attributes.put(m.group(1).toLowerCase(Locale.ROOT),unescape(m.group(2)!=null?m.group(2):m.group(3)!=null?m.group(3):m.group(4)));return attributes;}
  static boolean driveDownload(URL u){return "https".equals(u.getProtocol())&&(u.getHost().equals("drive.google.com")||u.getHost().equals("drive.usercontent.google.com"))&&(u.getPath().equals("/download")||u.getPath().equals("/uc"));}
  static String confirmation(String html,String base)throws Exception{
    Matcher forms=Pattern.compile("(?is)<form\\b([^>]*)>(.*?)</form>").matcher(html);
    while(forms.find()){
      Map<String,String> attrs=attributes(forms.group(1));if(!attrs.containsKey("action"))continue;URL action=new URL(new URL(base),attrs.get("action"));if(!driveDownload(action)||!attrs.getOrDefault("method","get").equalsIgnoreCase("get"))continue;
      StringBuilder query=new StringBuilder();Matcher inputs=Pattern.compile("(?is)<input\\b([^>]*)>").matcher(forms.group(2));while(inputs.find()){Map<String,String> a=attributes(inputs.group(1));if(!a.containsKey("name")||!a.containsKey("value"))continue;if(query.length()>0)query.append('&');query.append(enc(a.get("name"))).append('=').append(enc(a.get("value")));}
      if(query.length()>0)return action.toString()+(action.getQuery()==null?"?":"&")+query;
    }
    Matcher links=Pattern.compile("(?is)<a\\b([^>]*)>").matcher(html);while(links.find()){String href=attributes(links.group(1)).get("href");if(href==null)continue;URL candidate=new URL(new URL(base),href);if(driveDownload(candidate)&&candidate.getQuery()!=null&&candidate.getQuery().contains("confirm="))return candidate.toString();}
    throw new IOException("Drive returned a sign-in or confirmation page that could not be downloaded. Check public sharing or use a direct APK link.");
  }
  static void download(String initial,File destination,Progress progress)throws Exception{
    String url=normalize(initial);java.net.CookieManager cookies=new java.net.CookieManager(null,CookiePolicy.ACCEPT_ALL);int redirects=0,forms=0;
    try{
      while(redirects++<12){
        ScriptUpdateClient.requireHttps(url);URL target=new URL(url);HttpURLConnection c=(HttpURLConnection)target.openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(20000);c.setReadTimeout(30000);c.setRequestProperty("User-Agent","Mozilla/5.0 ChaotykBrowserUpdater/3");c.setRequestProperty("Accept","application/vnd.android.package-archive, application/octet-stream, */*");c.setRequestProperty("Cache-Control","no-cache");
        for(Map.Entry<String,List<String>> header:cookies.get(target.toURI(),Collections.emptyMap()).entrySet())c.setRequestProperty(header.getKey(),String.join("; ",header.getValue()));
        try{
          progress.update(0,-1);int code=c.getResponseCode();cookies.put(target.toURI(),c.getHeaderFields());
          if(Arrays.asList(301,302,303,307,308).contains(code)){String location=c.getHeaderField("Location");if(location==null)throw new IOException("Download redirect has no destination.");url=new URL(target,location).toString();continue;}
          if(code==429)throw new IOException("Google Drive is rate-limiting this download. Wait a few minutes and try again.");
          if(code!=200)throw new IOException("APK download returned HTTP "+code+".");
          try(BufferedInputStream in=new BufferedInputStream(c.getInputStream())){
            in.mark(16);int first=in.read(),second=in.read();in.reset();
            if(first!='P'||second!='K'){
              if(++forms>2)throw new IOException("Too many Drive download confirmation pages.");
              if(!target.getHost().equals("drive.google.com")&&!target.getHost().equals("drive.usercontent.google.com"))throw new IOException("Download link returned a web page instead of an APK.");
              ByteArrayOutputStream text=new ByteArrayOutputStream();byte[] chunk=new byte[8192];int n;while((n=in.read(chunk))!=-1){text.write(chunk,0,n);progress.update(0,-1);if(text.size()>1_000_000)throw new IOException("Download confirmation page is too large.");}url=confirmation(text.toString("UTF-8"),url);continue;
            }
            long expected=c.getContentLengthLong(),received=0;if(expected>MAX_BYTES)throw new IOException("APK exceeds the 150 MB download limit.");
            try(FileOutputStream out=new FileOutputStream(destination)){byte[] bytes=new byte[32768];int n;while((n=in.read(bytes))!=-1){received+=n;if(received>MAX_BYTES)throw new IOException("APK exceeds the 150 MB download limit.");out.write(bytes,0,n);progress.update(received,expected);}out.getFD().sync();}
            if(expected>=0&&received!=expected)throw new IOException("APK download was incomplete.");if(received<1024)throw new IOException("Downloaded file is too small to be an APK.");return;
          }
        }finally{c.disconnect();}
      }
      throw new IOException("Too many APK download redirects.");
    }catch(Exception e){if(destination.exists())destination.delete();throw e;}
  }
}
