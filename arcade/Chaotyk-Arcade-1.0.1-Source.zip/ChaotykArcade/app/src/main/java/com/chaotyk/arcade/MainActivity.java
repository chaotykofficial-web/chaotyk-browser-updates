package com.chaotyk.arcade;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.webkit.*;
import android.view.*;
import android.widget.*;
import java.io.*;

public class MainActivity extends Activity {
  static final String VERSION="1.0.1";
  static final String ORIGIN="https://appassets.androidplatform.net";
  static final String FEED="https://raw.githubusercontent.com/chaotykofficial-web/chaotyk-browser-updates/main/arcade/app-update.txt";
  WebView web; AppUpdateController updates; ValueCallback<Uri[]> fileCallback;
  String exportData; boolean background=false;
  @Override public void onCreate(Bundle state){
    super.onCreate(state);
    getWindow().setStatusBarColor(0xff09090c);getWindow().setNavigationBarColor(0xff09090c);
    // Keep gameplay away from notches and Android's navigation gestures.
    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
    web=new WebView(this);web.setBackgroundColor(0xff09090c);setContentView(web);
    WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setSupportZoom(false);s.setMediaPlaybackRequiresUserGesture(true);
    CookieManager.getInstance().setAcceptCookie(false);
    web.addJavascriptInterface(new Bridge(),"ArcadeNative");
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){return !isLocal(req.getUrl());}
      @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest req){
        Uri uri=req.getUrl();
        if(!isLocal(uri))return blocked();
        try{String name=uri.getPath().substring("/assets/".length());if(name.contains("..")||!name.matches("[A-Za-z0-9._/-]+"))return blocked();String type=name.endsWith(".js")?"application/javascript":name.endsWith(".html")?"text/html":"application/octet-stream";return new WebResourceResponse(type,"UTF-8",getAssets().open(name));}catch(Exception e){return blocked();}
      }
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onJsAlert(WebView w,String url,String text,JsResult result){new AlertDialog.Builder(MainActivity.this).setTitle("Chaotyk Arcade").setMessage(text).setPositiveButton("OK",(d,n)->result.confirm()).setOnCancelListener(d->result.cancel()).show();return true;}
      @Override public boolean onJsConfirm(WebView w,String url,String text,JsResult result){new AlertDialog.Builder(MainActivity.this).setTitle("Chaotyk Arcade").setMessage(text).setPositiveButton("Yes",(d,n)->result.confirm()).setNegativeButton("Cancel",(d,n)->result.cancel()).setOnCancelListener(d->result.cancel()).show();return true;}
      @Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> callback,FileChooserParams p){if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=callback;try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,61);}catch(Exception e){fileCallback.onReceiveValue(null);fileCallback=null;toast("No file picker is available");}return true;}
    });
    updates=new AppUpdateController(this,getSharedPreferences("arcade",MODE_PRIVATE),VERSION,FEED);
    web.loadUrl(ORIGIN+"/assets/index.html");
  }
  static boolean isLocal(Uri uri){return "https".equals(uri.getScheme())&&"appassets.androidplatform.net".equals(uri.getHost())&&(uri.getPort()==-1||uri.getPort()==443)&&uri.getPath()!=null&&uri.getPath().startsWith("/assets/");}
  static WebResourceResponse blocked(){return new WebResourceResponse("text/plain","UTF-8",403,"Blocked",java.util.Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));}
  void toast(String text){Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
  void options(){new AlertDialog.Builder(this).setTitle("Chaotyk Arcade · v"+VERSION).setItems(new String[]{"App updates","About Arcade","Exit Arcade"},(d,n)->{if(n==0)updates.menu();if(n==1)new AlertDialog.Builder(this).setTitle("Chaotyk Arcade").setMessage("18 games, ready offline.\n\nChaotyk · Android v"+VERSION+"\nGame collection v3.12.0\n\nScores and settings are stored on this device. Export your leaderboard before uninstalling. Updates keep your data.\n\nAndroid Back returns to the game menu; Back again exits.").setPositiveButton("OK",null).show();if(n==2)confirmExit();}).show();}
  void confirmExit(){new AlertDialog.Builder(this).setTitle("Exit Arcade?").setMessage("Saved scores and settings will be kept. The current round will end.").setNegativeButton("Keep playing",null).setPositiveButton("Exit",(d,n)->finish()).show();}
  final class Bridge {
    @JavascriptInterface public void menu(){runOnUiThread(()->options());}
    @JavascriptInterface public void exit(){runOnUiThread(()->confirmExit());}
    @JavascriptInterface public void resumeGame(){runOnUiThread(()->{background=false;web.resumeTimers();});}
    @JavascriptInterface public void importScores(){runOnUiThread(()->{try{startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE),63);}catch(Exception e){toast("No file picker is available");}});}
    @JavascriptInterface public void exportScores(String json){if(json==null||json.length()>2_000_000)return;runOnUiThread(()->{exportData=json;try{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"Chaotyk-Arcade-Scores.json");startActivityForResult(i,62);}catch(Exception e){exportData=null;toast("No file picker is available");}});}
  }
  @Override public void onBackPressed(){web.evaluateJavascript("window.arcadeBack && window.arcadeBack()",null);}
  void suspendGame(){if(web!=null&&!background){background=true;web.evaluateJavascript("window.arcadeSuspend && window.arcadeSuspend()",v->{if(background&&web!=null)web.pauseTimers();});}}
  @Override public void onWindowFocusChanged(boolean focused){super.onWindowFocusChanged(focused);if(!focused)suspendGame();else getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);}
  @Override protected void onPause(){if(updates!=null)updates.pause();suspendGame();if(web!=null)web.onPause();super.onPause();}
  @Override protected void onResume(){super.onResume();if(web!=null)web.onResume();if(updates!=null)updates.resume();}
  @Override protected void onDestroy(){if(updates!=null)updates.destroy();if(fileCallback!=null)fileCallback.onReceiveValue(null);if(web!=null){web.resumeTimers();web.removeJavascriptInterface("ArcadeNative");web.destroy();}super.onDestroy();}
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(updates!=null&&updates.result(request))return;if(request==63){if(result==RESULT_OK&&data!=null)try(InputStream in=getContentResolver().openInputStream(data.getData());ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] bytes=new byte[8192];int n;while((n=in.read(bytes))!=-1){out.write(bytes,0,n);if(out.size()>2_000_000)throw new IOException("Import is too large");}String text=out.toString("UTF-8");new org.json.JSONObject(text);web.evaluateJavascript("window.arcadeImport("+org.json.JSONObject.quote(text)+")",null);}catch(Exception e){toast("Could not read a valid leaderboard JSON file");}return;}if(request==61){if(fileCallback!=null){fileCallback.onReceiveValue(result==RESULT_OK&&data!=null?new Uri[]{data.getData()}:null);fileCallback=null;}return;}if(request==62){String content=exportData;exportData=null;if(result==RESULT_OK&&data!=null&&content!=null)try(OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write(content.getBytes("UTF-8"));toast("Leaderboard exported");}catch(Exception e){toast("Could not save the export");}}}
}
