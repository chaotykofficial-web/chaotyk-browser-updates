package com.chaotyk.arcade;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.net.Uri;
import android.provider.Settings;
import android.webkit.CookieManager;
import android.widget.*;
import java.io.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** App update lifecycle: release check → user choice → download → validation → Android installer. */
final class AppUpdateController {
  static final int ALLOW_INSTALL=52,INSTALL_RESULT=53;
  final Activity activity;final SharedPreferences prefs;final String version,defaultFeed;
  final Handler handler=new Handler(Looper.getMainLooper());
  boolean busy=false,promptVisible=false,resumed=false;
  final Runnable tick=new Runnable(){public void run(){if(!resumed)return;check(false);handler.postDelayed(this,300000L);}};
  AppUpdateController(Activity activity,SharedPreferences prefs,String version,String defaultFeed){this.activity=activity;this.prefs=prefs;this.version=version;this.defaultFeed=defaultFeed;cleanupInstalled();}
  void resume(){resumed=true;handler.removeCallbacks(tick);handler.postDelayed(tick,5000L);}
  void pause(){resumed=false;handler.removeCallbacks(tick);}
  void destroy(){pause();handler.removeCallbacksAndMessages(null);}
  void toast(String message){Toast.makeText(activity,message,Toast.LENGTH_LONG).show();}
  String source(){return prefs.getString("appUpdateSource",defaultFeed);}
  File directory(){File dir=new File(activity.getFilesDir(),"updates");dir.mkdirs();return dir;}
  File readyFile(){return new File(directory(),"app-update.apk");}
  void record(String message){prefs.edit().putString("appUpdateStatus",message).apply();}
  long code(PackageInfo p){return Build.VERSION.SDK_INT>=28?p.getLongVersionCode():p.versionCode;}
  int flags(){return Build.VERSION.SDK_INT>=28?PackageManager.GET_SIGNING_CERTIFICATES:PackageManager.GET_SIGNATURES;}
  Set<String> signers(PackageInfo p)throws Exception{android.content.pm.Signature[] signatures=Build.VERSION.SDK_INT>=28?(p.signingInfo==null?null:p.signingInfo.getApkContentsSigners()):p.signatures;Set<String> result=new TreeSet<>();if(signatures!=null)for(android.content.pm.Signature signature:signatures){byte[] digest=MessageDigest.getInstance("SHA-256").digest(signature.toByteArray());StringBuilder hex=new StringBuilder();for(byte b:digest)hex.append(String.format(Locale.ROOT,"%02x",b&255));result.add(hex.toString());}return result;}
  void validate(File file,String expected)throws Exception{
    PackageManager pm=activity.getPackageManager();PackageInfo installed=pm.getPackageInfo(activity.getPackageName(),flags()),candidate=pm.getPackageArchiveInfo(file.getAbsolutePath(),flags());
    if(candidate==null)throw new IOException("Downloaded file is not a readable Android APK.");
    AppRelease.validateApk(candidate.packageName,candidate.versionName,code(candidate),signers(candidate),installed.packageName,code(installed),signers(installed),expected);
  }
  void cleanupInstalled(){if(!readyFile().isFile())return;try{PackageManager pm=activity.getPackageManager();PackageInfo own=pm.getPackageInfo(activity.getPackageName(),0),pending=pm.getPackageArchiveInfo(readyFile().getAbsolutePath(),0);if(pending==null||code(pending)<=code(own)){readyFile().delete();prefs.edit().remove("appPendingVersion").remove("appInstallPermissionPending").apply();record("Running v"+version);}}catch(Exception ignored){}}
  void menu(){String[] items={"Check app updates now","Install downloaded update","Update-source URL",prefs.getBoolean("autoAppUpdates",true)?"Automatic app checks: on":"Automatic app checks: off"};String last=prefs.getString("appUpdateStatus","Not checked yet");new AlertDialog.Builder(activity).setTitle("App updates · v"+version).setMessage(last+"\n\nChecks on open/resume and every 5 minutes while Arcade is visible.").setPositiveButton("Check now",(d,n)->check(true)).setNeutralButton("Options",(d,n)->new AlertDialog.Builder(activity).setTitle("App update options").setItems(items,(a,b)->{if(b==0)check(true);if(b==1)installReady();if(b==2)editSource();if(b==3){prefs.edit().putBoolean("autoAppUpdates",!prefs.getBoolean("autoAppUpdates",true)).apply();toast("App update setting saved");}}).show()).setNegativeButton("Close",null).show();}
  void editSource(){EditText input=new EditText(activity);input.setSingleLine(true);input.setInputType(17);input.setText(source());AlertDialog dialog=new AlertDialog.Builder(activity).setTitle("Update-source URL").setMessage("Public HTTPS release-feed URL.").setView(input).setNegativeButton("Cancel",null).setNeutralButton("Reset",(d,n)->{prefs.edit().remove("appUpdateSource").remove("appUpdateLastAttempt").remove("appSnoozeVersion").apply();toast("Bundled update source restored");}).setPositiveButton("Save",null).create();dialog.setOnShowListener(d->dialog.getButton(-1).setOnClickListener(v->{try{String url=input.getText().toString().trim();ScriptUpdateClient.requireHttps(url);prefs.edit().putString("appUpdateSource",url).remove("appUpdateLastAttempt").remove("appSnoozeVersion").apply();record("Update source changed; ready to check");dialog.dismiss();}catch(Exception e){input.setError(e.getMessage());}}));dialog.show();}
  void check(boolean manual){
    if(busy){if(manual)toast("An app update check or download is already running");return;}
    long now=System.currentTimeMillis();if(!manual&&(!prefs.getBoolean("autoAppUpdates",true)||now-prefs.getLong("appUpdateLastAttempt",0)<60000L))return;
    String feed=source();if(feed==null||feed.isEmpty()){if(manual)editSource();return;}
    busy=true;prefs.edit().putLong("appUpdateLastAttempt",now).apply();record("Checking app updates…");if(manual)toast("Checking app updates…");
    new Thread(()->{try{AppRelease release=AppRelease.parse(ScriptUpdateClient.fetch(feed,u->CookieManager.getInstance().getCookie(u)));boolean newer=ScriptUpdateClient.compareVersions(release.version,version)>0;activity.runOnUiThread(()->{busy=false;if(!source().equals(feed)){record("Update source changed during check; retry");return;}record(newer?"v"+release.version+" is available":"Up to date · v"+version);if(!newer){if(manual)toast("You're up to date · v"+version);return;}if(manual||(resumed&&!activity.isFinishing()&&(!prefs.getString("appSnoozeVersion","").equals(release.version)||System.currentTimeMillis()>prefs.getLong("appSnoozeUntil",0))))offer(release);});}catch(Exception e){activity.runOnUiThread(()->{busy=false;record("Check failed: "+e.getMessage());if(manual)new AlertDialog.Builder(activity).setTitle("Could not check app updates").setMessage(e.getMessage()+"\n\nVerify the server URL and that its release file is published.").setPositiveButton("OK",null).show();});}}).start();
  }
  void offer(AppRelease release){if(promptVisible||activity.isFinishing())return;promptVisible=true;AlertDialog dialog=new AlertDialog.Builder(activity).setTitle("Chaotyk Arcade update available").setMessage("Installed: "+version+"\nAvailable: "+release.version+(release.notes.isEmpty()?"":"\n\n"+release.notes)+"\n\nDownload the APK and open Android's update installer? Your scores and settings stays in place.").setNegativeButton("Later",(d,n)->prefs.edit().putString("appSnoozeVersion",release.version).putLong("appSnoozeUntil",System.currentTimeMillis()+86400000L).apply()).setPositiveButton("Update",(d,n)->download(release)).create();dialog.setOnDismissListener(d->promptVisible=false);dialog.show();}
  void download(AppRelease release){
    if(busy)return;busy=true;AtomicBoolean cancelled=new AtomicBoolean(false);ProgressDialog progress=new ProgressDialog(activity);progress.setTitle("Downloading v"+release.version);progress.setMessage("Connecting…");progress.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);progress.setMax(100);progress.setIndeterminate(true);progress.setCancelable(false);progress.setButton(DialogInterface.BUTTON_NEGATIVE,"Cancel",(d,n)->cancelled.set(true));progress.show();record("Downloading v"+release.version);
    File part=new File(directory(),"download.part");
    new Thread(()->{try{long[] lastProgress={0};ApkDownload.download(release.link,part,(received,expected)->{if(cancelled.get())throw new IOException("Download cancelled");long now=System.currentTimeMillis();if(now-lastProgress[0]<200&&received!=expected)return;lastProgress[0]=now;activity.runOnUiThread(()->{progress.setIndeterminate(expected<=0);if(expected>0)progress.setProgress((int)(received*100/expected));progress.setMessage(received/1024+" KB"+(expected>0?" / "+expected/1024+" KB":""));});});if(cancelled.get())throw new IOException("Download cancelled");validate(part,release.version);File ready=readyFile();if(ready.exists()&&!ready.delete())throw new IOException("Cannot replace the previous downloaded APK.");if(!part.renameTo(ready))throw new IOException("Could not save the downloaded APK.");prefs.edit().putString("appPendingVersion",release.version).apply();activity.runOnUiThread(()->{busy=false;progress.dismiss();record("v"+release.version+" downloaded and checked");if(resumed&&!activity.isFinishing())installReady();else toast("Update downloaded. Open App updates to install it.");});}catch(Exception e){part.delete();activity.runOnUiThread(()->{busy=false;progress.dismiss();record("Download failed: "+e.getMessage());if(!activity.isFinishing())new AlertDialog.Builder(activity).setTitle("App update not installed").setMessage(e.getMessage()+"\n\nYour installed app has not been changed.").setPositiveButton("OK",null).show();});}}).start();
  }
  void installReady(){try{String expected=prefs.getString("appPendingVersion","");if(expected.isEmpty()||!readyFile().isFile()){toast("No update has been downloaded");return;}validate(readyFile(),expected);if(!activity.getPackageManager().canRequestPackageInstalls()){new AlertDialog.Builder(activity).setTitle("Allow Arcade to install its update").setMessage("Android needs permission to install app updates from Chaotyk Arcade. Enable Allow from this source, then return here.").setNegativeButton("Later",null).setPositiveButton("Open Android settings",(d,n)->{try{prefs.edit().putBoolean("appInstallPermissionPending",true).apply();activity.startActivityForResult(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+activity.getPackageName())),ALLOW_INSTALL);}catch(Exception e){prefs.edit().remove("appInstallPermissionPending").apply();toast("Android or device management did not allow opening this setting");}}).show();return;}launchInstaller();}catch(Exception e){toast(e.getMessage());record("Installer check failed: "+e.getMessage());}}
  void launchInstaller(){try{Uri uri=UpdateApkProvider.uri(activity);Intent intent=new Intent(Intent.ACTION_INSTALL_PACKAGE);intent.setDataAndType(uri,"application/vnd.android.package-archive");intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);intent.setClipData(ClipData.newRawUri("Chaotyk Arcade update",uri));intent.putExtra(Intent.EXTRA_RETURN_RESULT,true);intent.putExtra(Intent.EXTRA_INSTALLER_PACKAGE_NAME,activity.getPackageName());record("Android installer opened");activity.startActivityForResult(intent,INSTALL_RESULT);}catch(Exception e){record("Could not open Android installer");toast("Could not open the Android installer. The APK remains ready to retry.");}}
  boolean result(int request){if(request==ALLOW_INSTALL){prefs.edit().remove("appInstallPermissionPending").apply();if(activity.getPackageManager().canRequestPackageInstalls())installReady();else toast("Install permission wasn't enabled. Retry from App updates when ready.");return true;}if(request==INSTALL_RESULT){record("Installer closed; running v"+version);return true;}return false;}
}
